<?php
// Enable error logging for debugging (remove in production)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

// Start output buffering
ob_start();
session_start();
include 'db.php';

// Check if user is authenticated
if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}

// Function to escape SQL values
function escapeSQLValue($value, $conn) {
    if (is_null($value)) {
        return 'NULL';
    }
    return "'" . $conn->real_escape_string($value) . "'";
}

// Function to generate SQL backup
function generateSQLBackup($conn, &$error) {
    try {
        $sql = "-- Database Backup\n";
        $sql .= "-- Generated on: " . date('Y-m-d H:i:s') . "\n";
        $sql .= "-- Host: " . $conn->host_info . "\n";
        $sql .= "-- Database: " . $conn->real_escape_string($conn->select_db) . "\n\n";
        
        // Disable foreign key checks for restore
        $sql .= "SET FOREIGN_KEY_CHECKS = 0;\n";
        $sql .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n";
        $sql .= "SET time_zone = '+00:00';\n\n";
        
        // Get all tables
        $tables = [];
        $result = $conn->query("SHOW TABLES");
        if ($result === false) {
            $error = "Ошибка получения списка таблиц: " . $conn->error;
            error_log("Backup failed: " . $conn->error);
            return false;
        }
        
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
        
        foreach ($tables as $table) {
            $table_escaped = $conn->real_escape_string($table);
            
            // Get table structure
            $create_result = $conn->query("SHOW CREATE TABLE `$table_escaped`");
            if ($create_result === false) {
                $error = "Ошибка получения структуры таблицы '$table': " . $conn->error;
                error_log("Backup failed for table '$table': " . $conn->error);
                return false;
            }
            
            $row = $create_result->fetch_assoc();
            $sql .= "\n-- Table structure for `$table`\n";
            $sql .= "DROP TABLE IF EXISTS `$table`;\n";
            $sql .= $row['Create Table'] . ";\n\n";
            
            // Get table data
            $data_result = $conn->query("SELECT * FROM `$table_escaped`");
            if ($data_result === false) {
                $error = "Ошибка получения данных таблицы '$table': " . $conn->error;
                error_log("Backup failed for table '$table': " . $conn->error);
                return false;
            }
            
            if ($data_result->num_rows > 0) {
                $sql .= "-- Dumping data for `$table`\n";
                $columns = array_keys($data_result->fetch_assoc());
                $data_result->data_seek(0);
                $columns_escaped = array_map(function($col) use ($conn) {
                    return "`" . $conn->real_escape_string($col) . "`";
                }, $columns);
                $columns_str = implode(', ', $columns_escaped);
                
                while ($row = $data_result->fetch_assoc()) {
                    $values = array_map(function($value) use ($conn) {
                        return escapeSQLValue($value, $conn);
                    }, $row);
                    $sql .= "INSERT INTO `$table_escaped` ($columns_str) VALUES (" . implode(', ', $values) . ");\n";
                }
                $sql .= "\n";
            }
        }
        
        // Re-enable foreign key checks
        $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
        return $sql;
    } catch (Exception $e) {
        $error = "Ошибка создания бэкапа: " . $e->getMessage();
        error_log("Backup exception: " . $e->getMessage());
        return false;
    }
}

// Handle backup request
$backup_error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] === 'create_backup') {
    $sql_content = generateSQLBackup($conn, $backup_error);
    
    if ($sql_content !== false) {
        // Clear output buffer and send headers
        ob_end_clean();
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="backup_' . date('Y-m-d_H-i') . '.sql"');
        header('Content-Length: ' . strlen($sql_content));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        echo $sql_content;
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создание бэкапа базы данных</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <div class="main-content">
            <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
            <header>
                <div class="header-content">
                    <h1>Создание бэкапа базы данных</h1>
                    <p>Здравствуйте, <?php echo htmlspecialchars($_SESSION['admin_login']); ?>! Нажмите кнопку ниже для создания бэкапа.</p>
                </div>
                <a href="index.php" class="logout-btn">Назад</a>
            </header>
            <main>
                <div id="backup-panel" class="sql-query-panel">
                    <h2>Создать бэкап</h2>
                    <form method="post" action="create_backup.php">
                        <input type="hidden" name="action" value="create_backup">
                        <?php if ($backup_error): ?>
                            <p class="error"><?php echo htmlspecialchars($backup_error); ?></p>
                        <?php endif; ?>
                        <button type="submit" class="add-btn">Создать бэкап</button>
                    </form>
                </div>
            </main>
        </div>
    </div>
    <script>
        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
<?php ob_end_flush(); ?>
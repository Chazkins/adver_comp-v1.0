<?php
// Enable error logging for debugging (remove in production)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

// Start output buffering
ob_start();
session_start();
include 'db.php';

// Check if user is authenticated
if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}

// Function to find a name column in the campaigns table
function getCampaignNameColumn($conn) {
    $result = $conn->query("SHOW COLUMNS FROM campaigns");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $field = strtolower($row['Field']);
            if (in_array($field, ['name', 'campaign_name', 'title', 'description'])) {
                return $row['Field'];
            }
        }
    }
    return 'campaign_id';
}

// Fetch order statistics
$analytics_error = '';
$order_status_data = [];
$total_orders = 0;
$order_campaign_data = [];

try {
    // Check if orders table exists
    $tables_list = [];
    $result = $conn->query("SHOW TABLES");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $tables_list[] = $row[0];
        }
    } else {
        $analytics_error = "Ошибка: Не удалось получить список таблиц.";
        error_log("Analytics failed: Unable to fetch table list - " . $conn->error);
    }

    if (in_array('orders', $tables_list)) {
        // Order counts by status
        $status_query = $conn->query("SELECT status, COUNT(*) as count FROM orders GROUP BY status");
        if ($status_query) {
            while ($row = $status_query->fetch_assoc()) {
                $order_status_data[] = [
                    'status' => $row['status'] ?: 'Не указано',
                    'count' => (int)$row['count']
                ];
                $total_orders += (int)$row['count'];
            }
        } else {
            $analytics_error = "Ошибка получения данных по заказам: " . $conn->error;
            error_log("Analytics failed: Order status query - " . $conn->error);
        }

        // Order distribution by campaign (if campaigns table exists)
        if (in_array('campaigns', $tables_list)) {
            $name_column = getCampaignNameColumn($conn);
            $campaign_query = $conn->query("SELECT c.$name_column AS campaign_name, COUNT(o.order_id) as order_count 
                                           FROM orders o 
                                           LEFT JOIN campaigns c ON o.campaign_id = c.campaign_id 
                                           GROUP BY c.campaign_id, c.$name_column");
            if ($campaign_query) {
                while ($row = $campaign_query->fetch_assoc()) {
                    $order_campaign_data[] = [
                        'campaign_name' => $row['campaign_name'] ?: ($name_column === 'campaign_id' ? 'Кампания ID: ' . $row['campaign_name'] : 'Неизвестная кампания'),
                        'order_count' => (int)$row['order_count']
                    ];
                }
            } else {
                $analytics_error = "Ошибка получения данных по кампаниям: " . $conn->error;
                error_log("Analytics failed: Campaign orders query - " . $conn->error);
            }
        } else {
            $analytics_error = "Таблица 'campaigns' не найдена.";
            error_log("Analytics failed: Campaigns table not found.");
        }
    } else {
        $analytics_error = "Таблица 'orders' не найдена.";
        error_log("Analytics failed: Orders table not found.");
    }
} catch (Exception $e) {
    $analytics_error = "Ошибка аналитики: " . $e->getMessage();
    error_log("Analytics exception: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Аналитика</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
    <style>
        /* Дополнительные стили для улучшения читаемости */
        .analytics-panel {
            max-width: 800px;
            width: 100%;
            background: rgba(255, 255, 255, 0.15); /* Более прозрачный фон */
            border-radius: 15px;
            padding: 25px;
            margin: 20px auto;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(10px);
        }

        body.dark-theme .analytics-panel {
            background: rgba(44, 62, 80, 0.15); /* Такая же прозрачность для темной темы */
            box-shadow: 0 8px 30px rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.2);
        }

        .analytics-panel h2 {
            color: #2c3e50; /* Темный цвет для светлой темы */
            font-size: 1.8em;
            font-weight: 700;
            margin-bottom: 25px;
            text-align: center;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        body.dark-theme .analytics-panel h2 {
            color: #ecf0f1; /* Светлый цвет для темной темы */
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }

        .chart-container {
            background: rgba(255, 255, 255, 0.1); /* Полупрозрачный фон */
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 35px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            backdrop-filter: blur(5px);
        }

        body.dark-theme .chart-container {
            background: rgba(255, 255, 255, 0.05); /* Очень прозрачный фон для темной темы */
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.02);
        }

        .chart-container h3 {
            color: #2c3e50; /* Темный цвет для лучшей читаемости */
            font-size: 1.4em;
            font-weight: 600;
            margin-bottom: 15px;
            text-align: center;
        }

        body.dark-theme .chart-container h3 {
            color: #ecf0f1;
        }

        .total-orders {
            text-align: center;
            color: #2c3e50; /* Темный цвет */
            font-size: 1.1em;
            font-weight: 500;
            margin-bottom: 20px;
            padding: 12px;
            background: rgba(155, 89, 182, 0.15);
            border-radius: 8px;
            border-left: 4px solid #9b59b6;
        }

        body.dark-theme .total-orders {
            color: #ecf0f1;
            background: rgba(155, 89, 182, 0.2);
            border-left: 4px solid #8e44ad;
        }

        .analytics-info {
            color: #2c3e50; /* Темный цвет для лучшей читаемости */
            font-size: 1em;
            font-weight: 500; /* Более жирный шрифт */
            line-height: 1.6;
            margin-bottom: 20px;
            text-align: center;
            text-shadow: 0 1px 2px rgba(255,255,255,0.8);
        }

        body.dark-theme .analytics-info {
            color: #ecf0f1;
            text-shadow: 0 1px 2px rgba(0,0,0,0.3);
        }

        .chart-canvas-container {
            position: relative;
            height: 300px;
            margin-top: 20px;
        }

        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(155, 89, 182, 0.9), rgba(142, 68, 173, 0.9));
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        body.dark-theme .stat-card {
            background: linear-gradient(135deg, rgba(52, 73, 94, 0.9), rgba(44, 62, 80, 0.9));
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .stat-number {
            font-size: 2em;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 0.9em;
            opacity: 0.9;
        }

        /* Улучшение читаемости текста в светлой теме */
        .main-content p, 
        .main-content h1, 
        .main-content h2, 
        .main-content h3 {
            color: #2c3e50 !important; /* Принудительно темный цвет для светлой темы */
            text-shadow: 0 1px 2px rgba(255,255,255,0.8);
        }

        body.dark-theme .main-content p,
        body.dark-theme .main-content h1,
        body.dark-theme .main-content h2,
        body.dark-theme .main-content h3 {
            color: #ecf0f1 !important;
            text-shadow: 0 1px 2px rgba(0,0,0,0.3);
        }

        @media (max-width: 768px) {
            .analytics-panel {
                padding: 20px;
                margin: 15px;
            }

            .chart-container {
                padding: 15px;
            }

            .chart-canvas-container {
                height: 250px;
            }

            .stats-summary {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <div class="main-content">
            <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
            <header>
                <div class="header-content">
                    <h1>Аналитика заказов</h1>
                    <p class="analytics-info">Здравствуйте, <?php echo htmlspecialchars($_SESSION['admin_login']); ?>! Здесь отображается статистика заказов.</p>
                </div>
                <a href="index.php" class="logout-btn">Назад</a>
            </header>
            <main>
                <div class="analytics-panel">
                    <h2>📊 Статистика заказов</h2>
                    
                    <?php if ($analytics_error): ?>
                        <div class="error" style="text-align: center; font-size: 1.1em; padding: 20px; color: #e74c3c; font-weight: 500;">
                            <?php echo htmlspecialchars($analytics_error); ?>
                        </div>
                    <?php elseif (empty($order_status_data)): ?>
                        <div class="error" style="text-align: center; font-size: 1.1em; padding: 20px; color: #e74c3c; font-weight: 500;">
                            Нет данных для отображения аналитики.
                        </div>
                    <?php else: ?>
                        <!-- Сводка статистики -->
                        <div class="stats-summary">
                            <div class="stat-card">
                                <div class="stat-number"><?php echo $total_orders; ?></div>
                                <div class="stat-label">Всего заказов</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number"><?php echo count($order_status_data); ?></div>
                                <div class="stat-label">Статусов</div>
                            </div>
                            <?php if (!empty($order_campaign_data)): ?>
                            <div class="stat-card">
                                <div class="stat-number"><?php echo count($order_campaign_data); ?></div>
                                <div class="stat-label">Кампаний</div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- График по статусам -->
                        <div class="chart-container">
                            <h3>📈 Количество заказов по статусу</h3>
                            <p class="total-orders">Всего заказов: <strong><?php echo $total_orders; ?></strong></p>
                            <div class="chart-canvas-container">
                                <canvas id="statusChart"></canvas>
                            </div>
                        </div>

                        <!-- График по кампаниям -->
                        <?php if (!empty($order_campaign_data)): ?>
                            <div class="chart-container">
                                <h3>🎯 Распределение заказов по кампаниям</h3>
                                <div class="chart-canvas-container">
                                    <canvas id="campaignChart"></canvas>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script>
        try {
            const toggleButton = document.getElementById('theme-toggle');
            const body = document.body;

            if (localStorage.getItem('theme') === 'dark') {
                body.classList.add('dark-theme');
            }

            toggleButton.addEventListener('click', () => {
                body.classList.toggle('dark-theme');
                if (body.classList.contains('dark-theme')) {
                    localStorage.setItem('theme', 'dark');
                } else {
                    localStorage.setItem('theme', 'light');
                }
                // Обновляем графики при смене темы
                setTimeout(updateChartsTheme, 100);
            });

            const canvas = document.getElementById('stars-canvas');
            const ctx = canvas.getContext('2d');
            let stars = [];
            let numStars = 200;

            function initStars() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
                stars = [];
                for (let i = 0; i < numStars; i++) {
                    stars.push({
                        x: Math.random() * canvas.width,
                        y: Math.random() * canvas.height,
                        radius: Math.random() * 1.5 + 0.5,
                        speed: Math.random() * 0.5 + 0.2,
                        opacity: Math.random() * 0.5 + 0.5
                    });
                }
            }

            function drawStars() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.3)';
                for (let star of stars) {
                    ctx.globalAlpha = star.opacity;
                    ctx.beginPath();
                    ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                    ctx.fill();
                    star.y += star.speed;
                    if (star.y > canvas.height) {
                        star.y = -star.radius;
                        star.x = Math.random() * canvas.width;
                    }
                }
                ctx.globalAlpha = 1;
                requestAnimationFrame(drawStars);
            }

            function updateChartsTheme() {
                // Функция для обновления тем графиков
                const isDark = body.classList.contains('dark-theme');
                const textColor = isDark ? '#ecf0f1' : '#2c3e50';
                const gridColor = isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';
                
                // Здесь можно добавить логику обновления Chart.js графиков
                // если они уже были инициализированы
            }

            initStars();
            drawStars();

            window.addEventListener('resize', initStars);

            // Инициализация графиков
            <?php if (!empty($order_status_data)): ?>
            try {
                const statusCtx = document.getElementById('statusChart').getContext('2d');
                const isDark = body.classList.contains('dark-theme');
                const textColor = isDark ? '#ecf0f1' : '#2c3e50';
                const gridColor = isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';
                
                new Chart(statusCtx, {
                    type: 'bar',
                    data: {
                        labels: [<?php echo implode(',', array_map(function($item) { return '"' . addslashes($item['status']) . '"'; }, $order_status_data)); ?>],
                        datasets: [{
                            label: 'Количество заказов',
                            data: [<?php echo implode(',', array_column($order_status_data, 'count')); ?>],
                            backgroundColor: [
                                '#3498db', '#e74c3c', '#2ecc71', '#f1c40f', '#9b59b6', 
                                '#1abc9c', '#e67e22', '#34495e', '#7f8c8d', '#d35400'
                            ],
                            borderColor: [
                                '#2980b9', '#c0392b', '#27ae60', '#f39c12', '#8e44ad',
                                '#16a085', '#d35400', '#2c3e50', '#95a5a6', '#c0392b'
                            ],
                            borderWidth: 2,
                            borderRadius: 5
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Количество заказов',
                                    font: {
                                        size: 14,
                                        weight: 'bold'
                                    },
                                    color: textColor
                                },
                                ticks: {
                                    color: textColor
                                },
                                grid: {
                                    color: gridColor
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Статус заказа',
                                    font: {
                                        size: 14,
                                        weight: 'bold'
                                    },
                                    color: textColor
                                },
                                ticks: {
                                    color: textColor
                                },
                                grid: {
                                    display: false
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                backgroundColor: isDark ? 'rgba(44, 62, 80, 0.9)' : 'rgba(255, 255, 255, 0.9)',
                                titleColor: isDark ? '#ecf0f1' : '#2c3e50',
                                bodyColor: isDark ? '#ecf0f1' : '#2c3e50',
                                borderColor: '#9b59b6',
                                borderWidth: 1
                            }
                        }
                    }
                });
            } catch (e) {
                console.error('Error initializing status chart:', e);
            }
            <?php endif; ?>

            <?php if (!empty($order_campaign_data)): ?>
            try {
                const campaignCtx = document.getElementById('campaignChart').getContext('2d');
                const isDark = body.classList.contains('dark-theme');
                const textColor = isDark ? '#ecf0f1' : '#2c3e50';
                
                new Chart(campaignCtx, {
                    type: 'pie',
                    data: {
                        labels: [<?php echo implode(',', array_map(function($item) { return '"' . addslashes($item['campaign_name']) . '"'; }, $order_campaign_data)); ?>],
                        datasets: [{
                            label: 'Заказы по кампаниям',
                            data: [<?php echo implode(',', array_column($order_campaign_data, 'order_count')); ?>],
                            backgroundColor: [
                                '#3498db', '#e74c3c', '#2ecc71', '#f1c40f', '#9b59b6', 
                                '#1abc9c', '#e67e22', '#34495e', '#7f8c8d', '#d35400'
                            ],
                            borderColor: [
                                '#2980b9', '#c0392b', '#27ae60', '#f39c12', '#8e44ad',
                                '#16a085', '#d35400', '#2c3e50', '#95a5a6', '#c0392b'
                            ],
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'right',
                                labels: {
                                    color: textColor,
                                    font: {
                                        size: 12
                                    },
                                    padding: 15
                                }
                            },
                            tooltip: {
                                backgroundColor: isDark ? 'rgba(44, 62, 80, 0.9)' : 'rgba(255, 255, 255, 0.9)',
                                titleColor: isDark ? '#ecf0f1' : '#2c3e50',
                                bodyColor: isDark ? '#ecf0f1' : '#2c3e50',
                                borderColor: '#9b59b6',
                                borderWidth: 1
                            }
                        }
                    }
                });
            } catch (e) {
                console.error('Error initializing campaign chart:', e);
            }
            <?php endif; ?>

        } catch (e) {
            console.error('Error in analytics page:', e);
        }
    </script>
</body>
</html>
<?php ob_end_flush(); ?>
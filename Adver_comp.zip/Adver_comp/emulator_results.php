<?php
// emulator_results.php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

session_start();
include 'db.php';

// Проверка авторизации
if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}

// Улучшенная функция для проверки валидности ФИО (без изменений данных)
function isValidFIO($fio) {
    $reasons = [];
    
    // Проверка на пустоту
    if (empty(trim($fio))) {
        return ['valid' => false, 'reason' => 'ФИО не может быть пустым'];
    }
    
    // Проверка длины (не более 100 символов)
    $length = mb_strlen(trim($fio));
    if ($length > 100) {
        $reasons[] = "Превышена максимальная длина (100 символов)";
    }
    if ($length < 5) {
        $reasons[] = "Слишком короткое ФИО (менее 5 символов)";
    }
    
    // Проверка на наличие запрещенных символов
    $forbidden_chars = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '[', ']', 
                       '{', '}', ';', ':', '"', '\\', '|', ',', '.', '<', '>', '?', '~', '№', '`'];
    
    $found_chars = [];
    foreach ($forbidden_chars as $char) {
        if (strpos($fio, $char) !== false) {
            $found_chars[] = $char;
        }
    }
    
    if (!empty($found_chars)) {
        $reasons[] = "Обнаружены запрещенные символы: " . implode(', ', $found_chars);
    }
    
    // Проверка на цифры
    if (preg_match('/\d/', $fio)) {
        $reasons[] = "Обнаружены цифры";
    }
    
    // Проверка на некорректные скобки
    if (preg_match('/[\(\)\[\]\{\}]/', $fio)) {
        $reasons[] = "Обнаружены скобки";
    }
    
    // Проверка формата (должно быть 3 слова)
    $parts = explode(' ', trim($fio));
    if (count($parts) !== 3) {
        $reasons[] = "Должно состоять из трёх слов (Фамилия Имя Отчество)";
    } else {
        // Проверка что каждое слово начинается с заглавной буквы
        foreach ($parts as $part) {
            $trimmed_part = trim($part);
            if (mb_strlen($trimmed_part) < 2) {
                $reasons[] = "Каждое слово должно содержать минимум 2 символа";
                break;
            }
            
            $first_char = mb_substr($trimmed_part, 0, 1);
            if (mb_strtolower($first_char) === $first_char) {
                $reasons[] = "Каждое слово должно начинаться с заглавной буквы";
                break;
            }
        }
    }
    
    if (empty($reasons)) {
        return ['valid' => true, 'reason' => 'Соответствует всем критериям'];
    } else {
        return [
            'valid' => false, 
            'reason' => implode('; ', $reasons),
            'details' => $reasons
        ];
    }
}

// Функция для получения данных из эмулятора БЕЗ КАКОЙ-ЛИБО ОБРАБОТКИ
function getRawFIOFromEmulator() {
    $emulator_url = 'http://prb.sylas.ru/TransferSimulator/fullName';
    
    try {
        $context = stream_context_create([
            'http' => [
                'timeout' => 10,
                'ignore_errors' => true
            ]
        ]);
        
        $response = file_get_contents($emulator_url, false, $context);
        if ($response !== false) {
            $data = json_decode($response, true);
            if (isset($data['value'])) {
                // ВОЗВРАЩАЕМ ДАННЫЕ "КАК ЕСТЬ" БЕЗ ОБРАБОТКИ
                $raw_fio = $data['value'];
                
                // Проверяем валидность, но НЕ изменяем данные
                $validation_result = isValidFIO($raw_fio);
                
                return [
                    'value' => $raw_fio, // Возвращаем оригинальные данные
                    'valid' => $validation_result['valid'],
                    'reason' => $validation_result['reason'],
                    'details' => $validation_result['details'] ?? [],
                    'raw_data' => $raw_fio // Сохраняем оригинальные данные
                ];
            }
        }
    } catch (Exception $e) {
        error_log("Error accessing emulator: " . $e->getMessage());
    }
    
    return [
        'value' => false,
        'valid' => false,
        'error' => 'Не удалось получить данные от эмулятора',
        'reason' => 'Эмулятор недоступен или не возвращает данные'
    ];
}

// Функция для проверки различий по роду фамилии (универсальная)
function isGenderVariant($name1, $name2) {
    $name1 = mb_strtolower(trim($name1));
    $name2 = mb_strtolower(trim($name2));
    
    // Если фамилии уже одинаковые - не вариант по роду
    if ($name1 === $name2) {
        return false;
    }
    
    // Минимальная длина фамилии для проверки
    if (mb_strlen($name1) < 3 || mb_strlen($name2) < 3) {
        return false;
    }
    
    // Основная проверка на различие по роду
    $last_char1 = mb_substr($name1, -1);
    $last_char2 = mb_substr($name2, -1);
    
    // Случай 1: name1 оканчивается на 'а', name2 - нет
    if ($last_char1 === 'а' && $last_char2 !== 'а') {
        $base1 = mb_substr($name1, 0, -1);
        return $base1 === $name2;
    }
    
    // Случай 2: name2 оканчивается на 'а', name1 - нет  
    if ($last_char1 !== 'а' && $last_char2 === 'а') {
        $base2 = mb_substr($name2, 0, -1);
        return $name1 === $base2;
    }
    
    return false;
}

// Функция для разбиения ФИО на компоненты с проверкой позиции
function extractNameParts($full_name) {
    $parts = explode(' ', trim($full_name));
    
    // Определяем компоненты по позициям
    $last_name = $parts[0] ?? '';
    $first_name = $parts[1] ?? '';
    $middle_name = $parts[2] ?? '';
    
    // Если в ФИО больше 3 слов, объединяем оставшиеся в отчество
    if (count($parts) > 3) {
        $middle_name = implode(' ', array_slice($parts, 2));
    }
    
    return [
        'last_name' => $last_name,
        'first_name' => $first_name,
        'middle_name' => $middle_name
    ];
}

// Функция для анализа соответствия данных на основе результатов поиска
function analyzeMatch($emulator_data, $search_results, $filter_type) {
    $analysis = [
        'level' => 'unknown',
        'message' => '',
        'details' => [],
        'validation' => [
            'passed' => false,
            'reasons' => []
        ]
    ];
    
    // Проверяем валидность данных эмулятора
    if (!$emulator_data['valid']) {
        $analysis['level'] = 'invalid';
        $analysis['message'] = 'Данные от эмулятора не соответствуют критериям валидности';
        $analysis['validation']['passed'] = false;
        
        if (isset($emulator_data['details'])) {
            foreach ($emulator_data['details'] as $detail) {
                $analysis['validation']['reasons'][] = $detail;
                $analysis['details'][] = "✗ " . $detail;
            }
        } else {
            $analysis['validation']['reasons'][] = $emulator_data['reason'];
            $analysis['details'][] = "✗ " . $emulator_data['reason'];
        }
        
        $analysis['details'][] = "Полученные данные: \"" . ($emulator_data['value'] ?: 'пусто') . "\"";
        $analysis['details'][] = "Рекомендация: Требуется корректировка данных эмулятора";
        return $analysis;
    }
    
    // Данные валидны
    $analysis['validation']['passed'] = true;
    $analysis['validation']['reasons'][] = $emulator_data['reason'];
    $analysis['details'][] = "✓ " . $emulator_data['reason'];
    
    // Разбиваем ФИО на составляющие
    $emulator_parts = extractNameParts($emulator_data['value']);
    $emulator_last_name = $emulator_parts['last_name'];
    $emulator_first_name = $emulator_parts['first_name'];
    $emulator_middle_name = $emulator_parts['middle_name'];
    
    switch ($filter_type) {
        case 'last_name':
            if (count($search_results) > 0) {
                $analysis['level'] = 'full';
                $analysis['message'] = 'Найдены клиенты с фамилией: ' . $emulator_last_name;
                $analysis['details'][] = "Количество найденных клиентов: " . count($search_results);
                $analysis['details'][] = "Фамилия из эмулятора: {$emulator_last_name}";
                
                // Проверяем, есть ли точные совпадения фамилий
                $exact_matches = 0;
                foreach ($search_results as $client) {
                    $client_parts = extractNameParts($client['full_name']);
                    if (strcasecmp($client_parts['last_name'], $emulator_last_name) == 0) {
                        $exact_matches++;
                    }
                }
                
                if ($exact_matches > 0) {
                    $analysis['details'][] = "Точные совпадения фамилий: {$exact_matches}";
                }
                
                // Проверяем варианты по роду
                $gender_variants = 0;
                foreach ($search_results as $client) {
                    $client_parts = extractNameParts($client['full_name']);
                    if (isGenderVariant($client_parts['last_name'], $emulator_last_name)) {
                        $gender_variants++;
                    }
                }
                
                if ($gender_variants > 0) {
                    $analysis['level'] = 'partial';
                    $analysis['message'] = 'Найдены клиенты с фамилиями, отличающимися по роду';
                    $analysis['details'][] = "Совпадения с учетом рода: {$gender_variants}";
                    $analysis['details'][] = "Рекомендация: Учитывайте мужской/женский варианты фамилий";
                }
            } else {
                $analysis['level'] = 'low';
                $analysis['message'] = 'Клиенты с фамилией "' . $emulator_last_name . '" не найдены';
                $analysis['details'][] = "Фамилия из эмулятора: {$emulator_last_name}";
                $analysis['details'][] = "Рекомендация: Проверить возможные опечатки или различные написания";
            }
            $analysis['details'][] = "Количество попыток эмулятора: {$emulator_data['attempts']}";
            break;
            
        case 'first_name':
            if (count($search_results) > 0) {
                $analysis['level'] = 'full';
                $analysis['message'] = 'Найдены клиенты с именем: ' . $emulator_first_name;
                $analysis['details'][] = "Количество найденных клиентов: " . count($search_results);
                $analysis['details'][] = "Имя из эмулятора: {$emulator_first_name}";
                
                // Проверяем точные совпадения имен
                $exact_matches = 0;
                foreach ($search_results as $client) {
                    $client_parts = extractNameParts($client['full_name']);
                    if (strcasecmp($client_parts['first_name'], $emulator_first_name) == 0) {
                        $exact_matches++;
                    }
                }
                
                $analysis['details'][] = "Точные совпадения имен: {$exact_matches}";
            } else {
                $analysis['level'] = 'low';
                $analysis['message'] = 'Клиенты с именем "' . $emulator_first_name . '" не найдены';
                $analysis['details'][] = "Имя из эмулятора: {$emulator_first_name}";
                $analysis['details'][] = "Примечание: Возможно использование сокращенных форм имени";
            }
            $analysis['details'][] = "Количество попыток эмулятора: {$emulator_data['attempts']}";
            break;
            
        case 'industry':
            $industry_filter = $_GET['industry_filter'] ?? '';
            if (count($search_results) > 0) {
                $analysis['level'] = 'info';
                $analysis['message'] = 'Найдены клиенты в индустрии: ' . $industry_filter;
                $analysis['details'][] = "Количество найденных клиентов: " . count($search_results);
                $analysis['details'][] = "Индустрия для поиска: {$industry_filter}";
            } else {
                $analysis['level'] = 'low';
                $analysis['message'] = 'Клиенты в индустрии "' . $industry_filter . '" не найдены';
                $analysis['details'][] = "Индустрия для поиска: {$industry_filter}";
            }
            $analysis['details'][] = "Количество попыток эмулятора: {$emulator_data['attempts']}";
            break;
            
        case 'all':
            if (count($search_results) > 0) {
                // Анализируем качество совпадений
                $exact_matches = 0;
                $partial_matches = 0;
                
                foreach ($search_results as $client) {
                    $client_parts = extractNameParts($client['full_name']);
                    $matches = 0;
                    
                    // Проверка фамилии
                    if (strcasecmp($client_parts['last_name'], $emulator_last_name) == 0) {
                        $matches++;
                    } elseif (isGenderVariant($client_parts['last_name'], $emulator_last_name)) {
                        $matches += 0.7;
                    }
                    
                    // Проверка имени
                    if (strcasecmp($client_parts['first_name'], $emulator_first_name) == 0) {
                        $matches++;
                    }
                    
                    // Проверка отчества
                    if (strcasecmp($client_parts['middle_name'], $emulator_middle_name) == 0) {
                        $matches++;
                    }
                    
                    $match_percentage = ($matches / 3) * 100;
                    
                    if ($match_percentage >= 90) {
                        $exact_matches++;
                    } elseif ($match_percentage >= 60) {
                        $partial_matches++;
                    }
                }
                
                $total_matches = $exact_matches + $partial_matches;
                
                if ($exact_matches > 0) {
                    $analysis['level'] = 'full';
                    $analysis['message'] = 'Найдены клиенты с полным соответствием ФИО';
                    $analysis['details'][] = "Клиентов с полным соответствием: {$exact_matches}";
                    if ($partial_matches > 0) {
                        $analysis['details'][] = "Клиентов с частичным соответствием: {$partial_matches}";
                    }
                } elseif ($partial_matches > 0) {
                    $analysis['level'] = 'partial';
                    $analysis['message'] = 'Найдены клиенты с частичным соответствием ФИО';
                    $analysis['details'][] = "Клиентов с частичным соответствием: {$partial_matches}";
                } else {
                    $analysis['level'] = 'low';
                    $analysis['message'] = 'Найдены клиенты с низким соответствием ФИО';
                }
                
                $analysis['details'][] = "Общее количество найденных клиентов: " . count($search_results);
            } else {
                $analysis['level'] = 'low';
                $analysis['message'] = 'Клиенты по всем критериям ФИО не найдены';
                $analysis['details'][] = "Рекомендуется дополнительная верификация";
            }
            $analysis['details'][] = "Количество попыток эмулятора: {$emulator_data['attempts']}";
            break;
    }
    
    return $analysis;
}

// Функция для поиска клиентов с учетом позиции компонентов ФИО
function searchClientsByPosition($conn, $emulator_data, $filter_type) {
    $search_results = [];
    
    if (!$emulator_data['valid']) {
        return $search_results;
    }
    
    // Разбиваем ФИО из эмулятора на составляющие
    $emulator_parts = extractNameParts($emulator_data['value']);
    $last_name_emulator = $emulator_parts['last_name'];
    $first_name_emulator = $emulator_parts['first_name'];
    $middle_name_emulator = $emulator_parts['middle_name'];
    
    // Формируем SQL запрос в зависимости от фильтра
    $query = "SELECT * FROM clients WHERE 1=1";
    $params = [];
    $types = '';
    
    switch ($filter_type) {
        case 'last_name':
            // Ищем только по фамилии (первое слово в ФИО)
            $query .= " AND (SUBSTRING_INDEX(full_name, ' ', 1) LIKE ? OR full_name LIKE ?)";
            $params = ["$last_name_emulator%", "$last_name_emulator %"];
            $types = 'ss';
            break;
            
        case 'first_name':
            // Ищем только по имени (второе слово в ФИО)
            $query .= " AND (";
            $query .= "   (SUBSTRING_INDEX(SUBSTRING_INDEX(full_name, ' ', 2), ' ', -1) LIKE ?) OR "; // Второе слово
            $query .= "   (full_name LIKE ? AND full_name NOT LIKE ?)"; // Имя не в начале
            $query .= ")";
            $params = ["$first_name_emulator%", "% $first_name_emulator %", "$first_name_emulator %"];
            $types = 'sss';
            break;
            
        case 'industry':
            $industry_filter = $_GET['industry_filter'] ?? '';
            if (!empty($industry_filter)) {
                $query .= " AND industry = ?";
                $params[] = $industry_filter;
                $types .= 's';
            }
            break;
            
        case 'all':
        default:
            // Ищем по всем компонентам ФИО с учетом позиций
            $query .= " AND (";
            $query .= "   (SUBSTRING_INDEX(full_name, ' ', 1) LIKE ?) OR "; // Фамилия
            $query .= "   (SUBSTRING_INDEX(SUBSTRING_INDEX(full_name, ' ', 2), ' ', -1) LIKE ?) OR "; // Имя
            $query .= "   (SUBSTRING_INDEX(full_name, ' ', -1) LIKE ?)"; // Отчество
            $query .= ")";
            $params = [
                "$last_name_emulator%", 
                "$first_name_emulator%", 
                "$middle_name_emulator%"
            ];
            $types = 'sss';
            break;
    }
    
    try {
        // Выполняем поиск
        $stmt = $conn->prepare($query);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $search_results = $result->fetch_all(MYSQLI_ASSOC);
        
        // Дополнительная фильтрация на PHP для точного соответствия позициям
        if (!empty($search_results)) {
            $search_results = array_filter($search_results, function($client) use ($filter_type, $emulator_parts) {
                $client_parts = extractNameParts($client['full_name']);
                
                switch ($filter_type) {
                    case 'last_name':
                        // Проверяем, что совпадение именно с фамилией (первое слово)
                        return strcasecmp($client_parts['last_name'], $emulator_parts['last_name']) == 0 ||
                               isGenderVariant($client_parts['last_name'], $emulator_parts['last_name']);
                        
                    case 'first_name':
                        // Проверяем, что совпадение именно с именем (второе слово)
                        return strcasecmp($client_parts['first_name'], $emulator_parts['first_name']) == 0;
                        
                    case 'all':
                        // Для "всех критериев" оставляем все результаты
                        return true;
                        
                    default:
                        return true;
                }
            });
            
            // Переиндексируем массив
            $search_results = array_values($search_results);
        }
        
    } catch (Exception $e) {
        error_log("Search error: " . $e->getMessage());
    }
    
    return $search_results;
}

// Обработка параметров
$search_results = [];
$error_message = '';
$emulator_data = null;
$analysis_result = null;

try {
    // Получаем данные из эмулятора БЕЗ обработки
    $emulator_data = getRawFIOFromEmulator();
    
    if (!$emulator_data['value']) {
        $error_message = "Не удалось получить данные от эмулятора. " . 
                       ($emulator_data['error'] ?? "Проверьте, запущен ли эмулятор.");
    } else {
        // Выполняем поиск в БД по всем критериям (поскольку убрали фильтры)
        $search_results = searchClientsByPosition($conn, $emulator_data, 'all');
        
        // Выполняем анализ соответствия на основе результатов поиска
        $analysis_result = analyzeMatch($emulator_data, $search_results, 'all');
        
        if (empty($search_results)) {
            $error_message = "Клиенты по сгенерированным данным не найдены.";
        }
    }
} catch (Exception $e) {
    $error_message = "Ошибка при выполнении поиска: " . $e->getMessage();
    error_log("Emulator search error: " . $e->getMessage());
}

// Получаем список уникальных индустрий
$industries = [];
$industry_result = $conn->query("SELECT DISTINCT industry FROM clients WHERE industry IS NOT NULL AND industry != '' ORDER BY industry");
if ($industry_result) {
    $industries = $industry_result->fetch_all(MYSQLI_ASSOC);
}
?>

<!-- HTML код -->
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Результаты поиска через эмулятор</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
    <style>
        .analysis-result.invalid {
            color: #ff4444;
            font-weight: bold;
            background: rgba(255, 68, 68, 0.1);
            padding: 5px 10px;
            border-radius: 4px;
            border-left: 3px solid #ff4444;
        }
        
        .validation-info {
            background: rgba(255, 193, 7, 0.1);
            border-left: 3px solid #ffc107;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }
        
        .search-info {
            background: rgba(33, 150, 243, 0.1);
            border-left: 3px solid #2196f3;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .highlight-match {
            background: rgba(76, 175, 80, 0.1) !important;
            border-left: 3px solid #4caf50;
        }
        
        .analysis-result.full {
            color: #4caf50;
            font-weight: bold;
        }
        
        .analysis-result.partial {
            color: #ff9800;
            font-weight: bold;
        }
        
        .analysis-result.low {
            color: #f44336;
            font-weight: bold;
        }
        
        .analysis-result.info {
            color: #2196f3;
            font-weight: bold;
        }
        
        .validation-passed {
            background: rgba(76, 175, 80, 0.1);
            border-left: 3px solid #4caf50;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            color: #2e3333;
        }
        
        .validation-failed {
            background: rgba(244, 67, 54, 0.1);
            border-left: 3px solid #f44336;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            color: #2e3333;
        }
        
        .raw-data-warning {
            background: rgba(255, 152, 0, 0.1);
            border-left: 3px solid #ff9800;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            color: #2e3333;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <div class="main-content">
          <button id="theme-toggle" class="theme-toggle-btn" aria-label="Переключить тему">
    <span class="theme-icon">🌙</span>
</button>
            <header>
                <div class="header-content">
                    <h1>Результаты поиска через эмулятор</h1>
                    <p>Результаты вашего запроса с проверкой валидности данных</p>
                </div>
                <a href="index.php" class="logout-btn">Вернуться</a>
            </header>
            <main>
                <div id="emulator-results-panel" class="emulator-results-panel glass-container">
                    <?php if ($error_message): ?>
                        <div class="error-message glass-container">
                            <span class="error-icon">⚠️</span>
                            <?php echo $error_message; ?>
                        </div>
                    <?php elseif ($emulator_data): ?>
                        <div class="data-sources">
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🎰</span>
                                    <h3>Данные из эмулятора</h3>
                                </div>
                                <div class="source-content">
                                    <strong>ФИО (оригинальные данные):</strong>
                                    <span class="fio-value" style="color: #e74c3c; font-weight: bold;">"<?php echo htmlspecialchars($emulator_data['value']); ?>"</span>
                                    
                                    <div class="raw-data-warning">
                                        <strong>⚠ Режим работы:</strong> Данные получены "как есть" без обработки
                                    </div>
                                    
                                    <?php if ($emulator_data['valid']): ?>
                                        <div class="validation-passed">
                                            <strong>✓ Валидация пройдена</strong><br>
                                            <?php echo $emulator_data['reason']; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="validation-failed">
                                            <strong>✗ Валидация не пройдена</strong><br>
                                            <?php echo $emulator_data['reason']; ?>
                                            <?php if (isset($emulator_data['details']) && !empty($emulator_data['details'])): ?>
                                                <div style="margin-top: 8px;">
                                                    <strong>Детали ошибок:</strong>
                                                    <?php foreach ($emulator_data['details'] as $detail): ?>
                                                        <div style="font-size: 0.9em; margin: 2px 0;">• <?php echo htmlspecialchars($detail); ?></div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- Блок анализа соответствия -->
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🔍</span>
                                    <h3>Анализ соответствия</h3>
                                </div>
                                <div class="source-content">
                                    <strong>Статус:</strong>
                                    <span class="analysis-result <?php echo $analysis_result['level']; ?>">
                                        <?php echo htmlspecialchars($analysis_result['message']); ?>
                                    </span>
                                    
                                    <!-- Детали валидации -->
                                    <?php if (isset($analysis_result['validation'])): ?>
                                        <div class="validation-<?php echo $analysis_result['validation']['passed'] ? 'passed' : 'failed'; ?>">
                                            <strong>Проверка валидности:</strong>
                                            <?php foreach ($analysis_result['validation']['reasons'] as $reason): ?>
                                                <div><?php echo $reason; ?></div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($analysis_result['details'])): ?>
                                        <div class="analysis-details">
                                            <?php foreach ($analysis_result['details'] as $detail): ?>
                                                <div class="analysis-detail">• <?php echo htmlspecialchars($detail); ?></div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🎯</span>
                                    <h3>Критерий поиска</h3>
                                </div>
                                <div class="source-content">
                                    <strong>Фильтр:</strong>
                                    <span class="filter-value">
                                        <?php 
                                        switch ($filter_type) {
                                            case 'last_name': echo 'По фамилии'; break;
                                            case 'first_name': echo 'По имени'; break;
                                            case 'industry': echo 'По услугам'; break;
                                            case 'all': echo 'По всем критериям'; break;
                                            default: echo htmlspecialchars($filter_type);
                                        }
                                        ?>
                                    </span>
                                    <?php if ($emulator_data['valid']): ?>
                                        <?php 
                                        $emulator_parts = extractNameParts($emulator_data['value']);
                                        ?>
                                        <div class="search-info">
                                            <strong>Режим поиска:</strong> Точное соответствие по позиции в ФИО<br>
                                            <strong>Разобранные компоненты:</strong><br>
                                            • Фамилия: <strong><?php echo htmlspecialchars($emulator_parts['last_name']); ?></strong><br>
                                            • Имя: <strong><?php echo htmlspecialchars($emulator_parts['first_name']); ?></strong><br>
                                            • Отчество: <strong><?php echo htmlspecialchars($emulator_parts['middle_name']); ?></strong>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                       <?php if (!empty($search_results)): ?>
    <div class="results-section">
        <div class="results-count">
            <span class="count-icon">📊</span>
            Найдено клиентов: <strong><?php echo count($search_results); ?></strong>
        </div>
        
        <div class="compact-table-wrapper">
            <div class="table-scroll-container" style="max-height: 500px; overflow-y: auto;">
                <table class="compact-table" style="min-width: 1000px;">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Организация</th>
                            <th>ФИО</th>
                            <th>Контактное лицо</th>
                            <th>Email</th>
                            <th>Телефон</th>
                            <th>ИНН</th>
                            <th>Индустрия</th>
                            <th>Бюджет</th>
                            <th>Регион</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($search_results as $client): ?>
                            <?php 
                            $client_parts = extractNameParts($client['full_name']);
                            $highlight_class = '';
                            
                            // Определяем, нужно ли подсвечивать строку
                            if ($filter_type === 'last_name') {
                                if (strcasecmp($client_parts['last_name'], $emulator_parts['last_name']) == 0) {
                                    $highlight_class = 'highlight-match';
                                } elseif (isGenderVariant($client_parts['last_name'], $emulator_parts['last_name'])) {
                                    $highlight_class = 'highlight-match';
                                }
                            } elseif ($filter_type === 'first_name') {
                                if (strcasecmp($client_parts['first_name'], $emulator_parts['first_name']) == 0) {
                                    $highlight_class = 'highlight-match';
                                }
                            }
                            ?>
                            <tr class="<?php echo $highlight_class; ?>">
                                <td><?php echo htmlspecialchars($client['client_id']); ?></td>
                                <td><?php echo htmlspecialchars($client['org_name']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($client['full_name']); ?></strong>
                                    <div style="font-size: 12px; color: #666;">
                                        Ф: <?php echo htmlspecialchars($client_parts['last_name']); ?> | 
                                        И: <?php echo htmlspecialchars($client_parts['first_name']); ?> | 
                                        О: <?php echo htmlspecialchars($client_parts['middle_name']); ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($client['contact_person']); ?></td>
                                <td><?php echo htmlspecialchars($client['email']); ?></td>
                                <td><?php echo htmlspecialchars($client['phone']); ?></td>
                                <td><?php echo htmlspecialchars($client['inn']); ?></td>
                                <td>
                                    <span class="industry-badge"><?php echo htmlspecialchars($client['industry']); ?></span>
                                </td>
                                <td>
                                    <?php 
                                    $budget_class = '';
                                    switch ($client['budget_segment']) {
                                        case 'high': $budget_class = 'budget-high'; break;
                                        case 'medium': $budget_class = 'budget-medium'; break;
                                        case 'low': $budget_class = 'budget-low'; break;
                                    }
                                    ?>
                                    <span class="budget-segment <?php echo $budget_class; ?>">
                                        <?php echo htmlspecialchars($client['budget_segment']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($client['region']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
                        
                        <div class="action-buttons">
                            <a href="javascript:window.print()" class="action-btn print-btn">
                                <span class="btn-icon">🖨️</span>
                                Печать результатов
                            </a>
                            <a href="index.php" class="action-btn back-btn">
                                <span class="btn-icon">↩️</span>
                                Новый поиск
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script>
        // JavaScript код остается без изменений
        const toggleButton = document.getElementById('theme-toggle');
    const body = document.body;
    const themeIcon = toggleButton.querySelector('.theme-icon');

    function updateThemeIcon() {
        if (body.classList.contains('dark-theme')) {
            themeIcon.textContent = '☀️';
        } else {
            themeIcon.textContent = '🌙';
        }
    }

    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-theme');
    }

    updateThemeIcon();

    toggleButton.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        if (body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
        updateThemeIcon();
    });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
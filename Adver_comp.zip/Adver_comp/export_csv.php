<?php
session_start();
include 'db.php';

// Проверяем авторизацию
if (!isset($_SESSION['admin_login'])) {
    die("Ошибка: Доступ запрещен. Необходима авторизация.");
}

// Получаем название таблицы из GET-параметра
$table_name = isset($_GET['table']) ? trim($_GET['table']) : '';

if (empty($table_name)) {
    die("Ошибка: Не указано название таблицы.");
}

// Проверка на существование таблицы
$stmt = $conn->prepare("SHOW TABLES LIKE ?");
$stmt->bind_param("s", $table_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Ошибка: Таблица '$table_name' не существует.");
}
$stmt->close();

// Получение данных таблицы
$result = $conn->query("SELECT * FROM `$table_name`");
if (!$result) {
    die("Ошибка при получении данных таблицы: " . $conn->error);
}

// Проверяем, есть ли данные
if ($result->num_rows === 0) {
    die("Таблица '$table_name' пуста.");
}

// Очищаем все буферы вывода
while (ob_get_level()) {
    ob_end_clean();
}

// Устанавливаем заголовки для скачивания CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $table_name . '_export_' . date('Y-m-d_H-i') . '.csv"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Открываем вывод
$output = fopen('php://output', 'w');

// Добавляем BOM для корректного отображения кириллицы в Excel
fputs($output, "\xEF\xBB\xBF");

// Получаем названия колонок
$columns = array();
foreach ($result->fetch_fields() as $field) {
    $columns[] = $field->name;
}
fputcsv($output, $columns);

// Записываем данные
while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
exit();
?>
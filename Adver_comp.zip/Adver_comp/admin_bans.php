<?php
session_start();
include 'db.php';

// Проверка авторизации администратора
if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}

// Функция для разблокировки пользователя
function unbanUser($login, $conn) {
    $stmt = $conn->prepare("DELETE FROM banned_users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

// Разблокировка пользователя
if (isset($_GET['unban'])) {
    $login_to_unban = $_GET['unban'];
    if (unbanUser($login_to_unban, $conn)) {
        $success_message = "Пользователь $login_to_unban разблокирован";
    } else {
        $error_message = "Ошибка при разблокировке пользователя";
    }
}

// Получение списка заблокированных пользователей
$banned_users_result = $conn->query("
    SELECT bu.* 
    FROM banned_users bu 
    WHERE bu.banned_until IS NULL OR bu.banned_until > NOW()
    ORDER BY bu.banned_at DESC
");

// Получение статистики неудачных попыток входа
$failed_attempts_result = $conn->query("
    SELECT login, COUNT(*) as attempts, MAX(attempt_time) as last_attempt 
    FROM failed_logins 
    WHERE attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR) 
    GROUP BY login 
    ORDER BY attempts DESC
");

// Получение статистики неудачных попыток капчи
$failed_captcha_attempts_result = $conn->query("
    SELECT login, COUNT(*) as attempts, MAX(attempt_time) as last_attempt 
    FROM failed_captcha_attempts 
    WHERE attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR) 
    GROUP BY login 
    ORDER BY attempts DESC
");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление блокировками</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
    
    <div class="centered-header">
        <div class="header-container">
            <a href="index.php" class="back-link">
                <span class="back-arrow">&larr;</span>
                На главную
            </a>
            <h1 class="table-title">Управление блокировками пользователей</h1>
        </div>
    </div>

    <div class="table-page-container">
        <?php if (isset($success_message)): ?>
            <div style="background: #2ecc71; color: white; padding: 10px; border-radius: 5px; margin-bottom: 20px; text-align: center;">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div style="background: #e74c3c; color: white; padding: 10px; border-radius: 5px; margin-bottom: 20px; text-align: center;">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <!-- Заблокированные пользователи -->
        <div class="compact-table-wrapper">
            <h2 style="text-align: center; margin-bottom: 15px;">Заблокированные пользователи</h2>
            <div class="table-scroll-container">
                <table class="compact-table">
                    <thead>
                        <tr>
                            <th>Логин</th>
                            <th>Заблокирован до</th>
                            <th>Тип блокировки</th>
                            <th>Причина</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($banned_users_result->num_rows > 0): ?>
                            <?php while($user = $banned_users_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($user['login']); ?></td>
                                    <td><?php echo $user['banned_until'] ? htmlspecialchars($user['banned_until']) : 'Навсегда'; ?></td>
                                    <td><?php echo $user['ban_type'] == 'captcha' ? 'Капча' : 'Логин'; ?></td>
                                    <td><?php echo htmlspecialchars($user['reason']); ?></td>
                                    <td class="actions">
                                        <a href="admin_bans.php?unban=<?php echo urlencode($user['login']); ?>" class="edit-btn" onclick="return confirm('Разблокировать пользователя <?php echo htmlspecialchars($user['login']); ?>?')">Разблокировать</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5">Нет заблокированных пользователей</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Статистика неудачных попыток входа -->
        <div class="compact-table-wrapper">
            <h2 style="text-align: center; margin-bottom: 15px;">Неудачные попытки входа (последний час)</h2>
            <div class="table-scroll-container">
                <table class="compact-table">
                    <thead>
                        <tr>
                            <th>Логин</th>
                            <th>Количество попыток</th>
                            <th>Последняя попытка</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($failed_attempts_result->num_rows > 0): ?>
                            <?php while($attempt = $failed_attempts_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($attempt['login']); ?></td>
                                    <td><?php echo $attempt['attempts']; ?></td>
                                    <td><?php echo htmlspecialchars($attempt['last_attempt']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="3">Нет неудачных попыток входа за последний час</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Статистика неудачных попыток капчи -->
        <div class="compact-table-wrapper">
            <h2 style="text-align: center; margin-bottom: 15px;">Неудачные попытки капчи (последний час)</h2>
            <div class="table-scroll-container">
                <table class="compact-table">
                    <thead>
                        <tr>
                            <th>Логин</th>
                            <th>Количество попыток</th>
                            <th>Последняя попытка</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($failed_captcha_attempts_result->num_rows > 0): ?>
                            <?php while($attempt = $failed_captcha_attempts_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($attempt['login']); ?></td>
                                    <td><?php echo $attempt['attempts']; ?></td>
                                    <td><?php echo htmlspecialchars($attempt['last_attempt']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="3">Нет неудачных попыток капчи за последний час</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
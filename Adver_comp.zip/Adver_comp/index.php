<?php
ob_start();
session_start();
include 'db.php';

$error_message = '';
$max_attempts = 3;
$ban_duration = 24 * 60 * 60;

// Функция для проверки блокировки пользователя
function isUserBanned($login, $conn) {
    $stmt = $conn->prepare("SELECT banned_until FROM banned_users WHERE login = ? AND (banned_until IS NULL OR banned_until > NOW())");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    $is_banned = $result->num_rows > 0;
    $stmt->close();
    return $is_banned;
}

// Функция для получения количества неудачных попыток за последний час
function getFailedAttempts($login, $conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) as attempts FROM failed_logins WHERE login = ? AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['attempts'];
}

// Функция для добавления неудачной попытки входа
function addFailedAttempt($login, $conn) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt = $conn->prepare("INSERT INTO failed_logins (login, ip_address) VALUES (?, ?)");
    $stmt->bind_param("ss", $login, $ip);
    $stmt->execute();
    $stmt->close();
}

// Функция для блокировки пользователя
function banUser($login, $conn) {
    $conn->query("DELETE FROM banned_users WHERE login = '$login'");
    $banned_until = date('Y-m-d H:i:s', time() + 24 * 60 * 60);
    $reason = 'Превышено количество неудачных попыток входа';
    $sql = "INSERT INTO banned_users (login, banned_until, reason) VALUES ('$login', '$banned_until', '$reason')";
    if ($conn->query($sql)) {
        error_log("Пользователь $login заблокирован до $banned_until");
        return true;
    } else {
        error_log("Ошибка блокировки $login: " . $conn->error);
        return false;
    }
}

// Функция для разблокировки пользователя
function unbanUser($login, $conn) {
    $stmt = $conn->prepare("DELETE FROM banned_users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $stmt->close();
}

// Функция для хэширования пароля
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Функция для проверки пароля
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Функция для экранирования данных для CSV
function escapeCSV($value) {
    if (is_null($value)) {
        return '';
    }
    $value = str_replace('"', '""', $value);
    return '"' . $value . '"';
}

// Обработка экспорта таблицы в CSV через отдельный файл
$export_error = null;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['export_table_direct'])) {
    $table_name = trim($_POST['export_table_direct']);
    
    // Проверка на существование таблицы
    $stmt = $conn->prepare("SHOW TABLES LIKE ?");
    $stmt->bind_param("s", $table_name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $export_error = "Таблица '$table_name' не существует.";
    } else {
        // Перенаправляем на отдельный файл экспорта
        header("Location: export_csv.php?table=" . urlencode($table_name));
        exit();
    }
    $stmt->close();
}

// Обработка логина
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $login = trim($_POST['login']);
    $password = $_POST['password'];

    if (isUserBanned($login, $conn)) {
        $error_message = "Аккаунт временно заблокирован. Попробуйте позже или обратитесь к администратору.";
    } else {
        $failed_attempts = getFailedAttempts($login, $conn);
        
        if ($failed_attempts >= $max_attempts) {
            banUser($login, $conn);
            $error_message = "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
        } else {
            $stmt = $conn->prepare("SELECT admin_id, login, password_hash FROM admins WHERE login = ?");
            $stmt->bind_param("s", $login);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $admin = $result->fetch_assoc();
                
                if (verifyPassword($password, $admin['password_hash'])) {
                    $delete_stmt = $conn->prepare("DELETE FROM failed_logins WHERE login = ?");
                    $delete_stmt->bind_param("s", $login);
                    $delete_stmt->execute();
                    $delete_stmt->close();
                    
                    $_SESSION['admin_login'] = $admin['login'];
                    $_SESSION['admin_id'] = $admin['admin_id'];
                    header("Location: index.php");
                    exit();
                } else {
                    addFailedAttempt($login, $conn);
                    $remaining_attempts = $max_attempts - ($failed_attempts + 1);
                    $error_message = $remaining_attempts > 0 
                        ? "Неверный логин или пароль. Осталось попыток: $remaining_attempts"
                        : "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
                }
            } else {
                addFailedAttempt($login, $conn);
                $error_message = "Неверный логин или пароль.";
            }
            $stmt->close();
        }
    }
}

// Обработка SQL-запроса
$sql_result = null;
$sql_error = null;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sql_query'])) {
    $sql_query = trim($_POST['sql_query']);
    
    $restricted_commands = ['DROP', 'ALTER', 'DELETE', 'TRUNCATE', 'INSERT', 'UPDATE'];
    $query_upper = strtoupper($sql_query);
    $is_restricted = false;
    foreach ($restricted_commands as $command) {
        if (strpos($query_upper, $command) === 0) {
            $is_restricted = true;
            break;
        }
    }
    
    if ($is_restricted) {
        $sql_error = "Ошибка: Запрещено выполнение команд DROP, ALTER, DELETE, TRUNCATE, INSERT, UPDATE.";
    } else {
        if (stripos($sql_query, 'SELECT') === 0) {
            $result = $conn->query($sql_query);
            if ($result) {
                $sql_result = $result->fetch_all(MYSQLI_ASSOC);
            } else {
                $sql_error = "Ошибка выполнения запроса: " . $conn->error;
            }
        } else {
            $sql_error = "Ошибка: Поддерживаются только SELECT-запросы.";
        }
    }
}

function getEmoji($tableName) {
    switch ($tableName) {
        case 'admins': return '👤';
        case 'briefs': return '📄';
        case 'campaigns': return '📢';
        case 'clients': return '👥';
        case 'creatives': return '🎨';
        case 'interactions': return '💬';
        case 'logistics': return '🚚';
        case 'materials': return '🛠️';
        case 'orders': return '🛒';
        case 'registration': return '📝';
        case 'reports': return '📊';
        case 'suppliers': return '🤝';
        case 'failed_logins': return '🚫';
        case 'banned_users': return '⛔';
        default: return '📁';
    }
}

// Получаем список таблиц для отображения
$tables_list = array();
$tables_result = $conn->query("SHOW TABLES");
if ($tables_result->num_rows > 0) {
    while($table_row = $tables_result->fetch_array()) {
        $tables_list[] = $table_row[0];
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления БД</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <?php if (isset($_SESSION['admin_login'])): ?>
            <div class="sidebar">
                <div class="table-list">
                    <?php
                    foreach ($tables_list as $table_name) {
                        $emoji = getEmoji($table_name);
                        echo "<a href='table_view.php?table=" . $table_name . "' class='table-item'>{$emoji} " . $table_name . "</a>";
                    }
                    ?>
                    <a href='admin_bans.php' class='table-item'>⛔ Управление блокировками</a>
                </div>
            </div>
            <div class="main-content">
                <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
                <header>
                    <div class="header-content">
                        <h1>Панель управления базой данных</h1>
                        <p>Здравствуйте, <?php echo htmlspecialchars($_SESSION['admin_login']); ?>! Выберите таблицу для работы.</p>
                    </div>
                    <a href="logout.php" class="logout-btn">Выйти</a>
                </header>
                <main>
                    <button id="resource-monitor-btn" class="resource-monitor-btn">Мониторинг ресурсов</button>
                    <div id="resource-monitor-panel" class="resource-monitor-panel" style="display: none;">
                        <h2>Состояние системы</h2>
                        <div class="resource-item">
                            <span>Загрузка ЦП:</span>
                            <span id="cpu-usage">N/A</span>
                        </div>
                        <div class="resource-item">
                            <span>Использование ОЗУ:</span>
                            <span id="ram-usage">N/A</span>
                        </div>
                        <div class="resource-item">
                            <span>Количество ядер ЦП:</span>
                            <span id="cpu-cores">N/A</span>
                        </div>
                        <div class="resource-item">
                            <span>Время работы:</span>
                            <span id="uptime">N/A</span>
                        </div>
                    </div>
                    
                    <button id="sql-query-btn" class="sql-query-btn">Выполнить SQL-запрос</button>
                    <div id="sql-query-panel" class="sql-query-panel" style="display: block;">
                        <h2>SQL-запрос</h2>
                        <form method="post" action="index.php">
                            <div class="form-group">
                                <label for="sql_query">Введите SQL-запрос</label>
                                <textarea id="sql_query" name="sql_query" rows="5" style="width: 100%; resize: vertical;"><?php echo isset($_POST['sql_query']) ? htmlspecialchars($_POST['sql_query']) : ''; ?></textarea>
                            </div>
                            <?php if ($sql_error): ?>
                                <p class="error"><?php echo htmlspecialchars($sql_error); ?></p>
                            <?php endif; ?>
                            <button type="submit" class="add-btn">Выполнить</button>
                        </form>
                        <?php if ($sql_result): ?>
                            <div class="compact-table-wrapper">
                                <div class="table-scroll-container">
                                    <table class="compact-table">
                                        <thead>
                                            <tr>
                                                <?php foreach (array_keys($sql_result[0]) as $column): ?>
                                                    <th><?php echo htmlspecialchars($column); ?></th>
                                                <?php endforeach; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($sql_result as $row): ?>
                                                <tr>
                                                    <?php foreach ($row as $value): ?>
                                                        <td><?php echo htmlspecialchars($value); ?></td>
                                                    <?php endforeach; ?>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <button id="export-table-btn" class="sql-query-btn">Экспорт таблицы в CSV</button>
                    <div id="export-table-panel" class="sql-query-panel" style="display: none;">
                        <h2>Экспорт таблицы</h2>
                        
                        <!-- Способ 1: Прямой ввод названия таблицы -->
                        <form method="post" action="index.php" style="margin-bottom: 20px;">
                            <div class="form-group">
                                <label for="export_table_direct">Введите название таблицы</label>
                                <input type="text" id="export_table_direct" name="export_table_direct" 
                                       placeholder="Например: clients, orders, users"
                                       value="<?php echo isset($_POST['export_table_direct']) ? htmlspecialchars($_POST['export_table_direct']) : ''; ?>">
                            </div>
                            <?php if ($export_error): ?>
                                <p class="error"><?php echo htmlspecialchars($export_error); ?></p>
                            <?php endif; ?>
                            <button type="submit" class="add-btn">Экспортировать</button>
                        </form>
                        
                        <!-- Способ 2: Быстрый экспорт по клику -->
                        <div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                            <h3>Быстрый экспорт:</h3>
                            <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                                <?php foreach ($tables_list as $table_name): ?>
                                    <a href="export_csv.php?table=<?php echo urlencode($table_name); ?>" 
                                       class="export-quick-btn" 
                                       target="_blank"
                                       title="Экспорт таблицы <?php echo htmlspecialchars($table_name); ?>">
                                       📥 <?php echo htmlspecialchars($table_name); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <!-- Список доступных таблиц -->
                        <div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.05); border-radius: 5px;">
                            <h3>Доступные таблицы:</h3>
                            <div style="font-size: 0.9em; columns: 2; column-gap: 20px;">
                                <?php foreach ($tables_list as $table_name): ?>
                                    <div style="padding: 3px 0; break-inside: avoid;">• <?php echo htmlspecialchars($table_name); ?></div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        <?php else: ?>
            <div class="main-content">
                <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
                <div class="login-container" style="display: flex; max-width: 800px;">
                    <div style="flex: 1; padding: 40px;">
                        <h2>Вход в панель управления</h2>
                        <form method="post" action="index.php">
                            <div class="form-group">
                                <label for="login">Логин</label>
                                <input type="text" id="login" name="login" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Пароль</label>
                                <input type="password" id="password" name="password" required>
                            </div>
                            <?php if ($error_message): ?>
                                <p class="error"><?php echo $error_message; ?></p>
                            <?php endif; ?>
                            <button type="submit" class="login-btn">Войти</button>
                        </form>
                    </div>
                    <div style="flex: 1; padding: 40px; background-color: rgba(236, 240, 241, 0.7); border-radius: 15px; text-align: center; transition: background-color 0.5s ease; box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);">
                        <h2>О системе</h2>
                        <p>Добро пожаловать в панель управления базой данных. Эта система предоставляет безопасный доступ к управлению данными, включая просмотр, редактирование и удаление записей. Используйте ваши учетные данные для входа.</p>
                        <p style="margin-top: 20px; font-size: 0.9em; color: #2c3e50;">© 2025 Все права защищены</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script>
        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);

        // Resource Monitor Functionality
        const resourceButton = document.getElementById('resource-monitor-btn');
        const resourcePanel = document.getElementById('resource-monitor-panel');

        resourceButton.addEventListener('click', () => {
            resourcePanel.style.display = resourcePanel.style.display === 'none' ? 'block' : 'none';
            if (resourcePanel.style.display === 'block') {
                updateResourceMonitor();
            }
        });

        function updateResourceMonitor() {
            const cpuUsageElement = document.getElementById('cpu-usage');
            const ramUsageElement = document.getElementById('ram-usage');
            const cpuCoresElement = document.getElementById('cpu-cores');
            const uptimeElement = document.getElementById('uptime');

            cpuCoresElement.textContent = navigator.hardwareConcurrency ? navigator.hardwareConcurrency : 'N/A';

            const simulateResourceData = () => {
                const cpuUsage = (Math.random() * 100).toFixed(1) + '%';
                const ramUsage = (Math.random() * 16).toFixed(1) + 'GB / 16GB';
                const uptimeSeconds = Math.floor(performance.now() / 1000);
                const hours = Math.floor(uptimeSeconds / 3600);
                const minutes = Math.floor((uptimeSeconds % 3600) / 60);
                const seconds = uptimeSeconds % 60;

                cpuUsageElement.textContent = cpuUsage;
                ramUsageElement.textContent = ramUsage;
                uptimeElement.textContent = `${hours}h ${minutes}m ${seconds}s`;
            };

            simulateResourceData();
            if (resourcePanel.style.display === 'block') {
                setTimeout(updateResourceMonitor, 2000);
            }
        }

        // SQL Query Functionality
        const sqlQueryButton = document.getElementById('sql-query-btn');
        const sqlQueryPanel = document.getElementById('sql-query-panel');

        sqlQueryButton.addEventListener('click', () => {
            if (sqlQueryPanel.style.display === 'none' || sqlQueryPanel.style.display === '') {
                sqlQueryPanel.style.display = 'block';
            } else {
                sqlQueryPanel.style.display = 'none';
            }
        });

        // Export Table Functionality
        const exportTableButton = document.getElementById('export-table-btn');
        const exportTablePanel = document.getElementById('export-table-panel');

        exportTableButton.addEventListener('click', () => {
            if (exportTablePanel.style.display === 'none' || exportTablePanel.style.display === '') {
                exportTablePanel.style.display = 'block';
            } else {
                exportTablePanel.style.display = 'none';
            }
        });

        // Keep panels open after form submission if they were open
        document.addEventListener('DOMContentLoaded', () => {
            if (<?php echo isset($_POST['sql_query']) ? 'true' : 'false'; ?>) {
                sqlQueryPanel.style.display = 'block';
            }
            if (<?php echo isset($_POST['export_table_direct']) ? 'true' : 'false'; ?>) {
                exportTablePanel.style.display = 'block';
            }
        });
    </script>
</body>
</html>
<?php 
ob_end_flush();
?>
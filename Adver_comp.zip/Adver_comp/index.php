<?php
// Enable error logging for debugging (remove in production)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

// Start output buffering
ob_start();
session_start();
include 'db.php';

$error_message = '';
$export_error = '';
$max_attempts = 3;
$max_captcha_attempts = 3;
$ban_duration = 24 * 60 * 60;

function isUserBanned($login, $conn) {
    $login = $conn->real_escape_string($login);
    
    // Сначала проверяем существование колонки ban_type
    $check_column = $conn->query("SHOW COLUMNS FROM banned_users LIKE 'ban_type'");
    if ($check_column->num_rows > 0) {
        // Колонка существует, используем новый запрос
        $result = $conn->query("SELECT banned_until, ban_type FROM banned_users WHERE login = '$login' AND (banned_until IS NULL OR banned_until > NOW())");
    } else {
        // Колонки нет, используем старый запрос
        $result = $conn->query("SELECT banned_until FROM banned_users WHERE login = '$login' AND (banned_until IS NULL OR banned_until > NOW())");
    }
    
    if ($result === false) {
        error_log("isUserBanned error: " . $conn->error);
        return false;
    }
    $is_banned = $result->num_rows > 0;
    return $is_banned;
}

// Функция для получения количества неудачных попыток за последний час
function getFailedAttempts($login, $conn) {
    $login = $conn->real_escape_string($login);
    $result = $conn->query("SELECT COUNT(*) as attempts FROM failed_logins WHERE login = '$login' AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    if ($result === false) {
        error_log("getFailedAttempts error: " . $conn->error);
        return 0;
    }
    $row = $result->fetch_assoc();
    return $row['attempts'];
}

// Функция для получения количества неудачных попыток капчи за последний час
function getFailedCaptchaAttempts($login, $conn) {
    $login = $conn->real_escape_string($login);
    $result = $conn->query("SELECT COUNT(*) as attempts FROM failed_captcha_attempts WHERE login = '$login' AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    if ($result === false) {
        error_log("getFailedCaptchaAttempts error: " . $conn->error);
        return 0;
    }
    $row = $result->fetch_assoc();
    return $row['attempts'];
}

// Функция для добавления неудачной попытки входа
function addFailedAttempt($login, $conn) {
    $ip = $conn->real_escape_string($_SERVER['REMOTE_ADDR']);
    $login = $conn->real_escape_string($login);
    $result = $conn->query("INSERT INTO failed_logins (login, ip_address) VALUES ('$login', '$ip')");
    if ($result === false) {
        error_log("addFailedAttempt error: " . $conn->error);
    }
}

// Функция для добавления неудачной попытки капчи
function addFailedCaptchaAttempt($login, $conn) {
    $ip = $conn->real_escape_string($_SERVER['REMOTE_ADDR']);
    $login = $conn->real_escape_string($login);
    $result = $conn->query("INSERT INTO failed_captcha_attempts (login, ip_address) VALUES ('$login', '$ip')");
    if ($result === false) {
        error_log("addFailedCaptchaAttempt error: " . $conn->error);
    }
}

// Функция для блокировки пользователя
function banUser($login, $conn, $ban_type = 'login') {
    $login = $conn->real_escape_string($login);
    $conn->query("DELETE FROM banned_users WHERE login = '$login'");
    $banned_until = date('Y-m-d H:i:s', time() + 24 * 60 * 60);
    $reason = $conn->real_escape_string($ban_type == 'captcha' ? 'Превышено количество неудачных попыток ввода капчи' : 'Превышено количество неудачных попыток входа');
    $sql = "INSERT INTO banned_users (login, banned_until, reason, ban_type) VALUES ('$login', '$banned_until', '$reason', '$ban_type')";
    if ($conn->query($sql)) {
        error_log("Пользователь $login заблокирован до $banned_until по причине: $ban_type");
        return true;
    } else {
        error_log("Ошибка блокировки $login: " . $conn->error);
        return false;
    }
}

// Функция для разблокировки пользователя
function unbanUser($login, $conn) {
    $login = $conn->real_escape_string($login);
    $result = $conn->query("DELETE FROM banned_users WHERE login = '$login'");
    if ($result === false) {
        error_log("unbanUser error: " . $conn->error);
    }
}

// Функция для хэширования пароля
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Функция для проверки пароля
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Функция для экранирования данных для CSV
function escapeCSV($value) {
    if (is_null($value)) {
        return '';
    }
    if (strpos($value, ',') !== false || strpos($value, '"') !== false || strpos($value, "\n") !== false) {
        return '"' . str_replace('"', '""', $value) . '"';
    }
    return $value;
}

// Получение списка таблиц для валидации
function getTableList($conn) {
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    } else {
        error_log("Failed to fetch table list: " . $conn->error);
    }
    return $tables;
}

// Генерация капчи с пазлом
function generatePuzzleCaptcha() {
    $images = ['1.png', '2.png', '3.png', '4.png'];
    $puzzle_order = [1, 2, 3, 4];
    shuffle($puzzle_order); // Перемешиваем порядок пазлов
    
    $_SESSION['puzzle_correct_order'] = [1, 2, 3, 4]; // Правильный порядок
    $_SESSION['puzzle_current_order'] = $puzzle_order; // Текущий перемешанный порядок
    
    return [
        'images' => $images,
        'current_order' => $puzzle_order,
        'correct_order' => [1, 2, 3, 4]
    ];
}

// Получаем или генерируем капчу-пазл
if (!isset($_SESSION['puzzle_current_order'])) {
    $captcha_data = generatePuzzleCaptcha();
} else {
    // ВСЕГДА генерируем новую капчу при загрузке страницы
$captcha_data = generatePuzzleCaptcha();
}

// Обработка экспорта таблицы в JSON
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] === 'export_table') {
    try {
        $table_name = trim($_POST['export_table']);
        $table_name = $conn->real_escape_string($table_name);
        $tables_list = getTableList($conn);
        
        // Проверка на существование таблицы
        if (!in_array($table_name, $tables_list)) {
            $export_error = "Таблица '$table_name' не существует.";
            error_log("Export failed: Table '$table_name' does not exist.");
        } else {
            // Получение данных таблицы
            $result = $conn->query("SELECT * FROM `$table_name`");
            if ($result === false) {
                $export_error = "Ошибка при получении данных таблицы: " . $conn->error;
                error_log("Export failed: " . $conn->error);
            } elseif ($result->num_rows === 0) {
                $export_error = "Таблица '$table_name' пуста.";
                error_log("Export failed: Table '$table_name' is empty.");
            } else {
                // Собираем данные в массив
                $json_data = array();
                while ($row = $result->fetch_assoc()) {
                    $json_data[] = $row;
                }
                
                // Преобразуем в JSON
                $json_output = json_encode($json_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                
                // Clear output buffer and send headers
                ob_end_clean();
                header('Content-Type: application/json; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $table_name . '_export_' . date('Y-m-d_H-i') . '.json"');
                header('Content-Length: ' . strlen($json_output));
                header('Cache-Control: no-cache, no-store, must-revalidate');
                header('Pragma: no-cache');
                header('Expires: 0');
                
                echo $json_output;
                exit();
            }
        }
    } catch (Exception $e) {
        $export_error = "Ошибка экспорта: " . $e->getMessage();
        error_log("Export exception: " . $e->getMessage());
    }
}

// Обработка SQL-запроса
$sql_result = null;
$sql_error = null;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sql_query'])) {
    try {
        $sql_query = trim($_POST['sql_query']);
        $restricted_commands = ['DROP', 'ALTER', 'DELETE', 'TRUNCATE', 'INSERT', 'UPDATE'];
        $query_upper = strtoupper($sql_query);
        $is_restricted = false;
        foreach ($restricted_commands as $command) {
            if (strpos($query_upper, $command) === 0) {
                $is_restricted = true;
                break;
            }
        }
        
        if ($is_restricted) {
            $sql_error = "Ошибка: Запрещено выполнение команд DROP, ALTER, DELETE, TRUNCATE, INSERT, UPDATE.";
            error_log("SQL query blocked: $sql_query");
        } else {
            if (stripos($sql_query, 'SELECT') === 0) {
                $result = $conn->query($sql_query);
                if ($result) {
                    $sql_result = $result->fetch_all(MYSQLI_ASSOC);
                } else {
                    $sql_error = "Ошибка выполнения запроса: " . $conn->error;
                    error_log("SQL query error: " . $conn->error);
                }
            } else {
                $sql_error = "Ошибка: Поддерживаются только SELECT-запросы.";
                error_log("Invalid SQL query: $sql_query");
            }
        }
    } catch (Exception $e) {
        $sql_error = "Ошибка SQL: " . $e->getMessage();
        error_log("SQL exception: " . $e->getMessage());
    }
}

// Обработка логина
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    try {
        $login = trim($_POST['login']);
        $password = $_POST['password'];

        // Проверка блокировки пользователя
        if (isUserBanned($login, $conn)) {
            $error_message = "Аккаунт временно заблокирован. Попробуйте позже или обратитесь к администратору.";
            error_log("Login failed: $login is banned.");
        } else {
            // Проверка капчи
            if (!isset($_POST['puzzle_order']) || empty($_POST['puzzle_order'])) {
                $error_message = "Пожалуйста, соберите пазл для входа.";
                error_log("Login failed: Puzzle not completed for $login.");
            } else {
                $submitted_order = json_decode($_POST['puzzle_order'], true);
                $correct_order = isset($_SESSION['puzzle_correct_order']) ? $_SESSION['puzzle_correct_order'] : null;
                
                if (json_encode($submitted_order) !== json_encode($correct_order)) {
                    // Неверная капча
                    addFailedCaptchaAttempt($login, $conn);
                    $failed_captcha_attempts = getFailedCaptchaAttempts($login, $conn);
                    
                    if ($failed_captcha_attempts >= $max_captcha_attempts) {
                        banUser($login, $conn, 'captcha');
                        $error_message = "Превышено количество неудачных попыток ввода капчи. Аккаунт заблокирован на 24 часа.";
                        error_log("Login failed: $login exceeded max captcha attempts.");
                    } else {
                        $remaining_attempts = $max_captcha_attempts - $failed_captcha_attempts;
                        $error_message = "Неверно собран пазл. Осталось попыток: $remaining_attempts";
                        error_log("Login failed: Incorrect puzzle for $login.");
                    }
                    
                    // Сбрасываем капчу при ошибке
                    unset($_SESSION['puzzle_correct_order']);
                    unset($_SESSION['puzzle_current_order']);
                    $captcha_data = generatePuzzleCaptcha();
                } else {
                    // Капча пройдена, продолжаем проверку логина и пароля
                    $failed_attempts = getFailedAttempts($login, $conn);
                    
                    if ($failed_attempts >= $max_attempts) {
                        banUser($login, $conn, 'login');
                        $error_message = "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
                        error_log("Login failed: $login exceeded max login attempts.");
                    } else {
                        $login_escaped = $conn->real_escape_string($login);
                        $result = $conn->query("SELECT admin_id, login, password_hash FROM admins WHERE login = '$login_escaped'");
                        if ($result && $result->num_rows === 1) {
                            $admin = $result->fetch_assoc();
                            
                            if (verifyPassword($password, $admin['password_hash'])) {
                                // Успешный вход - очищаем все неудачные попытки
                                $conn->query("DELETE FROM failed_logins WHERE login = '$login_escaped'");
                                $conn->query("DELETE FROM failed_captcha_attempts WHERE login = '$login_escaped'");
                                $_SESSION['admin_login'] = $admin['login'];
                                $_SESSION['admin_id'] = $admin['admin_id'];
                                // Очищаем капчу после успешного входа
                                unset($_SESSION['puzzle_correct_order']);
                                unset($_SESSION['puzzle_current_order']);
                                header("Location: index.php");
                                exit();
                            } else {
                                addFailedAttempt($login, $conn);
                                $remaining_attempts = $max_attempts - ($failed_attempts + 1);
                                $error_message = $remaining_attempts > 0 
                                    ? "Неверный логин или пароль. Осталось попыток: $remaining_attempts"
                                    : "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
                                error_log("Login failed: Incorrect password for $login.");
                                // Сбрасываем капчу при ошибке пароля
                                unset($_SESSION['puzzle_correct_order']);
                                unset($_SESSION['puzzle_current_order']);
                                $captcha_data = generatePuzzleCaptcha();
                            }
                        } else {
                            addFailedAttempt($login, $conn);
                            $error_message = "Неверный логин или пароль.";
                            error_log("Login failed: $login not found.");
                            // Сбрасываем капчу при ошибке логина
                            unset($_SESSION['puzzle_correct_order']);
                            unset($_SESSION['puzzle_current_order']);
                            $captcha_data = generatePuzzleCaptcha();
                        }
                    }
                }
            }
        }
    } catch (Exception $e) {
        $error_message = "Ошибка входа: " . $e->getMessage();
        error_log("Login exception: " . $e->getMessage());
    }
}

function getEmoji($tableName) {
    switch ($tableName) {
        case 'admins': return '👤';
        case 'briefs': return '📄';
        case 'campaigns': return '📢';
        case 'clients': return '👥';
        case 'creatives': return '🎨';
        case 'interactions': return '💬';
        case 'logistics': return '🚚';
        case 'materials': return '🛠️';
        case 'orders': return '🛒';
        case 'registration': return '📝';
        case 'reports': return '📊';
        case 'suppliers': return '🤝';
        case 'failed_logins': return '🚫';
        case 'failed_captcha_attempts': return '🧩';
        case 'banned_users': return '⛔';
        default: return '📁';
    }
}

// Получаем список таблиц для отображения
$tables_list = getTableList($conn);
if (empty($tables_list)) {
    $export_error = "Ошибка: Не удалось получить список таблиц.";
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления БД</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <?php if (isset($_SESSION['admin_login'])): ?>
            <div class="sidebar">
                <div class="table-list">
                    <?php
                    foreach ($tables_list as $table_name) {
                        $emoji = getEmoji($table_name);
                        echo "<a href='table_view.php?table=" . urlencode($table_name) . "' class='table-item'>{$emoji} " . htmlspecialchars($table_name) . "</a>";
                    }
                    ?>
                    <a href='admin_bans.php' class='table-item'>⛔ Управление блокировками</a>
                    <a href='analytics.php' class='table-item'>📊 Аналитика</a>
                </div>
            </div>
            <div class="main-content">
                <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
                <header>
                    <div class="header-content">
                        <h1>Панель управления базой данных</h1>
                        <p>Здравствуйте, <?php echo htmlspecialchars($_SESSION['admin_login']); ?>! Выберите таблицу или функцию для работы.</p>
                    </div>
                    <a href="logout.php" class="logout-btn">Выйти</a>
                </header>
                <main>
                    <!-- ЗАМЕНИТЕ блок SQL консоли на этот: -->
<div id="sql-query-panel" class="sql-query-panel">
    <h2>SQL-консоль</h2>
    <form method="post" action="index.php">
        <div class="form-group">
            <label for="sql_query">Введите SQL-запрос (только SELECT)</label>
            <textarea id="sql_query" name="sql_query" rows="5" placeholder="Введите ваш SQL запрос здесь..."><?php echo isset($_POST['sql_query']) ? htmlspecialchars($_POST['sql_query']) : ''; ?></textarea>
        </div>
        <?php if ($sql_error): ?>
            <p class="error"><?php echo htmlspecialchars($sql_error); ?></p>
        <?php endif; ?>
        <button type="submit" class="sql-execute-btn">Выполнить запрос</button>
    </form>
    <?php if ($sql_result): ?>
        <div class="compact-table-wrapper">
            <div class="table-scroll-container">
                <table class="compact-table">
                    <thead>
                        <tr>
                            <?php foreach (array_keys($sql_result[0]) as $column): ?>
                                <th><?php echo htmlspecialchars($column); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sql_result as $row): ?>
                            <tr>
                                <?php foreach ($row as $value): ?>
                                    <td><?php echo htmlspecialchars($value); ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

                    <!-- ЗАМЕНИТЕ старый блок мониторинга ресурсов на этот: -->
<div id="resource-monitor-panel" class="resource-monitor-panel">
    <h2>Состояние системы</h2>
    <div class="resource-grid">
        <div class="resource-card">
            <div class="resource-label">Загрузка ЦП</div>
            <div class="resource-value" id="cpu-usage">N/A</div>
        </div>
        <div class="resource-card">
            <div class="resource-label">Использование ОЗУ</div>
            <div class="resource-value" id="ram-usage">N/A</div>
        </div>
        <div class="resource-card">
            <div class="resource-label">Количество ядер ЦП</div>
            <div class="resource-value" id="cpu-cores">N/A</div>
        </div>
        <div class="resource-card">
            <div class="resource-label">Время работы</div>
            <div class="resource-value" id="uptime">N/A</div>
        </div>
    </div>
</div>
<!-- ЗАМЕНИТЕ старый блок экспорта на этот: -->
<div id="export-table-panel" class="export-backup-panel">
    <h2>Экспорт и Бэкап</h2>
    
    <div class="export-form">
        <form method="post" action="index.php">
            <input type="hidden" name="action" value="export_table">
            <div class="form-group">
                <label for="export_table">Экспорт таблицы в JSON</label>
                <select id="export_table" name="export_table" required>
                    <option value="">-- Выберите таблицу --</option>
                    <?php foreach ($tables_list as $table_name): ?>
                        <option value="<?php echo htmlspecialchars($table_name); ?>">
                            <?php echo htmlspecialchars($table_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($export_error): ?>
                <p class="error"><?php echo htmlspecialchars($export_error); ?></p>
            <?php endif; ?>
            <button type="submit" class="export-btn">
                📥 Экспортировать в JSON
            </button>
        </form>
    </div>
    
    <div class="export-form">
        <form method="post" action="create_backup.php">
            <input type="hidden" name="action" value="create_backup">
            <button type="submit" class="backup-btn">
                💾 Создать полный бэкап БД
            </button>
        </form>
    </div>
    
    <div class="tables-list">
        <h3>Доступные таблицы</h3>
        <div class="tables-grid">
            <?php foreach ($tables_list as $table_name): ?>
                <div class="table-item-list">
                    <?php echo getEmoji($table_name) . ' ' . htmlspecialchars($table_name); ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
                </main>
            </div>
        <?php else: ?>
            <div class="main-content">
                <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
                <div class="login-container" style="display: flex; max-width: 1000px;">
                    <div style="flex: 1; padding: 40px;">
                        <h2>Вход в панель управления</h2>
                        <form method="post" action="index.php">
                            <div class="form-group">
                                <label for="login">Логин</label>
                                <input type="text" id="login" name="login" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Пароль</label>
                                <input type="password" id="password" name="password" required>
                            </div>
                            
                            <!-- Капча-пазл -->
                            <div class="form-group">
                                <label>Капча: Соберите пазл в правильном порядке (перетащите элементы)</label>
                                
                                <div class="puzzle-instructions" style="margin-bottom: 15px; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 5px;">
                                    <p style="margin: 0; font-size: 0.9em; color: #7f8c8d;">💡 <strong>Как пройти:</strong> Перетащите элементы пазла в правильном порядке слева направо</p>
                                </div>
                                
                                <div class="puzzle-container" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 15px 0; padding: 15px; background: rgba(255,255,255,0.05); border-radius: 10px; max-width: 300px; margin-left: auto; margin-right: auto;">
    <?php foreach ($captcha_data['current_order'] as $position): ?>
        <div class="puzzle-piece" 
             data-piece="<?php echo $position; ?>" 
             style="cursor: grab; padding: 10px; border: 2px dashed #9b59b6; border-radius: 8px; background: rgba(255,255,255,0.8); transition: all 0.3s ease; user-select: none; display: flex; flex-direction: column; align-items: center; justify-content: center;">
            <img src="captcha-images/<?php echo $position; ?>.png" 
                 alt="Пазл <?php echo $position; ?>" 
                 style="max-width: 80px; height: auto; display: block;">
            <div style="text-align: center; margin-top: 5px; font-size: 0.8em; color: #7f8c8d;">Перетащи</div>
        </div>
    <?php endforeach; ?>
</div>
                                
                                <input type="hidden" name="puzzle_order" id="puzzle_order" value="<?php echo json_encode($captcha_data['current_order']); ?>">
                                
                                <div style="text-align: center; margin-top: 10px;">
                                    <button type="button" id="reset-puzzle" style="padding: 8px 15px; background: #e74c3c; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 0.9em;">
                                        🔄 Сбросить пазл
                                    </button>
                                    <button type="button" id="shuffle-puzzle" style="padding: 8px 15px; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 0.9em; margin-left: 10px;">
                                        🔀 Перемешать
                                    </button>
                                </div>
                            </div>
                            
                            <?php if ($error_message): ?>
                                <p class="error"><?php echo $error_message; ?></p>
                            <?php endif; ?>
                            <button type="submit" class="login-btn">Войти</button>
                        </form>
                    </div>
                    <div style="flex: 1; padding: 40px; background-color: rgba(236, 240, 241, 0.7); border-radius: 15px; text-align: center; transition: background-color 0.5s ease; box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);">
                        <h2>О системе</h2>
                        <p>Добро пожаловать в панель управления базой данных. Эта система предоставляет безопасный доступ к управлению данными, включая просмотр, редактирование и удаление записей. Используйте ваши учетные данные для входа.</p>
                        
                        <div style="margin-top: 30px; padding: 20px; background: rgba(255,255,255,0.5); border-radius: 10px;">
                            <h3>Инструкция по капче:</h3>
                            <p>Для входа необходимо собрать пазл. Перетащите элементы в правильном порядке (1-2-3-4).</p>
                            <p style="font-size: 0.9em; margin-top: 10px;">Используйте кнопки "Сбросить" или "Перемешать" если нужно начать заново.</p>
                        </div>
                        
                        <p style="margin-top: 20px; font-size: 0.9em; color: #2c3e50;">© 2025 Все права защищены</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script>
    const toggleButton = document.getElementById('theme-toggle');
    const body = document.body;

    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-theme');
    }

    toggleButton.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        if (body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    });

    const canvas = document.getElementById('stars-canvas');
    const ctx = canvas.getContext('2d');
    let stars = [];
    let numStars = 200;

    function initStars() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        stars = [];
        for (let i = 0; i < numStars; i++) {
            stars.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                radius: Math.random() * 1.5 + 0.5,
                speed: Math.random() * 0.5 + 0.2,
                opacity: Math.random() * 0.5 + 0.5
            });
        }
    }

    function drawStars() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
        for (let star of stars) {
            ctx.globalAlpha = star.opacity;
            ctx.beginPath();
            ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
            ctx.fill();
            star.y += star.speed;
            if (star.y > canvas.height) {
                star.y = -star.radius;
                star.x = Math.random() * canvas.width;
            }
        }
        ctx.globalAlpha = 1;
        requestAnimationFrame(drawStars);
    }

    initStars();
    drawStars();

    window.addEventListener('resize', initStars);

    function updateResourceMonitor() {
        const cpuUsageElement = document.getElementById('cpu-usage');
        const ramUsageElement = document.getElementById('ram-usage');
        const cpuCoresElement = document.getElementById('cpu-cores');
        const uptimeElement = document.getElementById('uptime');

        // Проверяем существование элементов (только для авторизованных пользователей)
        if (cpuUsageElement && ramUsageElement && cpuCoresElement && uptimeElement) {
            cpuCoresElement.textContent = navigator.hardwareConcurrency ? navigator.hardwareConcurrency : 'N/A';

            const simulateResourceData = () => {
                const cpuUsage = (Math.random() * 100).toFixed(1) + '%';
                const ramUsage = (Math.random() * 16).toFixed(1) + 'GB / 16GB';
                const uptimeSeconds = Math.floor(performance.now() / 1000);
                const hours = Math.floor(uptimeSeconds / 3600);
                const minutes = Math.floor((uptimeSeconds % 3600) / 60);
                const seconds = uptimeSeconds % 60;

                cpuUsageElement.textContent = cpuUsage;
                ramUsageElement.textContent = ramUsage;
                uptimeElement.textContent = `${hours}h ${minutes}m ${seconds}s`;
            };

            simulateResourceData();
            setTimeout(updateResourceMonitor, 2000);
        }
    }

    // Drag & Drop для пазла (только для страницы входа)
    function initializePuzzle() {
        const container = document.querySelector('.puzzle-container');
        const pieces = document.querySelectorAll('.puzzle-piece');
        
        // Проверяем, есть ли элементы пазла на странице
        if (container && pieces.length > 0) {
            pieces.forEach(piece => {
                piece.setAttribute('draggable', 'true');
                
                piece.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('text/plain', piece.dataset.piece);
                    piece.style.opacity = '0.5';
                    piece.style.cursor = 'grabbing';
                });
                
                piece.addEventListener('dragend', () => {
                    piece.style.opacity = '1';
                    piece.style.cursor = 'grab';
                });
                
                piece.addEventListener('dragover', (e) => {
                    e.preventDefault();
                });
                
                piece.addEventListener('drop', (e) => {
                    e.preventDefault();
                    const draggedPieceId = e.dataTransfer.getData('text/plain');
                    const draggedPiece = document.querySelector(`[data-piece="${draggedPieceId}"]`);
                    const targetPiece = e.target.closest('.puzzle-piece');
                    
                    if (targetPiece && draggedPiece !== targetPiece) {
                        swapPieces(draggedPiece, targetPiece);
                    }
                });
                
                // Touch events для мобильных устройств
                piece.addEventListener('touchstart', handleTouchStart, false);
                piece.addEventListener('touchmove', handleTouchMove, false);
                piece.addEventListener('touchend', handleTouchEnd, false);
            });
        }
    }

    let touchStartX, touchStartY, draggedPiece;

    function handleTouchStart(e) {
        draggedPiece = e.target.closest('.puzzle-piece');
        if (!draggedPiece) return;
        
        const touch = e.touches[0];
        touchStartX = touch.clientX;
        touchStartY = touch.clientY;
        draggedPiece.style.opacity = '0.5';
    }

    function handleTouchMove(e) {
        if (!draggedPiece) return;
        e.preventDefault();
        
        const touch = e.touches[0];
        const deltaX = touch.clientX - touchStartX;
        const deltaY = touch.clientY - touchStartY;
        
        draggedPiece.style.transform = `translate(${deltaX}px, ${deltaY}px)`;
    }

    function handleTouchEnd(e) {
        if (!draggedPiece) return;
        
        draggedPiece.style.opacity = '1';
        draggedPiece.style.transform = 'translate(0, 0)';
        
        const touch = e.changedTouches[0];
        const elements = document.elementsFromPoint(touch.clientX, touch.clientY);
        const targetPiece = elements.find(el => el.classList.contains('puzzle-piece') && el !== draggedPiece);
        
        if (targetPiece) {
            swapPieces(draggedPiece, targetPiece);
        }
        
        draggedPiece = null;
    }

    function swapPieces(piece1, piece2) {
        const container = piece1.parentNode;
        const piece1Index = Array.from(container.children).indexOf(piece1);
        const piece2Index = Array.from(container.children).indexOf(piece2);
        
        if (piece1Index < piece2Index) {
            container.insertBefore(piece2, piece1);
            container.insertBefore(piece1, container.children[piece2Index]);
        } else {
            container.insertBefore(piece1, piece2);
            container.insertBefore(piece2, container.children[piece1Index]);
        }
        
        updatePuzzleOrder();
    }

    function updatePuzzleOrder() {
        const pieces = document.querySelectorAll('.puzzle-piece');
        const currentOrder = Array.from(pieces).map(piece => parseInt(piece.dataset.piece));
        const puzzleOrderInput = document.getElementById('puzzle_order');
        
        if (puzzleOrderInput) {
            puzzleOrderInput.value = JSON.stringify(currentOrder);
        }
        
        // Визуальная обратная связь
        pieces.forEach((piece, index) => {
            piece.style.borderColor = '#9b59b6';
            piece.style.background = 'rgba(255,255,255,0.8)';
        });
    }

    function resetPuzzle() {
        const container = document.querySelector('.puzzle-container');
        if (!container) return;
        
        const pieces = Array.from(container.children);
        
        // Сортируем по data-piece
        pieces.sort((a, b) => parseInt(a.dataset.piece) - parseInt(b.dataset.piece));
        
        // Очищаем контейнер и добавляем отсортированные элементы
        container.innerHTML = '';
        pieces.forEach(piece => {
            container.appendChild(piece);
        });
        
        updatePuzzleOrder();
    }

    function shufflePuzzle() {
        const container = document.querySelector('.puzzle-container');
        if (!container) return;
        
        const pieces = Array.from(container.children);
        
        // Перемешиваем элементы
        for (let i = pieces.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            container.appendChild(pieces[j]);
        }
        
        updatePuzzleOrder();
    }

    // Инициализация при загрузке
    document.addEventListener('DOMContentLoaded', function() {
        console.log("DOM loaded, initializing...");
        
        // Инициализируем пазл (только если есть элементы пазла)
        initializePuzzle();
        
        // Обработчики кнопок пазла (только если кнопки существуют)
        const resetButton = document.getElementById('reset-puzzle');
        const shuffleButton = document.getElementById('shuffle-puzzle');
        
        if (resetButton) {
            resetButton.addEventListener('click', resetPuzzle);
        }
        
        if (shuffleButton) {
            shuffleButton.addEventListener('click', shufflePuzzle);
        }
        
        // Запускаем мониторинг ресурсов (только для авторизованных пользователей)
        updateResourceMonitor();
        
        console.log("Initialization complete");
    });
</script>
</body>
</html>
<?php ob_end_flush(); ?>
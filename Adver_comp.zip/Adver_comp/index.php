<?php
session_start();
include 'db.php';

$error_message = '';
$max_attempts = 3;
$ban_duration = 24 * 60 * 60; // 24 часа в секундах

// Функция для проверки блокировки пользователя
function isUserBanned($login, $conn) {
    $stmt = $conn->prepare("SELECT banned_until FROM banned_users WHERE login = ? AND (banned_until IS NULL OR banned_until > NOW())");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    $is_banned = $result->num_rows > 0;
    $stmt->close();
    return $is_banned;
}

// Функция для получения количества неудачных попыток за последний час
function getFailedAttempts($login, $conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) as attempts FROM failed_logins WHERE login = ? AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['attempts'];
}

// Функция для добавления неудачной попытки входа
function addFailedAttempt($login, $conn) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt = $conn->prepare("INSERT INTO failed_logins (login, ip_address) VALUES (?, ?)");
    $stmt->bind_param("ss", $login, $ip);
    $stmt->execute();
    $stmt->close();
}

// Функция для блокировки пользователя (альтернативная версия)
function banUser($login, $conn) {
    // Сначала удаляем старую запись если есть
    $conn->query("DELETE FROM banned_users WHERE login = '$login'");
    
    // Добавляем новую блокировку
    $banned_until = date('Y-m-d H:i:s', time() + 24 * 60 * 60);
    $reason = 'Превышено количество неудачных попыток входа';
    
    $sql = "INSERT INTO banned_users (login, banned_until, reason) VALUES ('$login', '$banned_until', '$reason')";
    
    if ($conn->query($sql)) {
        error_log("Пользователь $login заблокирован до $banned_until");
        return true;
    } else {
        error_log("Ошибка блокировки $login: " . $conn->error);
        return false;
    }
}

// Функция для разблокировки пользователя
function unbanUser($login, $conn) {
    $stmt = $conn->prepare("DELETE FROM banned_users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $stmt->close();
}

// Функция для хэширования пароля
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Функция для проверки пароля
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Обновление паролей в базе данных (выполнить один раз)
function updatePasswordsToHashed($conn) {
    $passwords_to_update = [
        'Dimitrinev' => 'Blitzo14',
        'maria.petрова' => 'hashed_pass2',
        'alexey.sidorov' => 'hashed_pass3',
        'olga.kuznetsova' => 'hashed_pass4',
        'dmitry.morozov' => 'hashed_pass5',
        'elena.ivanova' => 'hashed_pass6',
        'sergey.petrov' => 'hashed_pass7',
        'natalya.smirnova' => 'hashed_pass8',
        'andrey.nikolaev' => 'hashed_pass9',
        'anna.kozlova' => 'hashed_pass10',
        'viktor.lebedev' => 'hashed_pass11',
        'tatiana.vasilieva' => 'hashed_pass12',
        'pavel.fedorov' => 'hashed_pass13',
        'yulia.mikhailova' => 'hashed_pass14',
        'konstantin.orlov' => 'hashed_pass15'
    ];
    
    foreach ($passwords_to_update as $login => $password) {
        $hashed_password = hashPassword($password);
        $stmt = $conn->prepare("UPDATE admins SET password_hash = ? WHERE login = ?");
        $stmt->bind_param("ss", $hashed_password, $login);
        if ($stmt->execute()) {
            echo "Пароль для $login обновлен<br>";
        } else {
            echo "Ошибка обновления пароля для $login: " . $conn->error . "<br>";
        }
        $stmt->close();
    }
}

// Раскомментировать следующую строку для однократного обновления паролей в базе данных:
//updatePasswordsToHashed($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = trim($_POST['login']);
    $password = $_POST['password'];

    // Проверяем, не заблокирован ли пользователь
    if (isUserBanned($login, $conn)) {
        $error_message = "Аккаунт временно заблокирован. Попробуйте позже или обратитесь к администратору.";
    } else {
        // Проверяем количество неудачных попыток
        $failed_attempts = getFailedAttempts($login, $conn);
        
        if ($failed_attempts >= $max_attempts) {
            banUser($login, $conn);
            $error_message = "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
        } else {
            $stmt = $conn->prepare("SELECT admin_id, login, password_hash FROM admins WHERE login = ?");
            $stmt->bind_param("s", $login);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $admin = $result->fetch_assoc();
                
                // Проверяем пароль с помощью password_verify
                if (verifyPassword($password, $admin['password_hash'])) {
                    // Успешный вход - очищаем неудачные попытки
                    $delete_stmt = $conn->prepare("DELETE FROM failed_logins WHERE login = ?");
                    $delete_stmt->bind_param("s", $login);
                    $delete_stmt->execute();
                    $delete_stmt->close();
                    
                    $_SESSION['admin_login'] = $admin['login'];
                    $_SESSION['admin_id'] = $admin['admin_id'];
                    header("Location: index.php");
                    exit();
                } else {
                    // Неверный пароль - добавляем неудачную попытку
                    addFailedAttempt($login, $conn);
                    $remaining_attempts = $max_attempts - ($failed_attempts + 1);
                    
                    if ($remaining_attempts > 0) {
                        $error_message = "Неверный логин или пароль. Осталось попыток: " . $remaining_attempts;
                    } else {
                        $error_message = "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
                    }
                }
            } else {
                // Пользователь не найден - добавляем неудачную попытку
                addFailedAttempt($login, $conn);
                $error_message = "Неверный логин или пароль.";
            }
            $stmt->close();
        }
    }
}

function getEmoji($tableName) {
    switch ($tableName) {
        case 'admins': return '👤';
        case 'briefs': return '📄';
        case 'campaigns': return '📢';
        case 'clients': return '👥';
        case 'creatives': return '🎨';
        case 'interactions': return '💬';
        case 'logistics': return '🚚';
        case 'materials': return '🛠️';
        case 'orders': return '🛒';
        case 'registration': return '📝';
        case 'reports': return '📊';
        case 'suppliers': return '🤝';
        case 'failed_logins': return '🚫';
        case 'banned_users': return '⛔';
        default: return '📁';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления БД</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <?php if (isset($_SESSION['admin_login'])): ?>
            <div class="sidebar">
                <div class="table-list">
                    <?php
                    $result = $conn->query("SHOW TABLES");
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_array()) {
                            $emoji = getEmoji($row[0]);
                            echo "<a href='table_view.php?table=" . $row[0] . "' class='table-item'>{$emoji} " . $row[0] . "</a>";
                        }
                    }
                    ?>
                    <!-- Добавляем ссылку на управление блокировками -->
                    <a href='admin_bans.php' class='table-item'>⛔ Управление блокировками</a>
                </div>
            </div>
            <div class="main-content">
                <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
                <header>
                    <div class="header-content">
                        <h1>Панель управления базой данных</h1>
                        <p>Здравствуйте, <?php echo htmlspecialchars($_SESSION['admin_login']); ?>! Выберите таблицу для работы.</p>
                    </div>
                    <a href="logout.php" class="logout-btn">Выйти</a>
                </header>
                <main>
                    <p>Выберите таблицу из списка слева.</p>
                </main>
            </div>
        <?php else: ?>
            <div class="main-content">
                <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
                <div class="login-container">
                    <h2>Вход в панель управления</h2>
                    <form method="post" action="index.php">
                        <div class="form-group">
                            <label for="login">Логин</label>
                            <input type="text" id="login" name="login" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Пароль</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <?php if ($error_message): ?>
                            <p class="error"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                        <button type="submit" class="login-btn">Войти</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script>
        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(ddrawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
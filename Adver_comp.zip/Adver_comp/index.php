<?php
// Enable error logging for debugging (remove in production)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

// Start output buffering
ob_start();
session_start();
include 'db.php';

$error_message = '';
$export_error = '';
$max_attempts = 3;
$max_captcha_attempts = 3;
$ban_duration = 24 * 60 * 60;

function isUserBanned($login, $conn) {
    $login = $conn->real_escape_string($login);
    
    // Сначала проверяем существование колонки ban_type
    $check_column = $conn->query("SHOW COLUMNS FROM banned_users LIKE 'ban_type'");
    if ($check_column->num_rows > 0) {
        // Колонка существует, используем новый запрос
        $result = $conn->query("SELECT banned_until, ban_type FROM banned_users WHERE login = '$login' AND (banned_until IS NULL OR banned_until > NOW())");
    } else {
        // Колонки нет, используем старый запрос
        $result = $conn->query("SELECT banned_until FROM banned_users WHERE login = '$login' AND (banned_until IS NULL OR banned_until > NOW())");
    }
    
    if ($result === false) {
        error_log("isUserBanned error: " . $conn->error);
        return false;
    }
    $is_banned = $result->num_rows > 0;
    return $is_banned;
}

// Функция для получения количества неудачных попыток за последний час
function getFailedAttempts($login, $conn) {
    $login = $conn->real_escape_string($login);
    $result = $conn->query("SELECT COUNT(*) as attempts FROM failed_logins WHERE login = '$login' AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    if ($result === false) {
        error_log("getFailedAttempts error: " . $conn->error);
        return 0;
    }
    $row = $result->fetch_assoc();
    return $row['attempts'];
}

// Функция для получения количества неудачных попыток капчи за последний час
function getFailedCaptchaAttempts($login, $conn) {
    $login = $conn->real_escape_string($login);
    $result = $conn->query("SELECT COUNT(*) as attempts FROM failed_captcha_attempts WHERE login = '$login' AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    if ($result === false) {
        error_log("getFailedCaptchaAttempts error: " . $conn->error);
        return 0;
    }
    $row = $result->fetch_assoc();
    return $row['attempts'];
}

// Функция для добавления неудачной попытки входа
function addFailedAttempt($login, $conn) {
    $ip = $conn->real_escape_string($_SERVER['REMOTE_ADDR']);
    $login = $conn->real_escape_string($login);
    $result = $conn->query("INSERT INTO failed_logins (login, ip_address) VALUES ('$login', '$ip')");
    if ($result === false) {
        error_log("addFailedAttempt error: " . $conn->error);
    }
}

// Функция для добавления неудачной попытки капчи
function addFailedCaptchaAttempt($login, $conn) {
    $ip = $conn->real_escape_string($_SERVER['REMOTE_ADDR']);
    $login = $conn->real_escape_string($login);
    $result = $conn->query("INSERT INTO failed_captcha_attempts (login, ip_address) VALUES ('$login', '$ip')");
    if ($result === false) {
        error_log("addFailedCaptchaAttempt error: " . $conn->error);
    }
}

// Функция для блокировки пользователя
function banUser($login, $conn, $ban_type = 'login') {
    $login = $conn->real_escape_string($login);
    $conn->query("DELETE FROM banned_users WHERE login = '$login'");
    $banned_until = date('Y-m-d H:i:s', time() + 24 * 60 * 60);
    $reason = $conn->real_escape_string($ban_type == 'captcha' ? 'Превышено количество неудачных попыток ввода капчи' : 'Превышено количество неудачных попыток входа');
    $sql = "INSERT INTO banned_users (login, banned_until, reason, ban_type) VALUES ('$login', '$banned_until', '$reason', '$ban_type')";
    if ($conn->query($sql)) {
        error_log("Пользователь $login заблокирован до $banned_until по причине: $ban_type");
        return true;
    } else {
        error_log("Ошибка блокировки $login: " . $conn->error);
        return false;
    }
}

// Функция для разблокировки пользователя
function unbanUser($login, $conn) {
    $login = $conn->real_escape_string($login);
    $result = $conn->query("DELETE FROM banned_users WHERE login = '$login'");
    if ($result === false) {
        error_log("unbanUser error: " . $conn->error);
    }
}

// Функция для хэширования пароля
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Функция для проверки пароля
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Функция для экранирования данных для CSV
function escapeCSV($value) {
    if (is_null($value)) {
        return '';
    }
    if (strpos($value, ',') !== false || strpos($value, '"') !== false || strpos($value, "\n") !== false) {
        return '"' . str_replace('"', '""', $value) . '"';
    }
    return $value;
}

// Получение списка таблиц для валидации
function getTableList($conn) {
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    } else {
        error_log("Failed to fetch table list: " . $conn->error);
    }
    return $tables;
}

// Генерация капчи с пазлом
function generatePuzzleCaptcha() {
    $images = ['1.png', '2.png', '3.png', '4.png'];
    $puzzle_order = [1, 2, 3, 4];
    shuffle($puzzle_order); // Перемешиваем порядок пазлов
    
    $_SESSION['puzzle_correct_order'] = [1, 2, 3, 4]; // Правильный порядок
    $_SESSION['puzzle_current_order'] = $puzzle_order; // Текущий перемешанный порядок
    
    return [
        'images' => $images,
        'current_order' => $puzzle_order,
        'correct_order' => [1, 2, 3, 4]
    ];
}

// Функция для получения данных из эмулятора
function getRandomFIOFromEmulator() {
    $emulator_urls = [
        'http://localhost:4444/TransferSimulator/fullName',
        'http://prb.sylas.ru/TransferSimulator/fullName'
    ];
    
    foreach ($emulator_urls as $url) {
        try {
            $response = file_get_contents($url);
            if ($response !== false) {
                $data = json_decode($response, true);
                if (isset($data['value'])) {
                    return $data['value'];
                }
            }
        } catch (Exception $e) {
            error_log("Error accessing emulator at $url: " . $e->getMessage());
            continue;
        }
    }
    return false;
}

// Обработка запроса к эмулятору и фильтрации
$emulator_data = null;
$filtered_clients = [];
$filter_error = '';
$current_filter = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] === 'emulator_search') {
    try {
        $filter_type = $_POST['filter_type'] ?? 'all';
        $current_filter = $filter_type;
        
        // Получаем случайное ФИО из эмулятора
        $random_fio = getRandomFIOFromEmulator();
        
        if ($random_fio === false) {
            $filter_error = "Не удалось получить данные от эмулятора. Проверьте, запущен ли эмулятор.";
        } else {
            $emulator_data = $random_fio;
            
            // Разбиваем ФИО на составляющие
            $fio_parts = explode(' ', $random_fio);
            $last_name = $fio_parts[0] ?? '';
            $first_name = $fio_parts[1] ?? '';
            $middle_name = $fio_parts[2] ?? '';
            
            // Формируем SQL запрос в зависимости от фильтра
            $query = "SELECT * FROM clients WHERE 1=1";
            
            switch ($filter_type) {
                case 'last_name':
                    $query .= " AND full_name LIKE ?";
                    $param = "%$last_name%";
                    break;
                    
                case 'first_name':
                    $query .= " AND full_name LIKE ?";
                    $param = "%$first_name%";
                    break;
                    
                case 'industry':
                    $industry_filter = $_POST['industry_filter'] ?? '';
                    if (!empty($industry_filter)) {
                        $query .= " AND industry = ?";
                        $param = $industry_filter;
                    }
                    break;
                    
                case 'all':
                default:
                    // Для "всех критериев" ищем по всем частям ФИО
                    $query .= " AND (full_name LIKE ? OR full_name LIKE ? OR full_name LIKE ?)";
                    $params = ["%$last_name%", "%$first_name%", "%$middle_name%"];
                    break;
            }
            
            // Подготавливаем и выполняем запрос
            $stmt = $conn->prepare($query);
            
            if ($filter_type === 'all') {
                $stmt->bind_param('sss', ...$params);
            } elseif ($filter_type !== 'industry' || !empty($industry_filter)) {
                $stmt->bind_param('s', $param);
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            $filtered_clients = $result->fetch_all(MYSQLI_ASSOC);
            
            if (empty($filtered_clients)) {
                $filter_error = "По выбранным критериям клиенты не найдены.";
            }
        }
    } catch (Exception $e) {
        $filter_error = "Ошибка при выполнении поиска: " . $e->getMessage();
        error_log("Emulator search error: " . $e->getMessage());
    }
}

// Получаем список уникальных индустрий для фильтра
$industries = [];
$industry_result = $conn->query("SELECT DISTINCT industry FROM clients WHERE industry IS NOT NULL AND industry != '' ORDER BY industry");
if ($industry_result) {
    $industries = $industry_result->fetch_all(MYSQLI_ASSOC);
}


// Получаем или генерируем капчу-пазл
if (!isset($_SESSION['puzzle_current_order'])) {
    $captcha_data = generatePuzzleCaptcha();
} else {
    // ВСЕГДА генерируем новую капчу при загрузке страницы
$captcha_data = generatePuzzleCaptcha();
}

// Улучшенная функция для проверки валидности ФИО (без изменений данных)
function isValidFIO($fio) {
    $reasons = [];
    
    // Проверка на пустоту
    if (empty(trim($fio))) {
        return ['valid' => false, 'reason' => 'ФИО не может быть пустым'];
    }
    
    // Проверка длины (не более 100 символов)
    $length = mb_strlen(trim($fio));
    if ($length > 100) {
        $reasons[] = "Превышена максимальная длина (100 символов)";
    }
    if ($length < 5) {
        $reasons[] = "Слишком короткое ФИО (менее 5 символов)";
    }
    
    // Проверка на наличие запрещенных символов
    $forbidden_chars = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '[', ']', 
                       '{', '}', ';', ':', '"', '\\', '|', ',', '.', '<', '>', '?', '~', '№', '`'];
    
    $found_chars = [];
    foreach ($forbidden_chars as $char) {
        if (strpos($fio, $char) !== false) {
            $found_chars[] = $char;
        }
    }
    
    if (!empty($found_chars)) {
        $reasons[] = "Обнаружены запрещенные символы: " . implode(', ', $found_chars);
    }
    
    // Проверка на цифры
    if (preg_match('/\d/', $fio)) {
        $reasons[] = "Обнаружены цифры";
    }
    
    // Проверка на некорректные скобки
    if (preg_match('/[\(\)\[\]\{\}]/', $fio)) {
        $reasons[] = "Обнаружены скобки";
    }
    
    // Проверка формата (должно быть 3 слова)
    $parts = explode(' ', trim($fio));
    if (count($parts) !== 3) {
        $reasons[] = "Должно состоять из трёх слов (Фамилия Имя Отчество)";
    } else {
        // Проверка что каждое слово начинается с заглавной буквы
        foreach ($parts as $part) {
            $trimmed_part = trim($part);
            if (mb_strlen($trimmed_part) < 2) {
                $reasons[] = "Каждое слово должно содержать минимум 2 символа";
                break;
            }
            
            $first_char = mb_substr($trimmed_part, 0, 1);
            if (mb_strtolower($first_char) === $first_char) {
                $reasons[] = "Каждое слово должно начинаться с заглавной буквы";
                break;
            }
        }
    }
    
    if (empty($reasons)) {
        return ['valid' => true, 'reason' => 'Соответствует всем критериям'];
    } else {
        return [
            'valid' => false, 
            'reason' => implode('; ', $reasons),
            'details' => $reasons
        ];
    }
}

// Функция для получения данных из эмулятора БЕЗ КАКОЙ-ЛИБО ОБРАБОТКИ
function getRawFIOFromEmulator() {
    $emulator_url = 'http://prb.sylas.ru/TransferSimulator/fullName';
    
    try {
        $context = stream_context_create([
            'http' => [
                'timeout' => 10,
                'ignore_errors' => true
            ]
        ]);
        
        $response = file_get_contents($emulator_url, false, $context);
        if ($response !== false) {
            $data = json_decode($response, true);
            if (isset($data['value'])) {
                // ВОЗВРАЩАЕМ ДАННЫЕ "КАК ЕСТЬ" БЕЗ ОБРАБОТКИ
                $raw_fio = $data['value'];
                
                // Проверяем валидность, но НЕ изменяем данные
                $validation_result = isValidFIO($raw_fio);
                
                return [
                    'value' => $raw_fio, // Возвращаем оригинальные данные
                    'valid' => $validation_result['valid'],
                    'reason' => $validation_result['reason'],
                    'details' => $validation_result['details'] ?? [],
                    'raw_data' => $raw_fio // Сохраняем оригинальные данные
                ];
            }
        }
    } catch (Exception $e) {
        error_log("Error accessing emulator: " . $e->getMessage());
    }
    
    return [
        'value' => false,
        'valid' => false,
        'error' => 'Не удалось получить данные от эмулятора',
        'reason' => 'Эмулятор недоступен или не возвращает данные'
    ];
}

// Обработка запроса к эмулятору
$emulator_data = null;
$validation_result = null;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] === 'check_emulator_data') {
    try {
        // Получаем данные из эмулятора БЕЗ обработки
        $emulator_data = getRawFIOFromEmulator();
        
        if (!$emulator_data['value']) {
            $filter_error = "Не удалось получить данные от эмулятора. " . 
                           ($emulator_data['error'] ?? "Проверьте, запущен ли эмулятор.");
        }
    } catch (Exception $e) {
        $filter_error = "Ошибка при проверке данных: " . $e->getMessage();
        error_log("Emulator check error: " . $e->getMessage());
    }
}

// Обработка экспорта таблицы в JSON
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] === 'export_table') {
    try {
        $table_name = trim($_POST['export_table']);
        $table_name = $conn->real_escape_string($table_name);
        $tables_list = getTableList($conn);
        
        // Проверка на существование таблицы
        if (!in_array($table_name, $tables_list)) {
            $export_error = "Таблица '$table_name' не существует.";
            error_log("Export failed: Table '$table_name' does not exist.");
        } else {
            // Получение данных таблицы
            $result = $conn->query("SELECT * FROM `$table_name`");
            if ($result === false) {
                $export_error = "Ошибка при получении данных таблицы: " . $conn->error;
                error_log("Export failed: " . $conn->error);
            } elseif ($result->num_rows === 0) {
                $export_error = "Таблица '$table_name' пуста.";
                error_log("Export failed: Table '$table_name' is empty.");
            } else {
                // Собираем данные в массив
                $json_data = array();
                while ($row = $result->fetch_assoc()) {
                    $json_data[] = $row;
                }
                
                // Преобразуем в JSON
                $json_output = json_encode($json_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                
                // Clear output buffer and send headers
                ob_end_clean();
                header('Content-Type: application/json; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $table_name . '_export_' . date('Y-m-d_H-i') . '.json"');
                header('Content-Length: ' . strlen($json_output));
                header('Cache-Control: no-cache, no-store, must-revalidate');
                header('Pragma: no-cache');
                header('Expires: 0');
                
                echo $json_output;
                exit();
            }
        }
    } catch (Exception $e) {
        $export_error = "Ошибка экспорта: " . $e->getMessage();
        error_log("Export exception: " . $e->getMessage());
    }
}

// Обработка SQL-запроса
$sql_result = null;
$sql_error = null;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sql_query'])) {
    try {
        $sql_query = trim($_POST['sql_query']);
        $restricted_commands = ['DROP', 'ALTER', 'DELETE', 'TRUNCATE', 'INSERT', 'UPDATE'];
        $query_upper = strtoupper($sql_query);
        $is_restricted = false;
        foreach ($restricted_commands as $command) {
            if (strpos($query_upper, $command) === 0) {
                $is_restricted = true;
                break;
            }
        }
        
        if ($is_restricted) {
            $sql_error = "Ошибка: Запрещено выполнение команд DROP, ALTER, DELETE, TRUNCATE, INSERT, UPDATE.";
            error_log("SQL query blocked: $sql_query");
        } else {
            if (stripos($sql_query, 'SELECT') === 0) {
                $result = $conn->query($sql_query);
                if ($result) {
                    $sql_result = $result->fetch_all(MYSQLI_ASSOC);
                } else {
                    $sql_error = "Ошибка выполнения запроса: " . $conn->error;
                    error_log("SQL query error: " . $conn->error);
                }
            } else {
                $sql_error = "Ошибка: Поддерживаются только SELECT-запросы.";
                error_log("Invalid SQL query: $sql_query");
            }
        }
    } catch (Exception $e) {
        $sql_error = "Ошибка SQL: " . $e->getMessage();
        error_log("SQL exception: " . $e->getMessage());
    }
}

// Обработка логина
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    try {
        $login = trim($_POST['login']);
        $password = $_POST['password'];

        // Проверка блокировки пользователя
        if (isUserBanned($login, $conn)) {
            $error_message = "Аккаунт временно заблокирован. Попробуйте позже или обратитесь к администратору.";
            error_log("Login failed: $login is banned.");
        } else {
            // Проверка капчи
            if (!isset($_POST['puzzle_order']) || empty($_POST['puzzle_order'])) {
                $error_message = "Пожалуйста, соберите пазл для входа.";
                error_log("Login failed: Puzzle not completed for $login.");
            } else {
                $submitted_order = json_decode($_POST['puzzle_order'], true);
                $correct_order = isset($_SESSION['puzzle_correct_order']) ? $_SESSION['puzzle_correct_order'] : null;
                
                if (json_encode($submitted_order) !== json_encode($correct_order)) {
                    // Неверная капча
                    addFailedCaptchaAttempt($login, $conn);
                    $failed_captcha_attempts = getFailedCaptchaAttempts($login, $conn);
                    
                    if ($failed_captcha_attempts >= $max_captcha_attempts) {
                        banUser($login, $conn, 'captcha');
                        $error_message = "Превышено количество неудачных попыток ввода капчи. Аккаунт заблокирован на 24 часа.";
                        error_log("Login failed: $login exceeded max captcha attempts.");
                    } else {
                        $remaining_attempts = $max_captcha_attempts - $failed_captcha_attempts;
                        $error_message = "Неверно собран пазл. Осталось попыток: $remaining_attempts";
                        error_log("Login failed: Incorrect puzzle for $login.");
                    }
                    
                    // Сбрасываем капчу при ошибке
                    unset($_SESSION['puzzle_correct_order']);
                    unset($_SESSION['puzzle_current_order']);
                    $captcha_data = generatePuzzleCaptcha();
                } else {
                    // Капча пройдена, продолжаем проверку логина и пароля
                    $failed_attempts = getFailedAttempts($login, $conn);
                    
                    if ($failed_attempts >= $max_attempts) {
                        banUser($login, $conn, 'login');
                        $error_message = "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
                        error_log("Login failed: $login exceeded max login attempts.");
                    } else {
                        $login_escaped = $conn->real_escape_string($login);
                        $result = $conn->query("SELECT admin_id, login, password_hash FROM admins WHERE login = '$login_escaped'");
                        if ($result && $result->num_rows === 1) {
                            $admin = $result->fetch_assoc();
                            
                            if (verifyPassword($password, $admin['password_hash'])) {
                                // Успешный вход - очищаем все неудачные попытки
                                $conn->query("DELETE FROM failed_logins WHERE login = '$login_escaped'");
                                $conn->query("DELETE FROM failed_captcha_attempts WHERE login = '$login_escaped'");
                                $_SESSION['admin_login'] = $admin['login'];
                                $_SESSION['admin_id'] = $admin['admin_id'];
                                // Очищаем капчу после успешного входа
                                unset($_SESSION['puzzle_correct_order']);
                                unset($_SESSION['puzzle_current_order']);
                                header("Location: index.php");
                                exit();
                            } else {
                                addFailedAttempt($login, $conn);
                                $remaining_attempts = $max_attempts - ($failed_attempts + 1);
                                $error_message = $remaining_attempts > 0 
                                    ? "Неверный логин или пароль. Осталось попыток: $remaining_attempts"
                                    : "Превышено количество попыток входа. Аккаунт заблокирован на 24 часа.";
                                error_log("Login failed: Incorrect password for $login.");
                                // Сбрасываем капчу при ошибке пароля
                                unset($_SESSION['puzzle_correct_order']);
                                unset($_SESSION['puzzle_current_order']);
                                $captcha_data = generatePuzzleCaptcha();
                            }
                        } else {
                            addFailedAttempt($login, $conn);
                            $error_message = "Неверный логин или пароль.";
                            error_log("Login failed: $login not found.");
                            // Сбрасываем капчу при ошибке логина
                            unset($_SESSION['puzzle_correct_order']);
                            unset($_SESSION['puzzle_current_order']);
                            $captcha_data = generatePuzzleCaptcha();
                        }
                    }
                }
            }
        }
    } catch (Exception $e) {
        $error_message = "Ошибка входа: " . $e->getMessage();
        error_log("Login exception: " . $e->getMessage());
    }
}

function getEmoji($tableName) {
    switch ($tableName) {
        case 'admins': return '👤';
        case 'briefs': return '📄';
        case 'campaigns': return '📢';
        case 'clients': return '👥';
        case 'creatives': return '🎨';
        case 'interactions': return '💬';
        case 'logistics': return '🚚';
        case 'materials': return '🛠️';
        case 'orders': return '🛒';
        case 'registration': return '📝';
        case 'reports': return '📊';
        case 'suppliers': return '🤝';
        case 'failed_logins': return '🚫';
        case 'failed_captcha_attempts': return '🧩';
        case 'banned_users': return '⛔';
        default: return '📁';
    }
}

// Получаем список таблиц для отображения
$tables_list = getTableList($conn);
if (empty($tables_list)) {
    $export_error = "Ошибка: Не удалось получить список таблиц.";
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления БД</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <?php if (isset($_SESSION['admin_login'])): ?>
            <div class="sidebar">
                <div class="table-list">
                    <?php
                    foreach ($tables_list as $table_name) {
                        $emoji = getEmoji($table_name);
                        echo "<a href='table_view.php?table=" . urlencode($table_name) . "' class='table-item'>{$emoji} " . htmlspecialchars($table_name) . "</a>";
                    }
                    ?>
                    <a href='admin_bans.php' class='table-item'>⛔ Управление блокировками</a>
                    <a href='analytics.php' class='table-item'>📊 Аналитика</a>
                </div>
            </div>
            <div class="main-content">
                <button id="theme-toggle" class="theme-toggle-btn" aria-label="Переключить тему">
    <span class="theme-icon">🌙</span>
</button>
                <header>
                    <div class="header-content">
                        <h1>Панель управления базой данных</h1>
                        <p>Здравствуйте, <?php echo htmlspecialchars($_SESSION['admin_login']); ?>! Выберите таблицу или функцию для работы.</p>
                    </div>
                    <a href="logout.php" class="logout-btn">Выйти</a>
                </header>
                <main>
                    <!-- ЗАМЕНИТЕ блок SQL консоли на этот: -->
<div id="sql-query-panel" class="sql-query-panel">
    <h2>SQL-консоль</h2>
    <form method="post" action="index.php">
        <div class="form-group">
            <label for="sql_query">Введите SQL-запрос (только SELECT)</label>
            <textarea id="sql_query" name="sql_query" rows="5" placeholder="Введите ваш SQL запрос здесь..."><?php echo isset($_POST['sql_query']) ? htmlspecialchars($_POST['sql_query']) : ''; ?></textarea>
        </div>
        <?php if ($sql_error): ?>
            <p class="error"><?php echo htmlspecialchars($sql_error); ?></p>
        <?php endif; ?>
        <button type="submit" class="sql-execute-btn">Выполнить запрос</button>
    </form>
    <?php if ($sql_result): ?>
        <div class="compact-table-wrapper">
            <div class="table-scroll-container">
                <table class="compact-table">
                    <thead>
                        <tr>
                            <?php foreach (array_keys($sql_result[0]) as $column): ?>
                                <th><?php echo htmlspecialchars($column); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sql_result as $row): ?>
                            <tr>
                                <?php foreach ($row as $value): ?>
                                    <td><?php echo htmlspecialchars($value); ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

                    <!-- ЗАМЕНИТЕ старый блок мониторинга ресурсов на этот: -->
<div id="resource-monitor-panel" class="resource-monitor-panel">
    <h2>Состояние системы</h2>
    <div class="resource-grid">
        <div class="resource-card">
            <div class="resource-label">Загрузка ЦП</div>
            <div class="resource-value" id="cpu-usage">N/A</div>
        </div>
        <div class="resource-card">
            <div class="resource-label">Использование ОЗУ</div>
            <div class="resource-value" id="ram-usage">N/A</div>
        </div>
        <div class="resource-card">
            <div class="resource-label">Количество ядер ЦП</div>
            <div class="resource-value" id="cpu-cores">N/A</div>
        </div>
        <div class="resource-card">
            <div class="resource-label">Время работы</div>
            <div class="resource-value" id="uptime">N/A</div>
        </div>
    </div>
</div>
<!-- ЗАМЕНИТЕ старый блок экспорта на этот: -->
<div id="export-table-panel" class="export-backup-panel">
    <h2>Экспорт и Бэкап</h2>
    
    <div class="export-form">
        <form method="post" action="index.php">
            <input type="hidden" name="action" value="export_table">
            <div class="form-group">
                <label for="export_table">Экспорт таблицы в JSON</label>
                <select id="export_table" name="export_table" required>
                    <option value="">-- Выберите таблицу --</option>
                    <?php foreach ($tables_list as $table_name): ?>
                        <option value="<?php echo htmlspecialchars($table_name); ?>">
                            <?php echo htmlspecialchars($table_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($export_error): ?>
                <p class="error"><?php echo htmlspecialchars($export_error); ?></p>
            <?php endif; ?>
            <button type="submit" class="export-btn">
                📥 Экспортировать в JSON
            </button>
        </form>
    </div>

    <div id="emulator-search-panel" class="emulator-search-panel glass-container">
    <h2>🔍 Проверка данных эмулятора</h2>
    
    <div class="emulator-info glass-container">
        <div class="info-content">
            <span class="info-icon">💡</span>
            <div>
                <strong>Как работает проверка:</strong>
                <p>Система запрашивает случайное ФИО из эмулятора и проверяет его на соответствие критериям валидности. Данные отображаются в оригинальном виде без обработки.</p>
            </div>
        </div>
    </div>
    
    <form method="post" action="index.php" class="emulator-form">
        <input type="hidden" name="action" value="check_emulator_data">
        
        <button type="submit" class="emulator-search-btn modern-btn" style="width: 100%; padding: 16px 24px; font-size: 1.1em;">
            <span class="btn-icon">🔍</span>
            Проверить данные эмулятора
        </button>
    </form>
    
    <?php if ($emulator_data): ?>
        <div class="validation-results" style="margin-top: 25px;">
            <div class="source-card">
                <div class="source-header">
                    <span class="source-icon">📋</span>
                    <h3>Результаты проверки</h3>
                </div>
                <div class="source-content">
                    <strong>Полученные данные:</strong>
                    <div class="fio-value" style="font-size: 1.2em; font-weight: bold; color: #e74c3c; margin: 10px 0; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                        "<?php echo htmlspecialchars($emulator_data['value']); ?>"
                    </div>
                    
                    <?php if ($emulator_data['valid']): ?>
                        <div class="validation-passed" style="background: rgba(76, 175, 80, 0.1); border-left: 3px solid #4caf50; padding: 15px; margin: 15px 0; border-radius: 4px;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                                <span style="font-size: 1.5em;">✅</span>
                                <strong style="font-size: 1.1em; color: #2e3333;">Валидация пройдена</strong>
                            </div>
                            <div style="color: #2e3333;"><?php echo $emulator_data['reason']; ?></div>
                        </div>
                    <?php else: ?>
                        <div class="validation-failed" style="background: rgba(244, 67, 54, 0.1); border-left: 3px solid #f44336; padding: 15px; margin: 15px 0; border-radius: 4px;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                                <span style="font-size: 1.5em;">❌</span>
                                <strong style="font-size: 1.1em; color: #2e3333;">Валидация не пройдена</strong>
                            </div>
                            <div style="color: #2e3333; margin-bottom: 10px;"><?php echo $emulator_data['reason']; ?></div>
                            
                            <?php if (isset($emulator_data['details']) && !empty($emulator_data['details'])): ?>
                                <div style="margin-top: 10px;">
                                    <strong style="color: #2e3333;">Детали ошибок:</strong>
                                    <?php foreach ($emulator_data['details'] as $detail): ?>
                                        <div style="font-size: 0.9em; margin: 5px 0; padding: 5px 10px; background: rgba(244, 67, 54, 0.1); border-radius: 4px;">
                                            • <?php echo htmlspecialchars($detail); ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
    
    <div class="export-form">
        <form method="post" action="create_backup.php">
            <input type="hidden" name="action" value="create_backup">
            <button type="submit" class="backup-btn">
                💾 Создать полный бэкап БД
            </button>
        </form>
    </div>
    
    <div class="tables-list">
        <h3>Доступные таблицы</h3>
        <div class="tables-grid">
            <?php foreach ($tables_list as $table_name): ?>
                <div class="table-item-list">
                    <?php echo getEmoji($table_name) . ' ' . htmlspecialchars($table_name); ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
                </main>
            </div>
        <?php else: ?>
    <div class="main-content">
        <button id="theme-toggle" class="theme-toggle-btn" aria-label="Переключить тему">
    <span class="theme-icon">🌙</span>
</button>
        
        <div class="login-page-container">
            <!-- Левая панель - форма входа -->
            <div class="login-form-panel glass-container">
                <div class="login-header">
                    <h2>Вход в панель управления</h2>
                    <p>Введите ваши учетные данные для доступа к системе</p>
                </div>
                
                <form method="post" action="index.php" class="auth-form">
                    <div class="form-group">
                        <label for="login" class="form-label">
                            <span class="label-icon">👤</span>
                            Логин
                        </label>
                        <input type="text" id="login" name="login" class="form-control modern-input" required placeholder="Введите ваш логин">
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="form-label">
                            <span class="label-icon">🔒</span>
                            Пароль
                        </label>
                        <input type="password" id="password" name="password" class="form-control modern-input" required placeholder="Введите ваш пароль">
                    </div>
                    
                    <!-- Капча-пазл -->
                    <div class="captcha-section">
                        <div class="form-group">
                            <label class="form-label">
                                <span class="label-icon">🧩</span>
                                Проверка безопасности
                            </label>
                            
                            <div class="puzzle-instructions glass-container">
                                <div class="instruction-content">
                                    <span class="instruction-icon">💡</span>
                                    <div>
                                        <strong>Как пройти капчу:</strong>
                                        <p>Перетащите элементы пазла в правильном порядке слева направо (1-2-3-4)</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="puzzle-container">
                                <?php foreach ($captcha_data['current_order'] as $position): ?>
                                    <div class="puzzle-piece" data-piece="<?php echo $position; ?>">
                                        <div class="puzzle-image">
                                            <img src="captcha-images/<?php echo $position; ?>.png" alt="Пазл <?php echo $position; ?>">
                                        </div>
                                        <div class="puzzle-hint">Перетащи меня</div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <input type="hidden" name="puzzle_order" id="puzzle_order" value="<?php echo json_encode($captcha_data['current_order']); ?>">
                            
                            <div class="puzzle-actions">
                                <button type="button" id="reset-puzzle" class="puzzle-btn puzzle-btn-reset">
                                    <span class="btn-icon">🔄</span>
                                    Сбросить
                                </button>
                                <button type="button" id="shuffle-puzzle" class="puzzle-btn puzzle-btn-shuffle">
                                    <span class="btn-icon">🔀</span>
                                    Перемешать
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <?php if ($error_message): ?>
                        <div class="error-message glass-container">
                            <span class="error-icon">⚠️</span>
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <button type="submit" class="login-btn modern-btn">
                        <span class="btn-icon">🚀</span>
                        Войти в систему
                    </button>
                </form>
            </div>
            
            <!-- Правая панель - информация о системе -->
            <div class="login-info-panel glass-container">
                <div class="info-header">
                    <h2>О системе</h2>
                    <div class="welcome-icon">👋</div>
                </div>
                
                <div class="info-content">
                    <p class="info-text">
                        Добро пожаловать в современную панель управления базой данных. 
                        Эта система предоставляет безопасный доступ к управлению данными, 
                        включая просмотр, редактирование и экспорт записей.
                    </p>
                    
                    <div class="features-list">
                        <div class="feature-item">
                            <span class="feature-icon">🛡️</span>
                            <div class="feature-text">
                                <strong>Безопасный доступ</strong>
                                <p>Многоуровневая система защиты</p>
                            </div>
                        </div>
                        
                        <div class="feature-item">
                            <span class="feature-icon">📊</span>
                            <div class="feature-text">
                                <strong>Управление данными</strong>
                                <p>Полный контроль над таблицами и записями</p>
                            </div>
                        </div>
                        
                        <div class="feature-item">
                            <span class="feature-icon">⚡</span>
                            <div class="feature-text">
                                <strong>SQL консоль</strong>
                                <p>Прямое выполнение запросов к базе</p>
                            </div>
                        </div>
                        
                        <div class="feature-item">
                            <span class="feature-icon">💾</span>
                            <div class="feature-text">
                                <strong>Экспорт данных</strong>
                                <p>Выгрузка в JSON и создание бэкапов</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="captcha-guide glass-container">
                        <h4>Инструкция по капче</h4>
                        <p>Для успешного входа необходимо собрать пазл в правильной последовательности:</p>
                        <ol>
                            <li>Перетащите элементы мышью или касанием</li>
                            <li>Расположите их в порядке 1-2-3-4</li>
                            <li>Используйте кнопки управления при необходимости</li>
                        </ol>
                    </div>
                </div>
                
                <div class="footer-info">
                    <p class="copyright">© 2025 Система управления БД. Все права защищены.</p>
                    <div class="tech-info">
                        <span>PHP • MySQL • JavaScript</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
    </div>
    <script>
    const toggleButton = document.getElementById('theme-toggle');
    const body = document.body;
    const themeIcon = toggleButton.querySelector('.theme-icon');

    // Функция для установки правильной иконки
    function updateThemeIcon() {
        if (body.classList.contains('dark-theme')) {
            themeIcon.textContent = '☀️'; // Солнце для темной темы
        } else {
            themeIcon.textContent = '🌙'; // Луна для светлой темы
        }
    }

    // Инициализация темы
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-theme');
    }

    // Обновляем иконку при загрузке
    updateThemeIcon();

    // Обработчик клика
    toggleButton.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        if (body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
        updateThemeIcon();
    });

    const canvas = document.getElementById('stars-canvas');
    const ctx = canvas.getContext('2d');
    let stars = [];
    let numStars = 200;

    function initStars() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        stars = [];
        for (let i = 0; i < numStars; i++) {
            stars.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                radius: Math.random() * 1.5 + 0.5,
                speed: Math.random() * 0.5 + 0.2,
                opacity: Math.random() * 0.5 + 0.5
            });
        }
    }

    function drawStars() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
        for (let star of stars) {
            ctx.globalAlpha = star.opacity;
            ctx.beginPath();
            ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
            ctx.fill();
            star.y += star.speed;
            if (star.y > canvas.height) {
                star.y = -star.radius;
                star.x = Math.random() * canvas.width;
            }
        }
        ctx.globalAlpha = 1;
        requestAnimationFrame(drawStars);
    }

    initStars();
    drawStars();

    window.addEventListener('resize', initStars);

    function updateResourceMonitor() {
        const cpuUsageElement = document.getElementById('cpu-usage');
        const ramUsageElement = document.getElementById('ram-usage');
        const cpuCoresElement = document.getElementById('cpu-cores');
        const uptimeElement = document.getElementById('uptime');

        // Проверяем существование элементов (только для авторизованных пользователей)
        if (cpuUsageElement && ramUsageElement && cpuCoresElement && uptimeElement) {
            cpuCoresElement.textContent = navigator.hardwareConcurrency ? navigator.hardwareConcurrency : 'N/A';

            const simulateResourceData = () => {
                const cpuUsage = (Math.random() * 100).toFixed(1) + '%';
                const ramUsage = (Math.random() * 16).toFixed(1) + 'GB / 16GB';
                const uptimeSeconds = Math.floor(performance.now() / 1000);
                const hours = Math.floor(uptimeSeconds / 3600);
                const minutes = Math.floor((uptimeSeconds % 3600) / 60);
                const seconds = uptimeSeconds % 60;

                cpuUsageElement.textContent = cpuUsage;
                ramUsageElement.textContent = ramUsage;
                uptimeElement.textContent = `${hours}h ${minutes}m ${seconds}s`;
            };

            simulateResourceData();
            setTimeout(updateResourceMonitor, 2000);
        }
    }


    // Drag & Drop для пазла (только для страницы входа)
    function initializePuzzle() {
        const container = document.querySelector('.puzzle-container');
        const pieces = document.querySelectorAll('.puzzle-piece');
        
        // Проверяем, есть ли элементы пазла на странице
        if (container && pieces.length > 0) {
            pieces.forEach(piece => {
                piece.setAttribute('draggable', 'true');
                
                piece.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('text/plain', piece.dataset.piece);
                    piece.style.opacity = '0.5';
                    piece.style.cursor = 'grabbing';
                });
                
                piece.addEventListener('dragend', () => {
                    piece.style.opacity = '1';
                    piece.style.cursor = 'grab';
                });
                
                piece.addEventListener('dragover', (e) => {
                    e.preventDefault();
                });
                
                piece.addEventListener('drop', (e) => {
                    e.preventDefault();
                    const draggedPieceId = e.dataTransfer.getData('text/plain');
                    const draggedPiece = document.querySelector(`[data-piece="${draggedPieceId}"]`);
                    const targetPiece = e.target.closest('.puzzle-piece');
                    
                    if (targetPiece && draggedPiece !== targetPiece) {
                        swapPieces(draggedPiece, targetPiece);
                    }
                });
                
                // Touch events для мобильных устройств
                piece.addEventListener('touchstart', handleTouchStart, false);
                piece.addEventListener('touchmove', handleTouchMove, false);
                piece.addEventListener('touchend', handleTouchEnd, false);
            });
        }
    }

    let touchStartX, touchStartY, draggedPiece;

    function handleTouchStart(e) {
        draggedPiece = e.target.closest('.puzzle-piece');
        if (!draggedPiece) return;
        
        const touch = e.touches[0];
        touchStartX = touch.clientX;
        touchStartY = touch.clientY;
        draggedPiece.style.opacity = '0.5';
    }

    function handleTouchMove(e) {
        if (!draggedPiece) return;
        e.preventDefault();
        
        const touch = e.touches[0];
        const deltaX = touch.clientX - touchStartX;
        const deltaY = touch.clientY - touchStartY;
        
        draggedPiece.style.transform = `translate(${deltaX}px, ${deltaY}px)`;
    }

    function handleTouchEnd(e) {
        if (!draggedPiece) return;
        
        draggedPiece.style.opacity = '1';
        draggedPiece.style.transform = 'translate(0, 0)';
        
        const touch = e.changedTouches[0];
        const elements = document.elementsFromPoint(touch.clientX, touch.clientY);
        const targetPiece = elements.find(el => el.classList.contains('puzzle-piece') && el !== draggedPiece);
        
        if (targetPiece) {
            swapPieces(draggedPiece, targetPiece);
        }
        
        draggedPiece = null;
    }

    function swapPieces(piece1, piece2) {
        const container = piece1.parentNode;
        const piece1Index = Array.from(container.children).indexOf(piece1);
        const piece2Index = Array.from(container.children).indexOf(piece2);
        
        if (piece1Index < piece2Index) {
            container.insertBefore(piece2, piece1);
            container.insertBefore(piece1, container.children[piece2Index]);
        } else {
            container.insertBefore(piece1, piece2);
            container.insertBefore(piece2, container.children[piece1Index]);
        }
        
        updatePuzzleOrder();
    }

    function updatePuzzleOrder() {
        const pieces = document.querySelectorAll('.puzzle-piece');
        const currentOrder = Array.from(pieces).map(piece => parseInt(piece.dataset.piece));
        const puzzleOrderInput = document.getElementById('puzzle_order');
        
        if (puzzleOrderInput) {
            puzzleOrderInput.value = JSON.stringify(currentOrder);
        }
        
        // Визуальная обратная связь
        pieces.forEach((piece, index) => {
            piece.style.borderColor = '#9b59b6';
            piece.style.background = 'rgba(255,255,255,0.8)';
        });
    }

    function resetPuzzle() {
        const container = document.querySelector('.puzzle-container');
        if (!container) return;
        
        const pieces = Array.from(container.children);
        
        // Сортируем по data-piece
        pieces.sort((a, b) => parseInt(a.dataset.piece) - parseInt(b.dataset.piece));
        
        // Очищаем контейнер и добавляем отсортированные элементы
        container.innerHTML = '';
        pieces.forEach(piece => {
            container.appendChild(piece);
        });
        
        updatePuzzleOrder();
    }

    function shufflePuzzle() {
        const container = document.querySelector('.puzzle-container');
        if (!container) return;
        
        const pieces = Array.from(container.children);
        
        // Перемешиваем элементы
        for (let i = pieces.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            container.appendChild(pieces[j]);
        }
        
        updatePuzzleOrder();
    }

    // Управление отображением поля фильтра индустрии
document.addEventListener('DOMContentLoaded', function() {
    const filterType = document.getElementById('filter_type');
    const industryGroup = document.getElementById('industry_filter_group');
    
    if (filterType && industryGroup) {
        // Обработчик изменения типа фильтра
        filterType.addEventListener('change', function() {
            if (this.value === 'industry') {
                industryGroup.style.display = 'block';
            } else {
                industryGroup.style.display = 'none';
            }
        });
        
        // Инициализация при загрузке
        if (filterType.value === 'industry') {
            industryGroup.style.display = 'block';
        }
    }
});

    // Инициализация при загрузке
    document.addEventListener('DOMContentLoaded', function() {
        console.log("DOM loaded, initializing...");
        
        // Инициализируем пазл (только если есть элементы пазла)
        initializePuzzle();
        
        // Обработчики кнопок пазла (только если кнопки существуют)
        const resetButton = document.getElementById('reset-puzzle');
        const shuffleButton = document.getElementById('shuffle-puzzle');
        
        if (resetButton) {
            resetButton.addEventListener('click', resetPuzzle);
        }
        
        if (shuffleButton) {
            shuffleButton.addEventListener('click', shufflePuzzle);
        }
        
        // Запускаем мониторинг ресурсов (только для авторизованных пользователей)
        updateResourceMonitor();
        
        console.log("Initialization complete");
    });
</script>
</body>
</html>
<?php ob_end_flush(); ?>
<?php
session_start();
include 'db.php';

// Проверяем авторизацию
if (!isset($_SESSION['admin_login'])) {
    die("Ошибка: Доступ запрещен. Необходима авторизация.");
}

// Получаем название таблицы из GET-параметра
$table_name = isset($_GET['table']) ? trim($_GET['table']) : '';

if (empty($table_name)) {
    die("Ошибка: Не указано название таблицы.");
}

// Проверка на существование таблицы
$stmt = $conn->prepare("SHOW TABLES LIKE ?");
$stmt->bind_param("s", $table_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Ошибка: Таблица '$table_name' не существует.");
}
$stmt->close();

// Получение данных таблицы
$result = $conn->query("SELECT * FROM `$table_name`");
if (!$result) {
    die("Ошибка при получении данных таблицы: " . $conn->error);
}

// Проверяем, есть ли данные
if ($result->num_rows === 0) {
    die("Таблица '$table_name' пуста.");
}

// Очищаем все буферы вывода
while (ob_get_level()) {
    ob_end_clean();
}

// Устанавливаем заголовки для скачивания JSON
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $table_name . '_export_' . date('Y-m-d_H-i') . '.json"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Собираем данные в массив
$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Выводим JSON
echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit();
?>
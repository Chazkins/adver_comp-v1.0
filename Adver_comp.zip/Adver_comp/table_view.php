<?php
session_start();
include 'db.php';
$table = $_GET['table'];

// Обработка удаления
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $primary_key_query = $conn->query("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
    $primary_key = $primary_key_query->fetch_assoc()['Column_name'];
    $conn->query("DELETE FROM `$table` WHERE `$primary_key` = $delete_id");
    header("Location: table_view.php?table=$table");
    exit();
}

// Обработка добавления новой записи
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_record'])) {
    $fields = $conn->query("SHOW COLUMNS FROM `$table`");
    $columns = [];
    $values = [];
    $placeholders = [];
    $types = '';
    
    foreach ($fields as $field) {
        if ($field['Extra'] !== 'auto_increment') { // Пропускаем автоинкрементные поля
            $field_name = $field['Field'];
            $columns[] = "`$field_name`";
            $values[] = $_POST[$field_name] ?? '';
            $placeholders[] = '?';
            
            // Определяем тип данных для привязки
            if (strpos($field['Type'], 'int') !== false) {
                $types .= 'i';
            } elseif (strpos($field['Type'], 'double') !== false || strpos($field['Type'], 'float') !== false) {
                $types .= 'd';
            } else {
                $types .= 's';
            }
        }
    }
    
    if (!empty($columns)) {
        $columns_str = implode(', ', $columns);
        $placeholders_str = implode(', ', $placeholders);
        $sql = "INSERT INTO `$table` ($columns_str) VALUES ($placeholders_str)";
        
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param($types, ...$values);
            if ($stmt->execute()) {
                header("Location: table_view.php?table=$table");
                exit();
            } else {
                $error_message = "Ошибка при добавлении записи: " . $conn->error;
            }
            $stmt->close();
        } else {
            $error_message = "Ошибка подготовки запроса: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр таблицы: <?php echo htmlspecialchars($table); ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
    
    <!-- Центрированная шапка -->
    <div class="centered-header">
        <div class="header-container">
            <a href="index.php" class="back-link">
                <span class="back-arrow">&larr;</span>
                К списку таблиц
            </a>
            <h1 class="table-title">Таблица: <?php echo htmlspecialchars($table); ?></h1>
        </div>
    </div>

    <!-- Компактный контейнер для таблицы и формы -->
    <div class="table-page-container">
        <!-- Таблица -->
        <div class="compact-table-wrapper">
            <div class="table-scroll-container">
                <table class="compact-table">
                    <thead>
                        <tr>
                            <?php
                            $result = $conn->query("SELECT * FROM `$table` LIMIT 1");
                            $fields = $result->fetch_fields();
                            foreach ($fields as $field) {
                                echo "<th>" . htmlspecialchars($field->name) . "</th>";
                            }
                            ?>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $data_result = $conn->query("SELECT * FROM `$table`");
                        if ($data_result->num_rows > 0) {
                             while($row = $data_result->fetch_assoc()) {
                                echo "<tr>";
                                foreach ($row as $cell) {
                                    echo "<td>" . htmlspecialchars($cell) . "</td>";
                                }
                                $primary_key_query = $conn->query("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
                                $primary_key = $primary_key_query->fetch_assoc()['Column_name'];
                                $id = $row[$primary_key];
                                echo "<td class='actions'>";
                                echo "<a href='#' class='edit-btn'>Редактировать</a>";
                                echo "<a href='table_view.php?table=$table&delete=$id' class='delete-btn' onclick='return confirmDelete();'>Удалить</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='" . (count($fields) + 1) . "'>В таблице нет данных.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Форма для добавления новой записи -->
        <div class="add-record-container">
            <h2>Добавить новую запись</h2>
            <?php if (isset($error_message)): ?>
                <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
            <?php endif; ?>
            <form method="post" action="table_view.php?table=<?php echo htmlspecialchars($table); ?>">
                <div class="form-fields-container">
                    <?php
                    $fields = $conn->query("SHOW COLUMNS FROM `$table`");
                    foreach ($fields as $field) {
                        if ($field['Extra'] !== 'auto_increment') { // Пропускаем автоинкрементные поля
                            $field_name = $field['Field'];
                            $field_type = $field['Type'];
                            echo "<div class='form-group'>";
                            echo "<label for='$field_name'>" . htmlspecialchars($field_name) . "</label>";
                            if (strpos($field_type, 'text') !== false || strpos($field_type, 'varchar') !== false) {
                                echo "<input type='text' id='$field_name' name='$field_name' required>";
                            } elseif (strpos($field_type, 'int') !== false) {
                                echo "<input type='number' id='$field_name' name='$field_name' required>";
                            } elseif (strpos($field_type, 'date') !== false) {
                                echo "<input type='date' id='$field_name' name='$field_name' required>";
                            } elseif (strpos($field_type, 'datetime') !== false) {
                                echo "<input type='datetime-local' id='$field_name' name='$field_name' required>";
                            } else {
                                echo "<input type='text' id='$field_name' name='$field_name' required>";
                            }
                            echo "</div>";
                        }
                    }
                    ?>
                </div>
                <button type="submit" name="add_record" class="add-btn">Добавить</button>
            </form>
        </div>
    </div>

    <script>
        function confirmDelete() {
            return confirm("Вы уверены, что хотите удалить эту запись?");
        }

        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
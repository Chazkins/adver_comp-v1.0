<?php
session_start();

function generatePuzzleCaptcha() {
    $images = ['1.png', '2.png', '3.png', '4.png'];
    $puzzle_order = [1, 2, 3, 4];
    shuffle($puzzle_order);
    
    $_SESSION['puzzle_correct_order'] = [1, 2, 3, 4];
    $_SESSION['puzzle_current_order'] = $puzzle_order;
    
    return $puzzle_order;
}

header('Content-Type: application/json');
$new_order = generatePuzzleCaptcha();
echo json_encode(['current_order' => $new_order]);
?>
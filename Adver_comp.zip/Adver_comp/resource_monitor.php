<?php
ob_start();
session_start();
include 'db.php';

// Проверка авторизации
if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мониторинг ресурсов</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
    
    <div class="centered-header">
        <div class="header-container">
            <a href="index.php" class="back-link">
                <span class="back-arrow">&larr;</span>
                На главную
            </a>
            <h1 class="table-title">Мониторинг ресурсов</h1>
        </div>
    </div>

    <div class="table-page-container">
        <div id="resource-monitor-panel" class="resource-monitor-panel">
            <h2>Состояние системы</h2>
            
            <div class="resource-item">
                <span>Загрузка ЦП:</span>
                <span id="cpu-usage">0%</span>
            </div>
            
            <div class="resource-item">
                <span>Использование ОЗУ:</span>
                <span id="ram-usage">0 GB / 0 GB</span>
            </div>
            
            <div class="resource-item">
                <span>Количество ядер ЦП:</span>
                <span id="cpu-cores">0</span>
            </div>
            
            <div class="resource-item">
                <span>Время работы:</span>
                <span id="uptime">0h 0m 0s</span>
            </div>
            
            <div class="resource-item">
                <span>Статус БД:</span>
                <span id="db-status" style="color: #2ecc71;">● Подключена</span>
            </div>
            
            <div class="resource-item">
                <span>Активные сессии:</span>
                <span id="active-sessions">1</span>
            </div>
        </div>
    </div>

    <script>
        // Функция для обновления мониторинга ресурсов
        function updateResourceMonitor() {
            console.log("Updating resource monitor...");
            
            // Обновляем время работы
            const uptimeElement = document.getElementById('uptime');
            if (uptimeElement) {
                const uptimeSeconds = Math.floor(performance.now() / 1000);
                const hours = Math.floor(uptimeSeconds / 3600);
                const minutes = Math.floor((uptimeSeconds % 3600) / 60);
                const seconds = uptimeSeconds % 60;
                uptimeElement.textContent = `${hours}h ${minutes}m ${seconds}s`;
            }
            
            // Обновляем количество ядер
            const cpuCoresElement = document.getElementById('cpu-cores');
            if (cpuCoresElement) {
                cpuCoresElement.textContent = navigator.hardwareConcurrency || 'Недоступно';
            }
            
            // Симулируем загрузку CPU
            const cpuUsageElement = document.getElementById('cpu-usage');
            if (cpuUsageElement) {
                const cpuLoad = Math.floor(Math.random() * 30) + 10; // 10-40%
                cpuUsageElement.textContent = cpuLoad + '%';
                cpuUsageElement.style.color = cpuLoad > 70 ? '#e74c3c' : cpuLoad > 50 ? '#f39c12' : '#2ecc71';
            }
            
            // Симулируем использование RAM
            const ramUsageElement = document.getElementById('ram-usage');
            if (ramUsageElement) {
                const usedRAM = (Math.random() * 4 + 2).toFixed(1); // 2-6 GB
                const totalRAM = '16.0';
                ramUsageElement.textContent = usedRAM + ' GB / ' + totalRAM + ' GB';
                
                const usagePercent = (usedRAM / totalRAM * 100);
                ramUsageElement.style.color = usagePercent > 80 ? '#e74c3c' : usagePercent > 60 ? '#f39c12' : '#2ecc71';
            }
            
            // Обновляем статус активных сессий
            const sessionsElement = document.getElementById('active-sessions');
            if (sessionsElement) {
                const sessions = Math.floor(Math.random() * 3) + 1; // 1-3 сессии
                sessionsElement.textContent = sessions;
            }
            
            console.log("Resource monitor updated successfully");
        }
        
        // Функция для инициализации звездного фона
        function initStars() {
            const canvas = document.getElementById('stars-canvas');
            if (!canvas) return;
            
            const ctx = canvas.getContext('2d');
            let stars = [];
            const numStars = 150;
            
            function resizeCanvas() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
                stars = [];
                
                for (let i = 0; i < numStars; i++) {
                    stars.push({
                        x: Math.random() * canvas.width,
                        y: Math.random() * canvas.height,
                        radius: Math.random() * 1.2 + 0.3,
                        speed: Math.random() * 0.3 + 0.1,
                        opacity: Math.random() * 0.5 + 0.3
                    });
                }
            }
            
            function drawStars() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                const isDark = document.body.classList.contains('dark-theme');
                ctx.fillStyle = isDark ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.5)';
                
                for (let star of stars) {
                    ctx.globalAlpha = star.opacity;
                    ctx.beginPath();
                    ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                    ctx.fill();
                    star.y += star.speed;
                    
                    if (star.y > canvas.height) {
                        star.y = 0;
                        star.x = Math.random() * canvas.width;
                    }
                }
                ctx.globalAlpha = 1;
                requestAnimationFrame(drawStars);
            }
            
            resizeCanvas();
            drawStars();
            window.addEventListener('resize', resizeCanvas);
        }
        
        // Функция для переключения темы
        function initThemeToggle() {
            const toggleButton = document.getElementById('theme-toggle');
            const body = document.body;
            
            // Восстанавливаем тему из localStorage
            if (localStorage.getItem('theme') === 'dark') {
                body.classList.add('dark-theme');
            }
            
            if (toggleButton) {
                toggleButton.addEventListener('click', () => {
                    body.classList.toggle('dark-theme');
                    localStorage.setItem('theme', body.classList.contains('dark-theme') ? 'dark' : 'light');
                });
            }
        }
        
        // Инициализация при загрузке страницы
        document.addEventListener('DOMContentLoaded', function() {
            console.log("DOM loaded, initializing resource monitor...");
            
            // Инициализируем компоненты
            initThemeToggle();
            initStars();
            
            // Сразу обновляем мониторинг
            updateResourceMonitor();
            
            // Запускаем периодическое обновление каждые 2 секунды
            setInterval(updateResourceMonitor, 2000);
            
            console.log("Resource monitor initialized successfully");
        });
        
        // Резервная инициализация если DOMContentLoaded уже сработал
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initThemeToggle);
        } else {
            initThemeToggle();
        }
    </script>
</body>
</html>
<?php ob_end_flush(); ?>
<?php
ob_start();
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мониторинг ресурсов</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
    
    <div class="centered-header">
        <div class="header-container">
            <a href="index.php" class="back-link">
                <span class="back-arrow">&larr;</span>
                На главную
            </a>
            <h1 class="table-title">Мониторинг ресурсов</h1>
        </div>
    </div>

    <div class="table-page-container">
        <div id="resource-monitor-panel" class="resource-monitor-panel">
            <h2>Состояние системы</h2>
            <div class="resource-item">
                <span>Загрузка ЦП:</span>
                <span id="cpu-usage">N/A</span>
            </div>
            <div class="resource-item">
                <span>Использование ОЗУ:</span>
                <span id="ram-usage">N/A</span>
            </div>
            <div class="resource-item">
                <span>Количество ядер ЦП:</span>
                <span id="cpu-cores">N/A</span>
            </div>
            <div class="resource-item">
                <span>Время работы:</span>
                <span id="uptime">N/A</span>
            </div>
        </div>
    </div>

    <script>
        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);

        function updateResourceMonitor() {
            const cpuUsageElement = document.getElementById('cpu-usage');
            const ramUsageElement = document.getElementById('ram-usage');
            const cpuCoresElement = document.getElementById('cpu-cores');
            const uptimeElement = document.getElementById('uptime');

            cpuCoresElement.textContent = navigator.hardwareConcurrency ? navigator.hardwareConcurrency : 'N/A';

            const simulateResourceData = () => {
                const cpuUsage = (Math.random() * 100).toFixed(1) + '%';
                const ramUsage = (Math.random() * 16).toFixed(1) + 'GB / 16GB';
                const uptimeSeconds = Math.floor(performance.now() / 1000);
                const hours = Math.floor(uptimeSeconds / 3600);
                const minutes = Math.floor((uptimeSeconds % 3600) / 60);
                const seconds = uptimeSeconds % 60;

                cpuUsageElement.textContent = cpuUsage;
                ramUsageElement.textContent = ramUsage;
                uptimeElement.textContent = `${hours}h ${minutes}m ${seconds}s`;
            };

            simulateResourceData();
            setTimeout(updateResourceMonitor, 2000);
        }

        updateResourceMonitor();
    </script>
</body>
</html>
<?php ob_end_flush(); ?>
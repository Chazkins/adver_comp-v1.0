<?php
// emulator_results.php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

session_start();
include 'db.php';

// Проверка авторизации
if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}

// Функция для получения случайного клиента из БД
function getRandomClientFromDB($conn) {
    $result = $conn->query("SELECT * FROM clients ORDER BY RAND() LIMIT 1");
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

// Функция для получения данных из эмулятора
function getRandomFIOFromEmulator() {
    $emulator_urls = [
        'http://localhost:4444/TransferSimulator/fullName',
        'http://prb.sylas.ru/TransferSimulator/fullName'
    ];
    
    foreach ($emulator_urls as $url) {
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 10,
                    'ignore_errors' => true
                ]
            ]);
            
            $response = file_get_contents($url, false, $context);
            if ($response !== false) {
                $data = json_decode($response, true);
                if (isset($data['value'])) {
                    return $data['value'];
                }
            }
        } catch (Exception $e) {
            error_log("Error accessing emulator at $url: " . $e->getMessage());
            continue;
        }
    }
    return false;
}

// Функция для проверки различий по роду фамилии (универсальная)
function isGenderVariant($name1, $name2) {
    $name1 = mb_strtolower(trim($name1));
    $name2 = mb_strtolower(trim($name2));
    
    // Если фамилии уже одинаковые - не вариант по роду
    if ($name1 === $name2) {
        return false;
    }
    
    // Минимальная длина фамилии для проверки
    if (mb_strlen($name1) < 3 || mb_strlen($name2) < 3) {
        return false;
    }
    
    // Основная проверка на различие по роду
    $last_char1 = mb_substr($name1, -1);
    $last_char2 = mb_substr($name2, -1);
    
    // Случай 1: name1 оканчивается на 'а', name2 - нет
    if ($last_char1 === 'а' && $last_char2 !== 'а') {
        $base1 = mb_substr($name1, 0, -1);
        return $base1 === $name2;
    }
    
    // Случай 2: name2 оканчивается на 'а', name1 - нет  
    if ($last_char1 !== 'а' && $last_char2 === 'а') {
        $base2 = mb_substr($name2, 0, -1);
        return $name1 === $base2;
    }
    
    return false;
}

// Функция для анализа соответствия данных
function analyzeMatch($emulator_data, $db_client_data, $filter_type) {
    $analysis = [
        'level' => 'unknown',
        'message' => '',
        'details' => []
    ];
    
    // Разбиваем ФИО на составляющие
    $emulator_parts = explode(' ', $emulator_data);
    $db_parts = explode(' ', $db_client_data['full_name']);
    
    $emulator_last_name = $emulator_parts[0] ?? '';
    $emulator_first_name = $emulator_parts[1] ?? '';
    $emulator_middle_name = $emulator_parts[2] ?? '';
    
    $db_last_name = $db_parts[0] ?? '';
    $db_first_name = $db_parts[1] ?? '';
    $db_middle_name = $db_parts[2] ?? '';
    
    switch ($filter_type) {
        case 'last_name':
            // Проверяем точное совпадение
            if (strcasecmp($emulator_last_name, $db_last_name) == 0) {
                $analysis['level'] = 'full';
                $analysis['message'] = 'Найденные данные полностью соответствуют критерию';
                $analysis['details'][] = "Фамилия совпадает: {$emulator_last_name}";
            } 
            // Проверяем различие по роду (Иванов/Иванова и т.д.)
            elseif (isGenderVariant($emulator_last_name, $db_last_name)) {
                $analysis['level'] = 'partial';
                $analysis['message'] = 'Данные частично соответствуют выбранному критерию';
                $analysis['details'][] = "Фамилия из эмулятора: {$emulator_last_name}";
                $analysis['details'][] = "Фамилия в базе: {$db_last_name}";
                $analysis['details'][] = "Рекомендация: Различие по роду фамилии (мужской/женский вариант)";
            }
            // Нет совпадения
            else {
                $analysis['level'] = 'partial';
                $analysis['message'] = 'Данные частично соответствуют выбранному критерию';
                $analysis['details'][] = "Фамилия из эмулятора: {$emulator_last_name}";
                $analysis['details'][] = "Фамилия в базе: {$db_last_name}";
                $analysis['details'][] = "Рекомендация: Проверить возможные опечатки или различные написания";
            }
            break;
            
        case 'first_name':
            if (strcasecmp($emulator_first_name, $db_first_name) == 0) {
                $analysis['level'] = 'full';
                $analysis['message'] = 'Найденные данные полностью соответствуют критерию';
                $analysis['details'][] = "Имя совпадает: {$emulator_first_name}";
            } else {
                $analysis['level'] = 'partial';
                $analysis['message'] = 'Данные частично соответствуют выбранному критерию';
                $analysis['details'][] = "Имя из эмулятора: {$emulator_first_name}";
                $analysis['details'][] = "Имя в базе: {$db_first_name}";
                $analysis['details'][] = "Примечание: Возможно использование сокращенных форм имени";
            }
            break;
            
        case 'industry':
            $analysis['level'] = 'info';
            $analysis['message'] = 'Сравнение по услугам выполнено успешно';
            $analysis['details'][] = "Индустрия клиента: {$db_client_data['industry']}";
            $analysis['details'][] = "Статус: Критерий фильтрации применен корректно";
            break;
            
        case 'all':
            $matches = 0;
            $total = 3;
            
            // Проверка фамилии с учетом различий по роду
            if (strcasecmp($emulator_last_name, $db_last_name) == 0) {
                $matches++;
            } elseif (isGenderVariant($emulator_last_name, $db_last_name)) {
                $matches += 0.7; // Частичное совпадение по фамилии (разные роды)
            }
            
            if (strcasecmp($emulator_first_name, $db_first_name) == 0) $matches++;
            if (strcasecmp($emulator_middle_name, $db_middle_name) == 0) $matches++;
            
            $match_percentage = ($matches / $total) * 100;
            
            if ($match_percentage >= 90) {
                $analysis['level'] = 'full';
                $analysis['message'] = 'Полное соответствие по всем критериям';
                $analysis['details'][] = "Совпадение: " . round($match_percentage, 1) . "%";
                $analysis['details'][] = "Все компоненты ФИО идентичны";
            } elseif ($match_percentage >= 60) {
                $analysis['level'] = 'high';
                $analysis['message'] = 'Высокое соответствие данных';
                $analysis['details'][] = "Совпадение: " . round($match_percentage, 1) . "%";
                $analysis['details'][] = "Большинство компонентов ФИО совпадают";
            } elseif ($match_percentage >= 30) {
                $analysis['level'] = 'partial';
                $analysis['message'] = 'Частичное соответствие данных';
                $analysis['details'][] = "Совпадение: " . round($match_percentage, 1) . "%";
                $analysis['details'][] = "Некоторые компоненты ФИО требуют проверки";
            } else {
                $analysis['level'] = 'low';
                $analysis['message'] = 'Низкое соответствие данных';
                $analysis['details'][] = "Совпадение: " . round($match_percentage, 1) . "%";
                $analysis['details'][] = "Рекомендуется дополнительная верификация";
            }
            break;
    }
    
    return $analysis;
}

// Обработка параметров
$filter_type = $_GET['filter_type'] ?? 'all';
$search_results = [];
$error_message = '';
$emulator_data = null;
$db_client_data = null;
$analysis_result = null;

try {
    // Получаем случайного клиента из БД
    $db_client_data = getRandomClientFromDB($conn);
    
    if (!$db_client_data) {
        $error_message = "Не удалось получить данные из базы данных.";
    } else {
        // Получаем данные из эмулятора
        $emulator_data = getRandomFIOFromEmulator();
        
        if (!$emulator_data) {
            $error_message = "Не удалось получить данные от эмулятора. Проверьте, запущен ли эмулятор.";
        } else {
            // Выполняем анализ соответствия
            $analysis_result = analyzeMatch($emulator_data, $db_client_data, $filter_type);
            
            // Разбиваем ФИО из эмулятора на составляющие
            $fio_parts = explode(' ', $emulator_data);
            $last_name_emulator = $fio_parts[0] ?? '';
            $first_name_emulator = $fio_parts[1] ?? '';
            $middle_name_emulator = $fio_parts[2] ?? '';
            
            // Формируем SQL запрос в зависимости от фильтра
            $query = "SELECT * FROM clients WHERE 1=1";
            $params = [];
            $types = '';
            
            switch ($filter_type) {
                case 'last_name':
                    $query .= " AND full_name LIKE ?";
                    $params[] = "%$last_name_emulator%";
                    $types .= 's';
                    break;
                    
                case 'first_name':
                    $query .= " AND full_name LIKE ?";
                    $params[] = "%$first_name_emulator%";
                    $types .= 's';
                    break;
                    
                case 'industry':
                    $industry_filter = $_GET['industry_filter'] ?? '';
                    if (!empty($industry_filter)) {
                        $query .= " AND industry = ?";
                        $params[] = $industry_filter;
                        $types .= 's';
                    }
                    break;
                    
                case 'all':
                default:
                    $query .= " AND (full_name LIKE ? OR full_name LIKE ? OR full_name LIKE ?)";
                    $params = ["%$last_name_emulator%", "%$first_name_emulator%", "%$middle_name_emulator%"];
                    $types = 'sss';
                    break;
            }
            
            // Выполняем поиск
            $stmt = $conn->prepare($query);
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            $search_results = $result->fetch_all(MYSQLI_ASSOC);
            
            if (empty($search_results)) {
                $error_message = "По выбранным критериям клиенты не найдены.";
            }
        }
    }
} catch (Exception $e) {
    $error_message = "Ошибка при выполнении поиска: " . $e->getMessage();
    error_log("Emulator search error: " . $e->getMessage());
}

// Получаем список уникальных индустрий
$industries = [];
$industry_result = $conn->query("SELECT DISTINCT industry FROM clients WHERE industry IS NOT NULL AND industry != '' ORDER BY industry");
if ($industry_result) {
    $industries = $industry_result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Результаты поиска через эмулятор</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <div class="main-content">
          <button id="theme-toggle" class="theme-toggle-btn" aria-label="Переключить тему">
    <span class="theme-icon">🌙</span>
</button>
            <header>
                <div class="header-content">
                    <h1>Результаты поиска через эмулятор</h1>
                    <p>Результаты вашего запроса</p>
                </div>
                <a href="index.php" class="logout-btn">Вернуться</a>
            </header>
            <main>
                <div id="emulator-results-panel" class="emulator-results-panel glass-container">
                    <?php if ($error_message): ?>
                        <div class="error-message glass-container">
                            <span class="error-icon">⚠️</span>
                            <?php echo $error_message; ?>
                        </div>
                    <?php elseif ($emulator_data && $db_client_data): ?>
                        <div class="data-sources">
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🎰</span>
                                    <h3>Данные из эмулятора</h3>
                                </div>
                                <div class="source-content">
                                    <strong>ФИО:</strong>
                                    <span class="fio-value">"<?php echo htmlspecialchars($emulator_data); ?>"</span>
                                </div>
                            </div>
                            
                            <!-- Блок анализа соответствия -->
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🔍</span>
                                    <h3>Анализ соответствия</h3>
                                </div>
                                <div class="source-content">
                                    <strong>Статус:</strong>
                                    <span class="analysis-result <?php echo $analysis_result['level']; ?>">
                                        <?php echo htmlspecialchars($analysis_result['message']); ?>
                                    </span>
                                    <?php if (!empty($analysis_result['details'])): ?>
                                        <div class="analysis-details">
                                            <?php foreach ($analysis_result['details'] as $detail): ?>
                                                <div class="analysis-detail">• <?php echo htmlspecialchars($detail); ?></div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🎯</span>
                                    <h3>Критерий поиска</h3>
                                </div>
                                <div class="source-content">
                                    <strong>Фильтр:</strong>
                                    <span class="filter-value">
                                        <?php 
                                        switch ($filter_type) {
                                            case 'last_name': echo 'По фамилии'; break;
                                            case 'first_name': echo 'По имени'; break;
                                            case 'industry': echo 'По услугам'; break;
                                            case 'all': echo 'По всем критериям'; break;
                                            default: echo htmlspecialchars($filter_type);
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                       <?php if (!empty($search_results)): ?>
    <div class="results-section">
        <div class="results-count">
            <span class="count-icon">📊</span>
            Найдено клиентов: <strong><?php echo count($search_results); ?></strong>
        </div>
        
        <div class="compact-table-wrapper">
            <div class="table-scroll-container" style="max-height: 500px; overflow-y: auto;">
                <table class="compact-table" style="min-width: 1000px;">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Организация</th>
                            <th>ФИО</th>
                            <th>Контактное лицо</th>
                            <th>Email</th>
                            <th>Телефон</th>
                            <th>ИНН</th>
                            <th>Индустрия</th>
                            <th>Бюджет</th>
                            <th>Регион</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($search_results as $client): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($client['client_id']); ?></td>
                                <td><?php echo htmlspecialchars($client['org_name']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($client['full_name']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($client['contact_person']); ?></td>
                                <td><?php echo htmlspecialchars($client['email']); ?></td>
                                <td><?php echo htmlspecialchars($client['phone']); ?></td>
                                <td><?php echo htmlspecialchars($client['inn']); ?></td>
                                <td>
                                    <span class="industry-badge"><?php echo htmlspecialchars($client['industry']); ?></span>
                                </td>
                                <td>
                                    <?php 
                                    $budget_class = '';
                                    switch ($client['budget_segment']) {
                                        case 'high': $budget_class = 'budget-high'; break;
                                        case 'medium': $budget_class = 'budget-medium'; break;
                                        case 'low': $budget_class = 'budget-low'; break;
                                    }
                                    ?>
                                    <span class="budget-segment <?php echo $budget_class; ?>">
                                        <?php echo htmlspecialchars($client['budget_segment']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($client['region']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
                        
                        <div class="action-buttons">
                            <a href="javascript:window.print()" class="action-btn print-btn">
                                <span class="btn-icon">🖨️</span>
                                Печать результатов
                            </a>
                            <a href="index.php" class="action-btn back-btn">
                                <span class="btn-icon">↩️</span>
                                Новый поиск
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script>
        
        const toggleButton = document.getElementById('theme-toggle');
    const body = document.body;
    const themeIcon = toggleButton.querySelector('.theme-icon');

    // Функция для установки правильной иконки
    function updateThemeIcon() {
        if (body.classList.contains('dark-theme')) {
            themeIcon.textContent = '☀️'; // Солнце для темной темы
        } else {
            themeIcon.textContent = '🌙'; // Луна для светлой темы
        }
    }

    // Инициализация темы
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-theme');
    }

    // Обновляем иконку при загрузке
    updateThemeIcon();

    // Обработчик клика
    toggleButton.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        if (body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
        updateThemeIcon();
    });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
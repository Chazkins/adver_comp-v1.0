<?php
// Enable error logging for debugging (remove in production)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

// Start output buffering
ob_start();
session_start();
include 'db.php';

if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}

$table = isset($_GET['table']) ? trim($_GET['table']) : '';
if (empty($table)) {
    die("Ошибка: Не указано название таблицы.");
}

// Функция для экранирования данных для CSV
function escapeCSV($value) {
    if (is_null($value)) {
        return '';
    }
    if (strpos($value, ',') !== false || strpos($value, '"') !== false || strpos($value, "\n") !== false) {
        return '"' . str_replace('"', '""', $value) . '"';
    }
    return $value;
}

// Получение списка таблиц для валидации
function getTableList($conn) {
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    } else {
        error_log("Failed to fetch table list: " . $conn->error);
    }
    return $tables;
}

// Обработка экспорта таблицы в JSON
$export_error = null;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] === 'export_table') {
    try {
        $table_escaped = $conn->real_escape_string($table);
        $tables_list = getTableList($conn);
        
        // Проверка на существование таблицы
        if (!in_array($table, $tables_list)) {
            $export_error = "Таблица '$table' не существует.";
            error_log("Export failed: Table '$table' does not exist.");
        } else {
            // Получение данных таблицы
            $result = $conn->query("SELECT * FROM `$table_escaped`");
            if ($result === false) {
                $export_error = "Ошибка при получении данных таблицы: " . $conn->error;
                error_log("Export failed: " . $conn->error);
            } elseif ($result->num_rows === 0) {
                $export_error = "Таблица '$table' пуста.";
                error_log("Export failed: Table '$table' is empty.");
            } else {
                // Собираем данные в массив
                $json_data = array();
                while ($row = $result->fetch_assoc()) {
                    $json_data[] = $row;
                }
                
                // Преобразуем в JSON
                $json_output = json_encode($json_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                
                // Clear output buffer and send headers
                ob_end_clean();
                header('Content-Type: application/json; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $table . '_export_' . date('Y-m-d_H-i') . '.json"');
                header('Content-Length: ' . strlen($json_output));
                header('Cache-Control: no-cache, no-store, must-revalidate');
                header('Pragma: no-cache');
                header('Expires: 0');
                
                echo $json_output;
                exit();
            }
        }
    } catch (Exception $e) {
        $export_error = "Ошибка экспорта: " . $e->getMessage();
        error_log("Export exception: " . $e->getMessage());
    }
}

// Обработка удаления
if (isset($_GET['delete'])) {
    try {
        $delete_id = $_GET['delete'];
        $table_escaped = $conn->real_escape_string($table);
        $primary_key_query = $conn->query("SHOW KEYS FROM `$table_escaped` WHERE Key_name = 'PRIMARY'");
        $primary_key = $primary_key_query ? $primary_key_query->fetch_assoc()['Column_name'] : 'id';
        $stmt = $conn->prepare("DELETE FROM `$table_escaped` WHERE `$primary_key` = ?");
        $stmt->bind_param("i", $delete_id);
        $stmt->execute();
        $stmt->close();
        header("Location: table_view.php?table=" . urlencode($table));
        exit();
    } catch (Exception $e) {
        $error_message = "Ошибка удаления: " . $e->getMessage();
        error_log("Delete exception: " . $e->getMessage());
    }
}

// Обработка обновления записи
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_record'])) {
    try {
        $update_id = $_POST['update_id'];
        $table_escaped = $conn->real_escape_string($table);
        $primary_key_query = $conn->query("SHOW KEYS FROM `$table_escaped` WHERE Key_name = 'PRIMARY'");
        $primary_key = $primary_key_query ? $primary_key_query->fetch_assoc()['Column_name'] : 'id';
        
        $fields = $conn->query("SHOW COLUMNS FROM `$table_escaped`");
        $updates = [];
        $values = [];
        $types = '';
        
        foreach ($fields as $field) {
            if ($field['Field'] !== $primary_key) {
                $field_name = $field['Field'];
                $updates[] = "`$field_name` = ?";
                $values[] = $_POST[$field_name] ?? '';
                
                if (strpos($field['Type'], 'int') !== false) {
                    $types .= 'i';
                } elseif (strpos($field['Type'], 'double') !== false || strpos($field['Type'], 'float') !== false) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
            }
        }
        
        $values[] = $update_id;
        $types .= 'i';
        
        if (!empty($updates)) {
            $updates_str = implode(', ', $updates);
            $sql = "UPDATE `$table_escaped` SET $updates_str WHERE `$primary_key` = ?";
            
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param($types, ...$values);
                if ($stmt->execute()) {
                    header("Location: table_view.php?table=" . urlencode($table));
                    exit();
                } else {
                    $error_message = "Ошибка при обновлении записи: " . $conn->error;
                    error_log("Update error: " . $conn->error);
                }
                $stmt->close();
            } else {
                $error_message = "Ошибка подготовки запроса: " . $conn->error;
                error_log("Prepare error: " . $conn->error);
            }
        }
    } catch (Exception $e) {
        $error_message = "Ошибка обновления: " . $e->getMessage();
        error_log("Update exception: " . $e->getMessage());
    }
}

// Обработка добавления новой записи
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_record'])) {
    try {
        $table_escaped = $conn->real_escape_string($table);
        $fields = $conn->query("SHOW COLUMNS FROM `$table_escaped`");
        $columns = [];
        $values = [];
        $placeholders = [];
        $types = '';
        
        foreach ($fields as $field) {
            if ($field['Extra'] !== 'auto_increment') {
                $field_name = $field['Field'];
                $columns[] = "`$field_name`";
                $values[] = $_POST[$field_name] ?? '';
                $placeholders[] = '?';
                
                if (strpos($field['Type'], 'int') !== false) {
                    $types .= 'i';
                } elseif (strpos($field['Type'], 'double') !== false || strpos($field['Type'], 'float') !== false) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
            }
        }
        
        if (!empty($columns)) {
            $columns_str = implode(', ', $columns);
            $placeholders_str = implode(', ', $placeholders);
            $sql = "INSERT INTO `$table_escaped` ($columns_str) VALUES ($placeholders_str)";
            
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param($types, ...$values);
                if ($stmt->execute()) {
                    header("Location: table_view.php?table=" . urlencode($table));
                    exit();
                } else {
                    $error_message = "Ошибка при добавлении записи: " . $conn->error;
                    error_log("Insert error: " . $conn->error);
                }
                $stmt->close();
            } else {
                $error_message = "Ошибка подготовки запроса: " . $conn->error;
                error_log("Prepare error: " . $conn->error);
            }
        }
    } catch (Exception $e) {
        $error_message = "Ошибка добавления: " . $e->getMessage();
        error_log("Insert exception: " . $e->getMessage());
    }
}

// Получаем информацию о первичном ключе
$table_escaped = $conn->real_escape_string($table);
$primary_key_query = $conn->query("SHOW KEYS FROM `$table_escaped` WHERE Key_name = 'PRIMARY'");
$primary_key = $primary_key_query ? $primary_key_query->fetch_assoc()['Column_name'] : 'id';

// Получаем данные для редактирования
$edit_data = null;
if (isset($_GET['edit'])) {
    try {
        $edit_id = $_GET['edit'];
        $stmt = $conn->prepare("SELECT * FROM `$table_escaped` WHERE `$primary_key` = ?");
        $stmt->bind_param("i", $edit_id);
        $stmt->execute();
        $edit_result = $stmt->get_result();
        if ($edit_result && $edit_result->num_rows > 0) {
            $edit_data = $edit_result->fetch_assoc();
        }
        $stmt->close();
    } catch (Exception $e) {
        $error_message = "Ошибка редактирования: " . $e->getMessage();
        error_log("Edit exception: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр таблицы: <?php echo htmlspecialchars($table); ?></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <button id="theme-toggle" class="theme-toggle-btn" aria-label="Переключить тему"></button>
    
    <div class="centered-header">
        <div class="header-container">
            <a href="index.php" class="back-link">
                <span class="back-arrow">&larr;</span>
                К списку таблиц
            </a>
            <h1 class="table-title">Таблица: <?php echo htmlspecialchars($table); ?></h1>
        </div>
    </div>

    <div class="table-page-container">
        <form method="post" action="table_view.php?table=<?php echo urlencode($table); ?>" style="margin-bottom: 20px;">
    <input type="hidden" name="action" value="export_table">
    <button type="submit" class="export-quick-btn">
        📥 Экспорт таблицы в JSON
    </button>
</form>
        
        <?php if ($export_error): ?>
            <p class="error"><?php echo htmlspecialchars($export_error); ?></p>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        
        <div class="compact-table-wrapper">
            <div class="table-scroll-container">
                <table class="compact-table">
                    <thead>
                        <tr>
                            <?php
                            $result = $conn->query("SELECT * FROM `$table_escaped` LIMIT 1");
                            $fields = $result ? $result->fetch_fields() : [];
                            foreach ($fields as $field) {
                                echo "<th>" . htmlspecialchars($field->name) . "</th>";
                            }
                            ?>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $data_result = $conn->query("SELECT * FROM `$table_escaped`");
                        if ($data_result && $data_result->num_rows > 0) {
                            while($row = $data_result->fetch_assoc()) {
                                echo "<tr>";
                                foreach ($row as $cell) {
                                    echo "<td>" . htmlspecialchars($cell) . "</td>";
                                }
                                $id = $row[$primary_key];
                                echo "<td class='actions'>";
                                echo "<a href='table_view.php?table=" . urlencode($table) . "&edit=$id' class='edit-btn'>Редактировать</a>";
                                echo "<a href='table_view.php?table=" . urlencode($table) . "&delete=$id' class='delete-btn' onclick='return confirmDelete();'>Удалить</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='" . (count($fields) + 1) . "'>В таблице нет данных.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="add-record-container">
            <h2><?php echo $edit_data ? 'Редактировать запись' : 'Добавить новую запись'; ?></h2>
            <form method="post" action="table_view.php?table=<?php echo urlencode($table); ?>">
                <?php if ($edit_data): ?>
                    <input type="hidden" name="update_id" value="<?php echo $edit_data[$primary_key]; ?>">
                <?php endif; ?>
                <div class="form-fields-container">
                    <?php
                    $fields = $conn->query("SHOW COLUMNS FROM `$table_escaped`");
                    foreach ($fields as $field) {
                        if ($field['Extra'] !== 'auto_increment') {
                            $field_name = $field['Field'];
                            $field_type = $field['Type'];
                            $field_value = $edit_data ? $edit_data[$field_name] : '';
                            
                            echo "<div class='form-group'>";
                            echo "<label for='$field_name'>" . htmlspecialchars($field_name) . "</label>";
                            
                            if (strpos($field_type, 'text') !== false || strpos($field_type, 'varchar') !== false) {
                                echo "<input type='text' id='$field_name' name='$field_name' value='" . htmlspecialchars($field_value) . "' required>";
                            } elseif (strpos($field_type, 'int') !== false) {
                                echo "<input type='number' id='$field_name' name='$field_name' value='" . htmlspecialchars($field_value) . "' required>";
                            } elseif (strpos($field_type, 'date') !== false) {
                                echo "<input type='date' id='$field_name' name='$field_name' value='" . htmlspecialchars($field_value) . "' required>";
                            } elseif (strpos($field_type, 'datetime') !== false) {
                                $datetime_value = $field_value ? date('Y-m-d\TH:i', strtotime($field_value)) : '';
                                echo "<input type='datetime-local' id='$field_name' name='$field_name' value='" . htmlspecialchars($datetime_value) . "' required>";
                            } else {
                                echo "<input type='text' id='$field_name' name='$field_name' value='" . htmlspecialchars($field_value) . "' required>";
                            }
                            echo "</div>";
                        }
                    }
                    ?>
                </div>
                <?php if ($edit_data): ?>
                    <button type="submit" name="update_record" class="add-btn">Обновить</button>
                    <a href="table_view.php?table=<?php echo urlencode($table); ?>" class="cancel-btn">
    ❌ Отмена
</a>
                <?php else: ?>
                    <button type="submit" name="add_record" class="add-btn">Добавить</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <script>
        function confirmDelete() {
            return confirm("Вы уверены, что хотите удалить эту запись?");
        }

        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -

star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
<?php ob_end_flush(); ?>
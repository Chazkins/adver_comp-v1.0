<?php
include 'db.php';

// Функция для обновления структуры таблиц
function updateTableStructure($conn) {
    // Проверяем и добавляем колонку ban_type в таблицу banned_users
    $check_column = $conn->query("SHOW COLUMNS FROM banned_users LIKE 'ban_type'");
    if ($check_column->num_rows == 0) {
        $alter_table = "ALTER TABLE banned_users ADD COLUMN ban_type ENUM('login', 'captcha') DEFAULT 'login'";
        if ($conn->query($alter_table)) {
            echo "Successfully added ban_type column to banned_users table<br>";
        } else {
            echo "Error adding ban_type column: " . $conn->error . "<br>";
        }
    } else {
        echo "ban_type column already exists<br>";
    }
    
    // Проверяем существование таблицы failed_captcha_attempts
    $check_table = $conn->query("SHOW TABLES LIKE 'failed_captcha_attempts'");
    if ($check_table->num_rows == 0) {
        $create_failed_captcha_table = "
        CREATE TABLE failed_captcha_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            login VARCHAR(100) NOT NULL,
            attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            ip_address VARCHAR(45),
            INDEX idx_login (login),
            INDEX idx_attempt_time (attempt_time)
        )";
        
        if ($conn->query($create_failed_captcha_table)) {
            echo "Successfully created failed_captcha_attempts table<br>";
        } else {
            echo "Error creating failed_captcha_attempts table: " . $conn->error . "<br>";
        }
    } else {
        echo "failed_captcha_attempts table already exists<br>";
    }
}

// Выполняем обновление
updateTableStructure($conn);
echo "Table structure update completed!";
$conn->close();
?>
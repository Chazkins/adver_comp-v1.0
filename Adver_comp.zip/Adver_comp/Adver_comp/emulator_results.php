<?php
// emulator_results.php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

session_start();
include 'db.php';

// Проверка авторизации
if (!isset($_SESSION['admin_login'])) {
    header("Location: index.php");
    exit();
}

// Функция для получения случайного клиента из БД
function getRandomClientFromDB($conn) {
    $result = $conn->query("SELECT full_name FROM clients ORDER BY RAND() LIMIT 1");
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

// Функция для получения данных из эмулятора
function getRandomFIOFromEmulator() {
    $emulator_urls = [
        'http://localhost:4444/TransferSimulator/fullName',
        'http://prb.sylas.ru/TransferSimulator/fullName'
    ];
    
    foreach ($emulator_urls as $url) {
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 10,
                    'ignore_errors' => true
                ]
            ]);
            
            $response = file_get_contents($url, false, $context);
            if ($response !== false) {
                $data = json_decode($response, true);
                if (isset($data['value'])) {
                    return $data['value'];
                }
            }
        } catch (Exception $e) {
            error_log("Error accessing emulator at $url: " . $e->getMessage());
            continue;
        }
    }
    return false;
}

// Обработка параметров
$filter_type = $_GET['filter_type'] ?? 'all';
$search_results = [];
$error_message = '';
$emulator_data = null;
$db_client_data = null;

try {
    // Получаем случайного клиента из БД
    $db_client_data = getRandomClientFromDB($conn);
    
    if (!$db_client_data) {
        $error_message = "Не удалось получить данные из базы данных.";
    } else {
        // Получаем данные из эмулятора
        $emulator_data = getRandomFIOFromEmulator();
        
        if (!$emulator_data) {
            $error_message = "Не удалось получить данные от эмулятора. Проверьте, запущен ли эмулятор.";
        } else {
            // Разбиваем ФИО из эмулятора на составляющие
            $fio_parts = explode(' ', $emulator_data);
            $last_name_emulator = $fio_parts[0] ?? '';
            $first_name_emulator = $fio_parts[1] ?? '';
            $middle_name_emulator = $fio_parts[2] ?? '';
            
            // Разбиваем ФИО из БД на составляющие
            $db_fio_parts = explode(' ', $db_client_data['full_name']);
            $last_name_db = $db_fio_parts[0] ?? '';
            $first_name_db = $db_fio_parts[1] ?? '';
            $middle_name_db = $db_fio_parts[2] ?? '';
            
            // Формируем SQL запрос в зависимости от фильтра
            $query = "SELECT * FROM clients WHERE 1=1";
            $params = [];
            $types = '';
            
            switch ($filter_type) {
                case 'last_name':
                    // Используем фамилию из эмулятора для поиска
                    $query .= " AND full_name LIKE ?";
                    $params[] = "%$last_name_emulator%";
                    $types .= 's';
                    break;
                    
                case 'first_name':
                    // Используем имя из эмулятора для поиска
                    $query .= " AND full_name LIKE ?";
                    $params[] = "%$first_name_emulator%";
                    $types .= 's';
                    break;
                    
                case 'industry':
                    // Используем индустрию из выбранного клиента БД
                    $industry_filter = $_GET['industry_filter'] ?? '';
                    if (!empty($industry_filter)) {
                        $query .= " AND industry = ?";
                        $params[] = $industry_filter;
                        $types .= 's';
                    }
                    break;
                    
                case 'all':
                default:
                    // Используем все данные из эмулятора для поиска
                    $query .= " AND (full_name LIKE ? OR full_name LIKE ? OR full_name LIKE ?)";
                    $params = ["%$last_name_emulator%", "%$first_name_emulator%", "%$middle_name_emulator%"];
                    $types = 'sss';
                    break;
            }
            
            // Выполняем поиск
            $stmt = $conn->prepare($query);
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            $search_results = $result->fetch_all(MYSQLI_ASSOC);
            
            if (empty($search_results)) {
                $error_message = "По выбранным критериям клиенты не найдены.";
            }
        }
    }
} catch (Exception $e) {
    $error_message = "Ошибка при выполнении поиска: " . $e->getMessage();
    error_log("Emulator search error: " . $e->getMessage());
}

// Получаем список уникальных индустрий
$industries = [];
$industry_result = $conn->query("SELECT DISTINCT industry FROM clients WHERE industry IS NOT NULL AND industry != '' ORDER BY industry");
if ($industry_result) {
    $industries = $industry_result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Результаты поиска через эмулятор</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    <div class="container">
        <div class="main-content">
          <button id="theme-toggle" class="theme-toggle-btn" aria-label="Переключить тему">
    <span class="theme-icon">🌙</span>
</button>
            <header>
                <div class="header-content">
                    <h1>Результаты поиска через эмулятор</h1>
                    <p>Результаты вашего запроса</p>
                </div>
                <a href="index.php" class="logout-btn">Вернуться</a>
            </header>
            <main>
                <div id="emulator-results-panel" class="emulator-results-panel glass-container">
                    <?php if ($error_message): ?>
                        <div class="error-message glass-container">
                            <span class="error-icon">⚠️</span>
                            <?php echo $error_message; ?>
                        </div>
                    <?php elseif ($emulator_data && $db_client_data): ?>
                        <div class="data-sources">
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🎰</span>
                                    <h3>Данные из эмулятора</h3>
                                </div>
                                <div class="source-content">
                                    <strong>ФИО:</strong>
                                    <span class="fio-value">"<?php echo htmlspecialchars($emulator_data); ?>"</span>
                                </div>
                            </div>
                            
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🗄️</span>
                                    <h3>Данные из базы</h3>
                                </div>
                                <div class="source-content">
                                    <strong>ФИО клиента:</strong>
                                    <span class="fio-value">"<?php echo htmlspecialchars($db_client_data['full_name']); ?>"</span>
                                </div>
                            </div>
                            
                            <div class="source-card">
                                <div class="source-header">
                                    <span class="source-icon">🎯</span>
                                    <h3>Критерий поиска</h3>
                                </div>
                                <div class="source-content">
                                    <strong>Фильтр:</strong>
                                    <span class="filter-value">
                                        <?php 
                                        switch ($filter_type) {
                                            case 'last_name': echo 'По фамилии'; break;
                                            case 'first_name': echo 'По имени'; break;
                                            case 'industry': echo 'По услугам'; break;
                                            case 'all': echo 'По всем критериям'; break;
                                            default: echo htmlspecialchars($filter_type);
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                       <?php if (!empty($search_results)): ?>
    <div class="results-section">
        <div class="results-count">
            <span class="count-icon">📊</span>
            Найдено клиентов: <strong><?php echo count($search_results); ?></strong>
        </div>
        
        <div class="compact-table-wrapper">
            <div class="table-scroll-container" style="max-height: 500px; overflow-y: auto;">
                <table class="compact-table" style="min-width: 1000px;">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Организация</th>
                            <th>ФИО</th>
                            <th>Контактное лицо</th>
                            <th>Email</th>
                            <th>Телефон</th>
                            <th>ИНН</th>
                            <th>Индустрия</th>
                            <th>Бюджет</th>
                            <th>Регион</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($search_results as $client): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($client['client_id']); ?></td>
                                <td><?php echo htmlspecialchars($client['org_name']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($client['full_name']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($client['contact_person']); ?></td>
                                <td><?php echo htmlspecialchars($client['email']); ?></td>
                                <td><?php echo htmlspecialchars($client['phone']); ?></td>
                                <td><?php echo htmlspecialchars($client['inn']); ?></td>
                                <td>
                                    <span class="industry-badge"><?php echo htmlspecialchars($client['industry']); ?></span>
                                </td>
                                <td>
                                    <?php 
                                    $budget_class = '';
                                    switch ($client['budget_segment']) {
                                        case 'high': $budget_class = 'budget-high'; break;
                                        case 'medium': $budget_class = 'budget-medium'; break;
                                        case 'low': $budget_class = 'budget-low'; break;
                                    }
                                    ?>
                                    <span class="budget-segment <?php echo $budget_class; ?>">
                                        <?php echo htmlspecialchars($client['budget_segment']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($client['region']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
                        
                        <div class="action-buttons">
                            <a href="javascript:window.print()" class="action-btn print-btn">
                                <span class="btn-icon">🖨️</span>
                                Печать результатов
                            </a>
                            <a href="index.php" class="action-btn back-btn">
                                <span class="btn-icon">↩️</span>
                                Новый поиск
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script>
        
        const toggleButton = document.getElementById('theme-toggle');
    const body = document.body;
    const themeIcon = toggleButton.querySelector('.theme-icon');

    // Функция для установки правильной иконки
    function updateThemeIcon() {
        if (body.classList.contains('dark-theme')) {
            themeIcon.textContent = '☀️'; // Солнце для темной темы
        } else {
            themeIcon.textContent = '🌙'; // Луна для светлой темы
        }
    }

    // Инициализация темы
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-theme');
    }

    // Обновляем иконку при загрузке
    updateThemeIcon();

    // Обработчик клика
    toggleButton.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        if (body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
        updateThemeIcon();
    });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
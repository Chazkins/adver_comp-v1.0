<?php
$servername = "134.90.167.42:10306";
$username = "Dimitrinev";
$password = "-IQ62y";
$dbname = "project_Dimitrinev";
$port = 3306;

// Создаем соединение
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Проверяем соединение
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Создаем таблицу для отслеживания неудачных попыток входа
$create_failed_logins_table = "
CREATE TABLE IF NOT EXISTS failed_logins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(100) NOT NULL,
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    INDEX idx_login (login),
    INDEX idx_attempt_time (attempt_time)
)";

if (!$conn->query($create_failed_logins_table)) {
    // Если таблица уже существует, игнорируем ошибку
    if ($conn->errno != 1050) {
        error_log("Error creating failed_logins table: " . $conn->error);
    }
}

// Создаем таблицу для отслеживания неудачных попыток капчи
$create_failed_captcha_table = "
CREATE TABLE IF NOT EXISTS failed_captcha_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(100) NOT NULL,
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    INDEX idx_login (login),
    INDEX idx_attempt_time (attempt_time)
)";

if (!$conn->query($create_failed_captcha_table)) {
    // Если таблица уже существует, игнорируем ошибку
    if ($conn->errno != 1050) {
        error_log("Error creating failed_captcha_attempts table: " . $conn->error);
    }
}

// Создаем таблицу для заблокированных пользователей
$create_banned_users_table = "
CREATE TABLE IF NOT EXISTS banned_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(100) NOT NULL UNIQUE,
    banned_until TIMESTAMP NULL,
    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    banned_by INT,
    reason TEXT,
    ban_type ENUM('login', 'captcha') DEFAULT 'login',
    INDEX idx_login (login),
    INDEX idx_banned_until (banned_until),
    INDEX idx_ban_type (ban_type)
)";

if (!$conn->query($create_banned_users_table)) {
    // Если таблица уже существует, добавляем недостающие колонки
    if ($conn->errno == 1050) {
        // Проверяем существование колонки ban_type
        $check_column = $conn->query("SHOW COLUMNS FROM banned_users LIKE 'ban_type'");
        if ($check_column->num_rows == 0) {
            // Добавляем колонку ban_type
            $alter_table = "ALTER TABLE banned_users ADD COLUMN ban_type ENUM('login', 'captcha') DEFAULT 'login'";
            if (!$conn->query($alter_table)) {
                error_log("Error adding ban_type column: " . $conn->error);
            } else {
                error_log("Successfully added ban_type column to banned_users table");
            }
        }
    } else {
        error_log("Error creating banned_users table: " . $conn->error);
    }
}
?>
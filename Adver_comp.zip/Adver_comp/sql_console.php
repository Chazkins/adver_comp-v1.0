<?php
ob_start();
session_start();
include 'db.php';

$sql_result = null;
$sql_error = null;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sql_query'])) {
    $sql_query = trim($_POST['sql_query']);
    
    $restricted_commands = ['DROP', 'ALTER', 'DELETE', 'TRUNCATE', 'INSERT', 'UPDATE'];
    $query_upper = strtoupper($sql_query);
    $is_restricted = false;
    foreach ($restricted_commands as $command) {
        if (strpos($query_upper, $command) === 0) {
            $is_restricted = true;
            break;
        }
    }
    
    if ($is_restricted) {
        $sql_error = "Ошибка: Запрещено выполнение команд DROP, ALTER, DELETE, TRUNCATE, INSERT, UPDATE.";
    } else {
        if (stripos($sql_query, 'SELECT') === 0) {
            $result = $conn->query($sql_query);
            if ($result) {
                $sql_result = $result->fetch_all(MYSQLI_ASSOC);
            } else {
                $sql_error = "Ошибка выполнения запроса: " . $conn->error;
            }
        } else {
            $sql_error = "Ошибка: Поддерживаются только SELECT-запросы.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQL Консоль</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <button id="theme-toggle" class="theme-toggle-btn">Переключить тему</button>
    
    <div class="centered-header">
        <div class="header-container">
            <a href="index.php" class="back-link">
                <span class="back-arrow">&larr;</span>
                На главную
            </a>
            <h1 class="table-title">SQL Консоль</h1>
        </div>
    </div>

    <div class="table-page-container">
        <div id="sql-query-panel" class="sql-query-panel">
            <h2>SQL-запрос</h2>
            <form method="post" action="sql_console.php">
                <div class="form-group">
                    <label for="sql_query">Введите SQL-запрос</label>
                    <textarea id="sql_query" name="sql_query" rows="5" style="width: 100%; resize: vertical;"><?php echo isset($_POST['sql_query']) ? htmlspecialchars($_POST['sql_query']) : ''; ?></textarea>
                </div>
                <?php if ($sql_error): ?>
                    <p class="error"><?php echo htmlspecialchars($sql_error); ?></p>
                <?php endif; ?>
                <button type="submit" class="add-btn">Выполнить</button>
            </form>
            <?php if ($sql_result): ?>
                <div class="compact-table-wrapper">
                    <div class="table-scroll-container">
                        <table class="compact-table">
                            <thead>
                                <tr>
                                    <?php foreach (array_keys($sql_result[0]) as $column): ?>
                                        <th><?php echo htmlspecialchars($column); ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sql_result as $row): ?>
                                    <tr>
                                        <?php foreach ($row as $value): ?>
                                            <td><?php echo htmlspecialchars($value); ?></td>
                                        <?php endforeach; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        const toggleButton = document.getElementById('theme-toggle');
        const body = document.body;

        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
        }

        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });

        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 200;

        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }

        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }

        initStars();
        drawStars();

        window.addEventListener('resize', initStars);
    </script>
</body>
</html>
<?php ob_end_flush(); ?>
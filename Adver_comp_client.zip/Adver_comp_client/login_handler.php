<?php
// login_handler.php
session_start();
include 'db.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $login = trim($_POST['login']);
        $password = $_POST['password'];

        if (empty($login) || empty($password)) {
            $response['message'] = 'Логин и пароль обязательны для заполнения.';
            echo json_encode($response);
            exit;
        }

        // Ищем пользователя в таблице clients
        $stmt = $conn->prepare("SELECT client_id, login, password_hash FROM clients WHERE login = ?");
        $stmt->bind_param("s", $login);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $client = $result->fetch_assoc();
            
            // Проверяем пароль
            if (password_verify($password, $client['password_hash'])) {
                $_SESSION['client_id'] = $client['client_id'];
                $_SESSION['client_login'] = $client['login'];
                
                // Обновляем время последнего входа
                $update_stmt = $conn->prepare("UPDATE clients SET last_login = NOW() WHERE client_id = ?");
                $update_stmt->bind_param("i", $client['client_id']);
                $update_stmt->execute();
                
                $response['success'] = true;
                $response['message'] = 'Вход выполнен успешно!';
                
                // Логируем успешный вход
                error_log("Клиент вошел в систему: " . $client['login']);
            } else {
                $response['message'] = 'Неверный логин или пароль.';
            }
        } else {
            $response['message'] = 'Неверный логин или пароль.';
        }

    } catch (Exception $e) {
        $response['message'] = 'Ошибка при обработке запроса: ' . $e->getMessage();
        error_log("Login error: " . $e->getMessage());
    }
} else {
    $response['message'] = 'Неверный метод запроса.';
}

echo json_encode($response);
?>
<?php
include 'csrf.php';
include 'db.php';

// Проверяем авторизацию
if (!isset($_SESSION['client_id'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_POST['order_id'] ?? '') {
    $order_id = intval($_POST['order_id']);
    $client_id = $_SESSION['client_id'];
    
    // Проверяем, что заказ принадлежит пользователю
    $stmt = $conn->prepare("
        SELECT o.order_id 
        FROM orders o 
        JOIN campaigns c ON o.campaign_id = c.campaign_id 
        WHERE o.order_id = ? AND c.client_id = ?
    ");
    $stmt->bind_param("ii", $order_id, $client_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Обновляем статус заказа
        $update_stmt = $conn->prepare("UPDATE orders SET status = 'canceled' WHERE order_id = ?");
        $update_stmt->bind_param("i", $order_id);
        
        if ($update_stmt->execute()) {
            $_SESSION['success_message'] = "Заказ успешно отменен!";
        } else {
            $_SESSION['error_message'] = "Ошибка при отмене заказа.";
        }
    } else {
        $_SESSION['error_message'] = "Заказ не найден или у вас нет прав для его отмены.";
    }
}

header("Location: profile.php");
exit;
?>
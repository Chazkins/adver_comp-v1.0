-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 22, 2025 at 05:31 PM
-- Server version: 10.6.22-MariaDB-0ubuntu0.22.04.1
-- PHP Version: 8.1.2-1ubuntu2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_Dimitrinev`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`Dimitrinev`@`%` PROCEDURE `GenerateAdvertisingReport` ()  BEGIN
    SELECT
        o.id_order AS 'ID заказа',
        CONCAT(c.last_name_client, ' ', c.first_name_client, ' ', c.middle_name_client) AS 'Клиент',
        o.date_order AS 'Дата заказа',
        o.date_complete AS 'Дата выполнения',
        o.date_receiving AS 'Дата завершения',
        GROUP_CONCAT(DISTINCT ap.address_point SEPARATOR '; ') AS 'Рекламные места',
        GROUP_CONCAT(DISTINCT m.material_name SEPARATOR '; ') AS 'Материалы',
        SUM(m.material_price * mio.material_amount) AS 'Стоимость материалов (руб.)',
        o.order_cost AS 'Стоимость заказа (руб.)',
        o.order_cost + IFNULL(SUM(m.material_price * mio.material_amount), 0) AS 'Итоговая сумма (руб.)'
    FROM Orders o
    JOIN Client c ON o.id_client = c.id_client
    LEFT JOIN Advertising_points_in_order apio ON o.id_order = apio.id_order
    LEFT JOIN Advertising_points ap ON apio.id_point = ap.id_point
    LEFT JOIN Materials_in_the_order mio ON o.id_order = mio.id_order
    LEFT JOIN Materials m ON mio.id_material = m.id_material
    GROUP BY o.id_order
    ORDER BY o.date_order;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `login` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'manager',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `full_name`, `email`, `phone`, `login`, `password_hash`, `role`, `created_at`, `last_login`) VALUES
(1, 'Кирилл Димитринев', 'ivan@example.com', '+7 (3842) 123-456', 'Dimitrinev', '$2y$10$Mwg/kPBz902iNpcg71RMreWIa6aYPWvR4qO1yzIlCVv4jeqTUmS8e', 'superadmin', '2025-09-01 03:00:00', '2025-10-10 06:22:54'),
(2, 'Мария Петрова', 'maria@example.com', '+7 (3842) 234-567', 'Maria', '12345', 'analyst', '2025-09-02 04:00:00', '2025-09-21 07:30:00'),
(3, 'Алексей Сидоров', 'alexey@example.com', '+7 (3842) 345-678', 'alexey.sidorov', '$2y$10$iCsvqUA7DqqMkBKHFgY6PeBBpllZ2ClNedRp6RxpRn2q0YFBxETfK', 'superadmin', '2025-09-03 02:00:00', '2025-09-22 01:30:00'),
(4, 'Ольга Кузнецова', 'olga@example.com', '+7 (3842) 456-789', 'olga.kuznetsova', '$2y$10$5TkMK1zMRM/l2p5vi7dCtOiq2jLE9Nlq6G71kkU6q43lWmvGbK7Ai', 'logist', '2025-09-04 05:00:00', '2025-09-20 03:15:00'),
(5, 'Дмитрий Морозов', 'dmitry@example.com', '+7 (3842) 567-890', 'dmitry.morozov', '$2y$10$vF1szzHAWTXNcfMphrO8juoN1UIvkM54GxYeRNCob7us1ikx9m0I.', 'manager', '2025-09-05 06:00:00', '2025-09-19 09:45:00'),
(6, 'Елена Иванова', 'elena@example.com', '+7 (3842) 678-901', 'elena.ivanova', '$2y$10$1iOXM5kYioB6iSijVdNHyuwc1rQLbiiOlMU8w7P20uUGNZHp/YIqi', 'designer', '2025-09-06 07:00:00', '2025-09-18 02:30:00'),
(7, 'Сергей Петров', 'sergey@example.com', '+7 (3842) 789-012', 'sergey.petrov', '$2y$10$U.B0.1x/hCxXE0.povKctOiDjsuxdVVJ.CdVoAqhlFPYjJBVWK9Bm', 'superadmin', '2025-09-07 03:00:00', '2025-09-17 06:00:00'),
(8, 'Наталья Смирнова', 'natalya@example.com', '+7 (3842) 890-123', 'natalya.smirnova', '$2y$10$ZbHHsr43.hHB38thBuM/8.WtTwXXDtDzJbSqR/AL9GNRahcwKLCze', 'logist', '2025-09-08 04:00:00', '2025-09-16 04:20:00'),
(9, 'Андрей Николаев', 'andrey@example.com', '+7 (3842) 901-234', 'andrey.nikolaev', '$2y$10$IR61D6.l8B2fCYLtR0moZeWt0knPomHMqWu.wZ8b7lf86N/hVeXl2', 'manager', '2025-09-09 08:00:00', '2025-09-15 08:10:00'),
(10, 'Анна Козлова', 'anna@example.com', '+7 (3842) 012-345', 'anna.kozlova', '$2y$10$LGMtOVCpjY44HCNaCOWBEeTPK9p8g2lnL8hVxS4hJVjBtsVx1Rydy', 'analyst', '2025-09-10 02:00:00', '2025-09-14 01:50:00'),
(11, 'Виктор Лебедев', 'viktor@example.com', '+7 (3842) 123-789', 'viktor.lebedev', '$2y$10$Y5IeVRMwckAxkYG.vXK2ve5F6aAHzhyTZricREHMYVCXFXNcuyu.m', 'designer', '2025-09-11 05:00:00', '2025-09-13 05:30:00'),
(12, 'Татьяна Васильева', 'tatiana@example.com', '+7 (3842) 234-890', 'tatiana.vasilieva', '$2y$10$iC9IzlBc1yfnZDocDLOIae6aQK6Vlq7fN8YNO86XVlc.9eG.fDVt6', 'logist', '2025-09-12 06:00:00', '2025-09-12 03:00:00'),
(13, 'Павел Фёдоров', 'pavel@example.com', '+7 (3842) 345-901', 'pavel.fedorov', '$2y$10$gD8wmLMofhViFjGEsuCldebRGe.JTe9ybAs49RKQNX8czhlUWmtJm', 'manager', '2025-09-13 07:00:00', '2025-09-11 07:40:00'),
(14, 'Юлия Михайлова', 'yulia@example.com', '+7 (3842) 456-012', 'yulia.mikhailova', '$2y$10$JB1L9KF9ts2FY3z3lc5u0ewJybgh2QlU9nadcSujn0vC.TeG5rs8a', 'analyst', '2025-09-14 03:00:00', '2025-09-10 02:25:00'),
(15, 'Константин Орлов', 'konstantin@example.com', '+7 (3842) 567-123', 'konstantin.orlov', '$2y$10$Wt0hVej7RWhyD0MBU9Hefu/vnKM7K7cD0P2ZEnsVgNSPCJZ0C97bW', 'superadmin', '2025-09-15 04:00:00', '2025-09-09 06:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `banned_users`
--

CREATE TABLE `banned_users` (
  `id` int(11) NOT NULL,
  `login` varchar(100) NOT NULL,
  `banned_until` timestamp NULL DEFAULT NULL,
  `banned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `banned_by` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `ban_type` enum('login','captcha') DEFAULT 'login'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `briefs`
--

CREATE TABLE `briefs` (
  `brief_id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `goals` text DEFAULT NULL,
  `target_audience` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `briefs`
--

INSERT INTO `briefs` (`brief_id`, `campaign_id`, `goals`, `target_audience`, `requirements`, `submitted_at`) VALUES
(1, 1, 'Увеличить охват на 20%', 'Жители Кемерово 25-40 лет', 'Макет баннера 3x2 м', '2025-09-22 06:50:14'),
(2, 2, 'Повысить конверсию на 15%', 'Онлайн-аудитория 18-35 лет', 'Настройка Яндекс.Директ', '2025-09-22 06:50:14'),
(3, 3, 'Комбинированный охват', 'Местные предприниматели', 'SMM-стратегия и баннеры', '2025-09-22 06:50:14'),
(4, 4, 'Распространение листовок', 'Покупатели 30-50 лет', 'Дизайн А5 листовок', '2025-09-22 06:50:14'),
(5, 5, 'Таргетинг молодежи', 'Пользователи VK 18-25 лет', 'Кампания в VK', '2025-09-22 06:50:14'),
(6, 6, 'Реклама услуг', 'Клиенты 25-45 лет', 'Баннеры и SMM', '2025-09-22 06:50:14'),
(7, 7, 'Промо-мероприятие', 'Жители региона', 'Организация фестиваля', '2025-09-22 06:50:14'),
(8, 8, 'SEO-оптимизация', 'Владельцы сайтов', 'Ключевые слова и контент', '2025-09-22 06:50:14'),
(9, 9, 'Реклама стройки', 'Инвесторы 30-60 лет', 'Баннеры и контекст', '2025-09-22 06:50:14'),
(10, 10, 'Летняя акция', 'Покупатели 20-40 лет', 'Футболки с логотипом', '2025-09-22 06:50:14'),
(11, 11, 'SMM-продвижение', 'Подписчики Instagram', 'Посты и сторис', '2025-09-22 06:50:14'),
(12, 12, 'Реклама кафе', 'Жители Кемерово', 'Листовки и таргетинг', '2025-09-22 06:50:14'),
(13, 13, 'Промо строительства', 'Инвесторы', 'Вывески и баннеры', '2025-09-22 06:50:14'),
(14, 14, 'Цифровой маркетинг', 'Онлайн-аудитория', 'Google Ads кампания', '2025-09-22 06:50:14'),
(15, 15, 'Реклама услуг', 'Клиенты 25-50 лет', 'SMM и вывески', '2025-09-22 06:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

CREATE TABLE `campaigns` (
  `campaign_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `budget` decimal(12,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(15) DEFAULT 'planned',
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaigns`
--

INSERT INTO `campaigns` (`campaign_id`, `client_id`, `name`, `type`, `budget`, `start_date`, `end_date`, `status`, `created_by`) VALUES
(1, 1, 'Промо Весна 2025', 'offline', '50000.00', '2025-10-01', '2025-10-15', 'planned', 1),
(2, 2, 'Цифровой старт', 'digital', '30000.00', '2025-09-25', '2025-11-01', 'active', 2),
(3, 3, 'Смешанная кампания', 'mixed', '75000.00', '2025-10-05', '2025-11-30', 'planned', 3),
(4, 4, 'Осенняя распродажа', 'offline', '40000.00', '2025-10-10', '2025-11-10', 'active', 4),
(5, 5, 'Таргетинг молодежи', 'digital', '25000.00', '2025-09-28', '2025-10-31', 'completed', 5),
(6, 6, 'Реклама услуг', 'mixed', '60000.00', '2025-10-15', '2025-12-01', 'planned', 6),
(7, 7, 'Зимний фестиваль', 'offline', '80000.00', '2025-11-01', '2025-12-15', 'planned', 7),
(8, 8, 'SEO-продвижение', 'digital', '35000.00', '2025-09-30', '2025-11-15', 'active', 8),
(9, 9, 'Реклама стройки', 'mixed', '45000.00', '2025-10-20', '2025-12-01', 'completed', 9),
(10, 10, 'Летняя акция', 'offline', '30000.00', '2025-09-25', '2025-10-20', 'canceled', 10),
(11, 11, 'SMM-продвижение', 'digital', '20000.00', '2025-10-01', '2025-11-10', 'active', 11),
(12, 12, 'Реклама кафе', 'mixed', '55000.00', '2025-10-10', '2025-11-30', 'planned', 12),
(13, 13, 'Промо строительства', 'offline', '70000.00', '2025-10-15', '2025-12-01', 'active', 13),
(14, 14, 'Цифровой маркетинг', 'digital', '40000.00', '2025-09-20', '2025-10-31', 'completed', 14),
(15, 15, 'Реклама услуг', 'mixed', '65000.00', '2025-10-05', '2025-11-15', 'planned', 15);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `inn` varchar(20) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `budget_segment` enum('low','medium','high') DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `login` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `org_name`, `full_name`, `contact_person`, `email`, `phone`, `inn`, `industry`, `budget_segment`, `region`, `login`, `password_hash`, `created_at`, `last_login`) VALUES
(1, 'ООО Радуга', 'Иван Смирнов', 'Алексей Иванов', 'raduga@biz.ru', '+7 (3842) 123-456', '540123456789', 'розничная торговля', 'medium', 'Кемерово', 'raduga.user', 'hashed_pass16', '2025-09-01 02:00:00', '2025-09-22 02:00:00'),
(2, 'ИП Сокол', 'Мария Петрова', 'Ольга Кузнецова', 'sokol@trade.ru', '+7 (3842) 234-567', '540234567890', 'строительство', 'high', 'Новокузнецк', 'sokol.user', 'hashed_pass17', '2025-09-02 03:00:00', '2025-09-21 07:30:00'),
(3, 'ООО Лидер', 'Алексей Сидоров', 'Дмитрий Морозов', 'lider@market.ru', '+7 (3842) 345-678', '540345678901', 'услуги', 'low', 'Кемерово', 'lider.user', 'hashed_pass18', '2025-09-03 04:00:00', '2025-09-20 03:15:00'),
(4, 'ЗАО Прогресс', 'Елена Иванова', 'Сергей Петров', 'progress@corp.ru', '+7 (3842) 456-789', '540456789012', 'производство', 'medium', 'Прокопьевск', 'progress.user', 'hashed_pass19', '2025-09-04 05:00:00', '2025-09-19 09:45:00'),
(5, 'ООО Гармония', 'Наталья Смирнова', 'Андрей Николаев', 'garmonia@trade.ru', '+7 (3842) 567-890', '540567890123', 'торговля', 'high', 'Кемерово', 'garmonia.user', 'hashed_pass20', '2025-09-05 06:00:00', '2025-09-18 02:30:00'),
(6, 'ИП Орёл', 'Анна Козлова', 'Виктор Лебедев', 'orel@shop.ru', '+7 (3842) 678-901', '540678901234', 'ресторанный бизнес', 'medium', 'Ленинск-Кузнецкий', 'orel.user', 'hashed_pass21', '2025-09-06 07:00:00', '2025-09-17 06:00:00'),
(7, 'ООО Вершина', 'Татьяна Васильева', 'Павел Фёдоров', 'vershina@biz.ru', '+7 (3842) 789-012', '540789012345', 'финансы', 'high', 'Кемерово', 'vershina.user', 'hashed_pass22', '2025-09-07 03:00:00', '2025-09-16 04:20:00'),
(8, 'ЗАО Старт', 'Юлия Михайлова', 'Константин Орлов', 'start@industry.ru', '+7 (3842) 890-123', '540890123456', 'промышленность', 'medium', 'Таштагол', 'start.user', 'hashed_pass23', '2025-09-08 04:00:00', '2025-09-15 08:10:00'),
(9, 'ООО Свет', 'Игорь Рубцов', 'Елена Соколова', 'svet@service.ru', '+7 (3842) 901-234', '540901234567', 'сервис', 'low', 'Кемерово', 'svet.user', 'hashed_pass24', '2025-09-09 08:00:00', '2025-09-14 01:50:00'),
(10, 'ИП Ястреб', 'Олег Козлов', 'Марина Иванова', 'yastreb@trade.ru', '+7 (3842) 012-345', '540012345678', 'торговля', 'medium', 'Белово', 'yastreb.user', 'hashed_pass25', '2025-09-10 02:00:00', '2025-09-13 05:30:00'),
(11, 'ООО Пульс', 'Светлана Морозова', 'Анатолий Петров', 'puls@market.ru', '+7 (3842) 123-789', '540123789012', 'маркетинг', 'high', 'Кемерово', 'puls.user', 'hashed_pass26', '2025-09-11 05:00:00', '2025-09-12 03:00:00'),
(12, 'ЗАО Горизонт', 'Владимир Сидоров', 'Нина Кузнецова', 'gorizont@biz.ru', '+7 (3842) 234-890', '540234890123', 'логистика', 'medium', 'Киселевск', 'gorizont.user', 'hashed_pass27', '2025-09-12 06:00:00', '2025-09-11 07:40:00'),
(13, 'ООО Энергия', 'Галина Иванова', 'Роман Лебедев', 'energia@corp.ru', '+7 (3842) 345-901', '540345901234', 'энергия', 'high', 'Кемерово', 'energia.user', 'hashed_pass28', '2025-09-13 07:00:00', '2025-09-10 02:25:00'),
(14, 'ИП Сова', 'Алексей Орлов', 'Татьяна Васильева', 'sova@shop.ru', '+7 (3842) 456-012', '540456012345', 'торговля', 'low', 'Анжеро-Судженск', 'sova.user', 'hashed_pass29', '2025-09-14 03:00:00', '2025-09-09 06:15:00'),
(15, 'ООО Заря', 'Екатерина Фёдорова', 'Петр Смирнов', 'zarya@service.ru', '+7 (3842) 567-123', '540567123456', 'сервис', 'medium', 'Кемерово', 'zarya.user', 'hashed_pass30', '2025-09-15 04:00:00', '2025-09-08 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `creatives`
--

CREATE TABLE `creatives` (
  `creative_id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `creatives`
--

INSERT INTO `creatives` (`creative_id`, `campaign_id`, `file_path`, `type`, `uploaded_by`, `uploaded_at`) VALUES
(1, 1, '/creatives/banner1.jpg', 'image', 1, '2025-09-22 06:50:14'),
(2, 2, '/creatives/ad1.mp4', 'video', 2, '2025-09-22 06:50:14'),
(3, 3, '/creatives/smm1.png', 'image', 3, '2025-09-22 06:50:14'),
(4, 4, '/creatives/leaflet1.pdf', 'pdf', 4, '2025-09-22 06:50:14'),
(5, 5, '/creatives/vk1.jpg', 'image', 5, '2025-09-22 06:50:14'),
(6, 6, '/creatives/mixed1.jpg', 'image', 6, '2025-09-22 06:50:14'),
(7, 7, '/creatives/festival1.mp4', 'video', 7, '2025-09-22 06:50:14'),
(8, 8, '/creatives/seo1.html', 'html', 8, '2025-09-22 06:50:14'),
(9, 9, '/creatives/build1.jpg', 'image', 9, '2025-09-22 06:50:14'),
(10, 10, '/creatives/tshirt1.png', 'image', 10, '2025-09-22 06:50:14'),
(11, 11, '/creatives/insta1.jpg', 'image', 11, '2025-09-22 06:50:14'),
(12, 12, '/creatives/cafe1.pdf', 'pdf', 12, '2025-09-22 06:50:14'),
(13, 13, '/creatives/build2.jpg', 'image', 13, '2025-09-22 06:50:14'),
(14, 14, '/creatives/google1.mp4', 'video', 14, '2025-09-22 06:50:14'),
(15, 15, '/creatives/service1.jpg', 'image', 15, '2025-09-22 06:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `failed_captcha_attempts`
--

CREATE TABLE `failed_captcha_attempts` (
  `id` int(11) NOT NULL,
  `login` varchar(100) NOT NULL,
  `attempt_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `failed_captcha_attempts`
--

INSERT INTO `failed_captcha_attempts` (`id`, `login`, `attempt_time`, `ip_address`) VALUES
(1, 'Maria', '2025-10-20 06:26:52', '::1'),
(2, 'Maria', '2025-10-20 06:27:06', '::1'),
(3, 'Maria', '2025-10-20 06:27:16', '::1'),
(4, 'Maria', '2025-10-20 06:27:30', '::1'),
(5, 'Maria', '2025-10-20 06:30:33', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `failed_logins`
--

CREATE TABLE `failed_logins` (
  `id` int(11) NOT NULL,
  `login` varchar(100) NOT NULL,
  `attempt_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `failed_logins`
--

INSERT INTO `failed_logins` (`id`, `login`, `attempt_time`, `ip_address`) VALUES
(4, 'Maria', '2025-09-29 08:24:26', '::1'),
(5, 'Maria', '2025-09-29 08:24:33', '::1'),
(6, 'Maria', '2025-09-29 08:24:40', '::1'),
(8, 'Maria', '2025-10-01 08:26:21', '::1'),
(9, 'Maria', '2025-10-01 08:26:28', '::1'),
(10, 'Maria', '2025-10-01 08:26:35', '::1'),
(12, 'Maria', '2025-10-10 06:21:30', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `interactions`
--

CREATE TABLE `interactions` (
  `interaction_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `type` varchar(15) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `interactions`
--

INSERT INTO `interactions` (`interaction_id`, `client_id`, `admin_id`, `type`, `notes`, `date`) VALUES
(1, 1, 1, 'call', 'Обсуждены сроки доставки', '2025-09-22 06:50:14'),
(2, 2, 2, 'meeting', 'Согласован бюджет', '2025-09-22 06:50:14'),
(3, 3, 3, 'email', 'Отправлен бриф', '2025-09-22 06:50:14'),
(4, 4, 4, 'call', 'Уточнены детали', '2025-09-22 06:50:14'),
(5, 5, 5, 'meeting', 'Подписан договор', '2025-09-22 06:50:14'),
(6, 6, 6, 'email', 'Запрошена отчетность', '2025-09-22 06:50:14'),
(7, 7, 7, 'call', 'Согласованы макеты', '2025-09-22 06:50:14'),
(8, 8, 8, 'meeting', 'Обсуждена кампания', '2025-09-22 06:50:14'),
(9, 9, 9, 'email', 'Отправлен счет', '2025-09-22 06:50:14'),
(10, 10, 10, 'call', 'Уточнены сроки', '2025-09-22 06:50:14'),
(11, 11, 11, 'meeting', 'Согласован дизайн', '2025-09-22 06:50:14'),
(12, 12, 12, 'email', 'Запрошены данные', '2025-09-22 06:50:14'),
(13, 13, 13, 'call', 'Обсуждены расходы', '2025-09-22 06:50:14'),
(14, 14, 14, 'meeting', 'Подписан акт', '2025-09-22 06:50:14'),
(15, 15, 15, 'email', 'Отправлен отчет', '2025-09-22 06:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `logistics`
--

CREATE TABLE `logistics` (
  `logistics_id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `status` varchar(15) DEFAULT 'planned'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logistics`
--

INSERT INTO `logistics` (`logistics_id`, `campaign_id`, `description`, `delivery_date`, `status`) VALUES
(1, 1, 'Доставка баннеров', '2025-10-10', 'planned'),
(2, 2, 'Доставка листовок', '2025-10-05', 'in_progress'),
(3, 3, 'Доставка футболок', '2025-10-15', 'planned'),
(4, 4, 'Доставка вывесок', '2025-10-12', 'done'),
(5, 5, 'Доставка наклеек', '2025-10-03', 'in_progress'),
(6, 6, 'Доставка баннеров', '2025-10-20', 'planned'),
(7, 7, 'Доставка брошюр', '2025-11-01', 'planned'),
(8, 8, 'Доставка футболок', '2025-10-10', 'done'),
(9, 9, 'Доставка вывесок', '2025-10-25', 'in_progress'),
(10, 10, 'Доставка листовок', '2025-10-05', 'canceled'),
(11, 11, 'Доставка наклеек', '2025-10-15', 'planned'),
(12, 12, 'Доставка баннеров', '2025-10-20', 'in_progress'),
(13, 13, 'Доставка брошюр', '2025-10-30', 'planned'),
(14, 14, 'Доставка футболок', '2025-10-10', 'done'),
(15, 15, 'Доставка вывесок', '2025-11-10', 'planned');

-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

CREATE TABLE `materials` (
  `material_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `cost_per_unit` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `materials`
--

INSERT INTO `materials` (`material_id`, `name`, `unit`, `cost_per_unit`) VALUES
(1, 'Баннер 3x2 м', 'шт', '1500.00'),
(2, 'Листовка А5', 'шт', '5.00'),
(3, 'Футболка с логотипом', 'шт', '300.00'),
(4, 'Вывеска 1x1 м', 'шт', '2000.00'),
(5, 'Наклейка 10x10 см', 'шт', '2.00'),
(6, 'Баннер 5x3 м', 'шт', '2500.00'),
(7, 'Брошюра А4', 'шт', '10.00'),
(8, 'Футболка промо', 'шт', '350.00'),
(9, 'Вывеска световая', 'шт', '3000.00'),
(10, 'Листовка цветная', 'шт', '7.00'),
(11, 'Наклейка большая', 'шт', '5.00'),
(12, 'Баннер уличный', 'шт', '1800.00'),
(13, 'Брошюра каталог', 'шт', '15.00'),
(14, 'Футболка зимняя', 'шт', '400.00'),
(15, 'Вывеска рекламная', 'шт', '2200.00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `total_cost` decimal(12,2) DEFAULT NULL,
  `status` varchar(15) DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `campaign_id`, `supplier_id`, `material_id`, `quantity`, `total_cost`, `status`, `order_date`) VALUES
(1, 1, 1, 1, '10.00', '15000.00', 'completed', '2025-09-22 06:50:14'),
(2, 2, 2, 2, '500.00', '2500.00', 'completed', '2025-09-22 06:50:14'),
(3, 3, 3, 3, '50.00', '15000.00', 'pending', '2025-09-22 06:50:14'),
(4, 4, 4, 4, '5.00', '10000.00', 'completed', '2025-09-22 06:50:14'),
(5, 5, 5, 5, '1000.00', '2000.00', 'completed', '2025-09-22 06:50:14'),
(6, 6, 6, 6, '8.00', '20000.00', 'pending', '2025-09-22 06:50:14'),
(7, 7, 7, 7, '200.00', '2000.00', 'completed', '2025-09-22 06:50:14'),
(8, 8, 8, 8, '30.00', '10500.00', 'completed', '2025-09-22 06:50:14'),
(9, 9, 9, 9, '3.00', '9000.00', 'pending', '2025-09-22 06:50:14'),
(10, 10, 10, 10, '600.00', '4200.00', 'canceled', '2025-09-22 06:50:14'),
(11, 11, 11, 11, '800.00', '4000.00', 'completed', '2025-09-22 06:50:14'),
(12, 12, 12, 12, '12.00', '21600.00', 'pending', '2025-09-22 06:50:14'),
(13, 13, 13, 13, '150.00', '2250.00', 'completed', '2025-09-22 06:50:14'),
(14, 14, 14, 14, '20.00', '8000.00', 'completed', '2025-09-22 06:50:14'),
(15, 15, 15, 15, '6.00', '13200.00', 'pending', '2025-09-22 06:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `registration_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`registration_id`, `client_id`, `status`, `created_at`, `expires_at`) VALUES
(1, 1, 'pending', '2025-09-22 06:56:11', '2025-09-23 02:53:00'),
(2, 2, 'confirmed', '2025-09-22 06:56:11', '2025-09-22 03:53:00'),
(3, 3, 'expired', '2025-09-22 06:56:11', '2025-09-22 01:53:00');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`report_id`, `campaign_id`, `type`, `file_path`, `created_at`) VALUES
(1, 1, 'offline_coverage', '/reports/report1.pdf', '2025-09-22 06:50:14'),
(2, 2, 'digital_performance', '/reports/report2.pdf', '2025-09-22 06:50:14'),
(3, 3, 'mixed', '/reports/report3.pdf', '2025-09-22 06:50:14'),
(4, 4, 'offline_coverage', '/reports/report4.pdf', '2025-09-22 06:50:14'),
(5, 5, 'digital_performance', '/reports/report5.pdf', '2025-09-22 06:50:14'),
(6, 6, 'mixed', '/reports/report6.pdf', '2025-09-22 06:50:14'),
(7, 7, 'offline_coverage', '/reports/report7.pdf', '2025-09-22 06:50:14'),
(8, 8, 'digital_performance', '/reports/report8.pdf', '2025-09-22 06:50:14'),
(9, 9, 'mixed', '/reports/report9.pdf', '2025-09-22 06:50:14'),
(10, 10, 'offline_coverage', '/reports/report10.pdf', '2025-09-22 06:50:14'),
(11, 11, 'digital_performance', '/reports/report11.pdf', '2025-09-22 06:50:14'),
(12, 12, 'mixed', '/reports/report12.pdf', '2025-09-22 06:50:14'),
(13, 13, 'offline_coverage', '/reports/report13.pdf', '2025-09-22 06:50:14'),
(14, 14, 'digital_performance', '/reports/report14.pdf', '2025-09-22 06:50:14'),
(15, 15, 'mixed', '/reports/report15.pdf', '2025-09-22 06:50:14');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `contact_info` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `name`, `type`, `contact_info`) VALUES
(1, 'Типография Кузбасс', 'typography', 'kuzbass@print.ru, +7 (3842) 987-654'),
(2, 'Логистик-Сервис', 'logistics', 'logistic@service.ru, +7 (3842) 876-543'),
(3, 'Реклама-Плюс', 'typography', 'plus@ad.ru, +7 (3842) 765-432'),
(4, 'Транспорт-Кузбасс', 'logistics', 'transport@kuz.ru, +7 (3842) 654-321'),
(5, 'Печать-Экспресс', 'typography', 'express@print.ru, +7 (3842) 543-210'),
(6, 'Доставка-Про', 'logistics', 'pro@delivery.ru, +7 (3842) 432-109'),
(7, 'Баннер-Мастер', 'typography', 'banner@master.ru, +7 (3842) 321-098'),
(8, 'Логистика-НН', 'logistics', 'nn@logistic.ru, +7 (3842) 210-987'),
(9, 'Промо-Печать', 'typography', 'promo@print.ru, +7 (3842) 109-876'),
(10, 'ТК Экспресс', 'logistics', 'tk@express.ru, +7 (3842) 098-765'),
(11, 'Типо-Кузбасс', 'typography', 'tipo@kuz.ru, +7 (3842) 876-109'),
(12, 'Логистик-Центр', 'logistics', 'center@logistic.ru, +7 (3842) 765-098'),
(13, 'Реклама-Старт', 'typography', 'start@ad.ru, +7 (3842) 654-087'),
(14, 'Доставка-Плюс', 'logistics', 'plus@delivery.ru, +7 (3842) 543-076'),
(15, 'Печать-Кузнецк', 'typography', 'kuznetsk@print.ru, +7 (3842) 432-065');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Indexes for table `banned_users`
--
ALTER TABLE `banned_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD KEY `idx_login` (`login`),
  ADD KEY `idx_banned_until` (`banned_until`);

--
-- Indexes for table `briefs`
--
ALTER TABLE `briefs`
  ADD PRIMARY KEY (`brief_id`),
  ADD KEY `campaign_id` (`campaign_id`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`campaign_id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Indexes for table `creatives`
--
ALTER TABLE `creatives`
  ADD PRIMARY KEY (`creative_id`),
  ADD KEY `campaign_id` (`campaign_id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `failed_captcha_attempts`
--
ALTER TABLE `failed_captcha_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_login` (`login`),
  ADD KEY `idx_attempt_time` (`attempt_time`);

--
-- Indexes for table `failed_logins`
--
ALTER TABLE `failed_logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_login` (`login`),
  ADD KEY `idx_attempt_time` (`attempt_time`);

--
-- Indexes for table `interactions`
--
ALTER TABLE `interactions`
  ADD PRIMARY KEY (`interaction_id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `logistics`
--
ALTER TABLE `logistics`
  ADD PRIMARY KEY (`logistics_id`),
  ADD KEY `campaign_id` (`campaign_id`);

--
-- Indexes for table `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`material_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `campaign_id` (`campaign_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `material_id` (`material_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`registration_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `campaign_id` (`campaign_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `banned_users`
--
ALTER TABLE `banned_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `briefs`
--
ALTER TABLE `briefs`
  MODIFY `brief_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `campaign_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `creatives`
--
ALTER TABLE `creatives`
  MODIFY `creative_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `failed_captcha_attempts`
--
ALTER TABLE `failed_captcha_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_logins`
--
ALTER TABLE `failed_logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `interactions`
--
ALTER TABLE `interactions`
  MODIFY `interaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `logistics`
--
ALTER TABLE `logistics`
  MODIFY `logistics_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `materials`
--
ALTER TABLE `materials`
  MODIFY `material_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `registration_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `briefs`
--
ALTER TABLE `briefs`
  ADD CONSTRAINT `briefs_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`campaign_id`);

--
-- Constraints for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD CONSTRAINT `campaigns_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`),
  ADD CONSTRAINT `campaigns_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `admins` (`admin_id`);

--
-- Constraints for table `creatives`
--
ALTER TABLE `creatives`
  ADD CONSTRAINT `creatives_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`campaign_id`),
  ADD CONSTRAINT `creatives_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `admins` (`admin_id`);

--
-- Constraints for table `interactions`
--
ALTER TABLE `interactions`
  ADD CONSTRAINT `interactions_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`),
  ADD CONSTRAINT `interactions_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`admin_id`);

--
-- Constraints for table `logistics`
--
ALTER TABLE `logistics`
  ADD CONSTRAINT `logistics_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`campaign_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`campaign_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`material_id`) REFERENCES `materials` (`material_id`);

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`campaign_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PeelyPulse - Рекламная компания</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
    <style>
        :root {
            --primary-light: #8e44ad;
            --secondary-light: #9b59b6;
            --primary-dark: #2c3e50;
            --secondary-dark: #34495e;
            --text-light: #333;
            --text-dark: #ecf0f1;
            --card-light: rgba(255, 255, 255, 0.9);
            --card-dark: rgba(44, 62, 80, 0.8);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-light), var(--secondary-light));
            color: var(--text-light);
            transition: all 0.5s ease;
            min-height: 100vh;
        }
        
        body.dark-theme {
            background: linear-gradient(135deg, var(--primary-dark), var(--secondary-dark));
            color: var(--text-dark);
        }
        
        .stars-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header & Navigation */
        header {
            padding: 20px 0;
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 28px;
            font-weight: 700;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .logo span {
            color: #f1c40f;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            gap: 25px;
        }
        
        nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 20px;
            transition: all 0.3s ease;
        }
        
        nav a:hover, nav a.active {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .auth-buttons {
            display: flex;
            gap: 15px;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 25px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-login {
            background: transparent;
            color: white;
            border: 2px solid white;
        }
        
        .btn-register {
            background: white;
            color: var(--primary-light);
        }
        
        .btn-login:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        .btn-register:hover {
            background: rgba(255, 255, 255, 0.9);
            transform: translateY(-2px);
        }
        
        .theme-toggle-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .theme-toggle-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        /* Hero Section */
        .hero {
            padding: 80px 0;
            text-align: center;
        }
        
        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
            color: white;
        }
        
        .hero p {
            font-size: 20px;
            max-width: 700px;
            margin: 0 auto 30px;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .btn-hero {
            background: #f1c40f;
            color: #333;
            padding: 12px 30px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 30px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-hero:hover {
            background: #f39c12;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        
        /* Features Section */
        .features {
            padding: 80px 0;
        }
        
        .section-title {
            text-align: center;
            font-size: 36px;
            margin-bottom: 50px;
            color: white;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .feature-card {
            background: var(--card-light);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        body.dark-theme .feature-card {
            background: var(--card-dark);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
        }
        
        .feature-icon {
            font-size: 40px;
            margin-bottom: 20px;
            color: var(--primary-light);
        }
        
        body.dark-theme .feature-icon {
            color: #f1c40f;
        }
        
        .feature-card h3 {
            font-size: 22px;
            margin-bottom: 15px;
        }
        
        /* Benefits Section */
        .benefits {
            padding: 80px 0;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .benefits-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: center;
        }
        
        .benefits-text h2 {
            font-size: 36px;
            margin-bottom: 20px;
            color: white;
        }
        
        .benefits-text p {
            margin-bottom: 20px;
            font-size: 18px;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .benefits-image {
            text-align: center;
        }
        
        .benefits-image img {
            max-width: 100%;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }
        
        /* Testimonials */
        .testimonials {
            padding: 80px 0;
        }
        
        .testimonials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .testimonial-card {
            background: var(--card-light);
            border-radius: 15px;
            padding: 30px;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        body.dark-theme .testimonial-card {
            background: var(--card-dark);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .testimonial-card:hover {
            transform: translateY(-5px);
        }
        
        .testimonial-text {
            font-style: italic;
            margin-bottom: 20px;
        }
        
        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .author-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--primary-light);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .author-info h4 {
            font-size: 18px;
        }
        
        .author-info p {
            font-size: 14px;
            opacity: 0.7;
        }
        
        /* CTA Section */
        .cta {
            padding: 80px 0;
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .cta h2 {
            font-size: 36px;
            margin-bottom: 20px;
            color: white;
        }
        
        .cta p {
            font-size: 20px;
            max-width: 700px;
            margin: 0 auto 30px;
            color: rgba(255, 255, 255, 0.9);
        }
        
        /* Footer */
        footer {
            padding: 50px 0 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }
        
        .footer-column h3 {
            font-size: 20px;
            margin-bottom: 20px;
            color: white;
        }
        
        .footer-column ul {
            list-style: none;
        }
        
        .footer-column ul li {
            margin-bottom: 10px;
        }
        
        .footer-column a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer-column a:hover {
            color: white;
        }
        
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: var(--card-light);
            border-radius: 15px;
            width: 90%;
            max-width: 450px;
            padding: 25px;
            position: relative;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
            max-height: 85vh;
            overflow-y: auto;
        }
        
        body.dark-theme .modal-content {
            background: var(--card-dark);
        }
        
        .compact-form {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .form-row {
            display: flex;
            gap: 12px;
        }
        
        .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        
        .form-group.full-width {
            flex: 0 0 100%;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            font-size: 13px;
            color: #666;
        }
        
        body.dark-theme .form-group label {
            color: #bbb;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        body.dark-theme .form-group input, body.dark-theme .form-group select {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
            color: var(--text-dark);
        }
        
        .form-group input:focus, .form-group select:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 2px rgba(142, 68, 173, 0.2);
        }
        
        .form-submit {
            width: 100%;
            padding: 12px;
            background: var(--primary-light);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .form-submit:hover {
            background: var(--secondary-light);
            transform: translateY(-2px);
        }
        
        .form-footer {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        
        .form-footer a {
            color: var(--primary-light);
            text-decoration: none;
            font-weight: 500;
        }
        
        body.dark-theme .form-footer a {
            color: #f1c40f;
        }
        
        .modal h2 {
            margin-bottom: 20px;
            text-align: center;
            font-size: 22px;
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 20px;
            cursor: pointer;
            color: #777;
            background: none;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .close-modal:hover {
            background: rgba(0, 0, 0, 0.1);
        }
        
        body.dark-theme .close-modal {
            color: #bbb;
        }
        
        body.dark-theme .close-modal:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        /* Стили для индикатора сложности пароля */
        .password-strength {
            height: 4px;
            background: #eee;
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
            border-radius: 2px;
        }
        
        .password-weak .password-strength-bar {
            background: #e74c3c;
            width: 33%;
        }
        
        .password-medium .password-strength-bar {
            background: #f39c12;
            width: 66%;
        }
        
        .password-strong .password-strength-bar {
            background: #2ecc71;
            width: 100%;
        }
        
        .password-hint {
            font-size: 12px;
            color: #777;
            margin-top: 3px;
        }
        
        body.dark-theme .password-hint {
            color: #bbb;
        }
        
        /* Адаптивность для мобильных устройств */
        @media (max-width: 480px) {
            .form-row {
                flex-direction: column;
                gap: 12px;
            }
            
            .modal-content {
                padding: 20px;
                max-width: 95%;
            }
            
            .header-content {
                flex-direction: column;
                gap: 20px;
            }
            
            nav ul {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .hero h1 {
                font-size: 36px;
            }
            
            .hero p {
                font-size: 18px;
            }
            
            .benefits-content {
                grid-template-columns: 1fr;
            }
            
            .section-title {
                font-size: 30px;
            }
        }
    </style>
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">Peely<span>Pulse</span></div>
                <nav>
                    <ul>
                        <li><a href="#" class="active">Главная</a></li>
                        <li><a href="#features">Ассортимент</a></li>
                        <li><a href="#benefits">Преимущества</a></li>
                        <li><a href="#testimonials">Отзывы</a></li>
                        <li><a href="#about">О нас</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <button class="btn btn-login" id="login-btn">Вход</button>
                    <button class="btn btn-register" id="register-btn">Регистрация</button>
                    <button class="theme-toggle-btn" id="theme-toggle">
                        <span id="theme-icon">🌙</span> Тема
                    </button>
                </div>
            </div>
        </div>
    </header>
    
    <section class="hero">
        <div class="container">
            <h1>Инновационные решения для вашего бизнеса</h1>
            <p>PeelyPulse предлагает передовые рекламные технологии, которые помогут вашему бренду выделиться на рынке и привлечь целевую аудиторию.</p>
            <button class="btn-hero">Узнать больше</button>
        </div>
    </section>
    
    <section class="features" id="features">
        <div class="container">
            <h2 class="section-title">Наши услуги</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <h3>Цифровой маркетинг</h3>
                    <p>Современные решения для продвижения в интернете, включая SEO, SMM и контекстную рекламу.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🎨</div>
                    <h3>Креативный дизайн</h3>
                    <p>Уникальный визуальный контент, который привлекает внимание и повышает вовлеченность.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📊</div>
                    <h3>Аналитика и отчетность</h3>
                    <p>Подробные отчеты и аналитика для оценки эффективности рекламных кампаний.</p>
                </div>
            </div>
        </div>
    </section>
    
    <section class="benefits" id="benefits">
        <div class="container">
            <div class="benefits-content">
                <div class="benefits-text">
                    <h2>Почему выбирают нас?</h2>
                    <p>PeelyPulse сочетает в себе многолетний опыт работы в рекламной индустрии с инновационными подходами к маркетингу.</p>
                    <p>Мы понимаем, что каждый бизнес уникален, поэтому предлагаем индивидуальные решения, соответствующие вашим целям и бюджету.</p>
                    <p>Наша команда профессионалов готова помочь вам достичь новых высот в развитии вашего бренда.</p>
                </div>
                <div class="benefits-image">
                    <!-- Placeholder for benefits image -->
                    <div style="width: 100%; height: 300px; background: rgba(255,255,255,0.2); border-radius: 15px; display: flex; align-items: center; justify-content: center; color: white; font-size: 18px;">
                        Изображение преимуществ
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="testimonials" id="testimonials">
        <div class="container">
            <h2 class="section-title">Что говорят наши клиенты</h2>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Благодаря PeelyPulse наш бренд стал узнаваемым в регионе. Результаты превзошли все ожидания!"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">ИП</div>
                        <div class="author-info">
                            <h4>Иван Петров</h4>
                            <p>Владелец бизнеса</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Профессиональный подход и креативные решения. Рекомендую PeelyPulse всем, кто хочет расти!"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">ОО</div>
                        <div class="author-info">
                            <h4>Ольга Орлова</h4>
                            <p>Маркетинг-директор</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Отличное соотношение цены и качества. Кампания окупилась уже в первый месяц после запуска."
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">АС</div>
                        <div class="author-info">
                            <h4>Алексей Смирнов</h4>
                            <p>Предприниматель</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="cta" id="about">
        <div class="container">
            <h2>Готовы начать работать с нами?</h2>
            <p>Свяжитесь с нами сегодня и получите бесплатную консультацию по вашей рекламной кампании.</p>
            <button class="btn-hero">Связаться с нами</button>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>PeelyPulse</h3>
                    <p>Инновационные рекламные решения для бизнеса любого масштаба.</p>
                </div>
                <div class="footer-column">
                    <h3>Услуги</h3>
                    <ul>
                        <li><a href="#">Цифровой маркетинг</a></li>
                        <li><a href="#">Брендинг</a></li>
                        <li><a href="#">Медийная реклама</a></li>
                        <li><a href="#">Аналитика</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Компания</h3>
                    <ul>
                        <li><a href="#">О нас</a></li>
                        <li><a href="#">Команда</a></li>
                        <li><a href="#">Карьера</a></li>
                        <li><a href="#">Контакты</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Контакты</h3>
                    <ul>
                        <li>г. Кемерово, ул. Примерная, 123</li>
                        <li>+7 (3842) 123-456</li>
                        <li>info@peelypulse.ru</li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 PeelyPulse. Все права защищены.</p>
            </div>
        </div>
    </footer>
    
    <!-- Login Modal -->
    <div class="modal" id="login-modal">
        <div class="modal-content">
            <button class="close-modal">&times;</button>
            <h2>Вход в систему</h2>
            <form id="login-form" class="compact-form">
                <div class="form-group full-width">
                    <label for="login-username">Логин</label>
                    <input type="text" id="login-username" name="login" required>
                </div>
                <div class="form-group full-width">
                    <label for="login-password">Пароль</label>
                    <input type="password" id="login-password" name="password" required>
                </div>
                <button type="submit" class="form-submit">Войти</button>
            </form>
            <div class="form-footer">
                <p>Нет аккаунта? <a href="#" id="switch-to-register">Зарегистрироваться</a></p>
            </div>
        </div>
    </div>
    
    <!-- Register Modal -->
    <div class="modal" id="register-modal">
        <div class="modal-content">
            <button class="close-modal">&times;</button>
            <h2>Регистрация</h2>
            <form id="register-form" class="compact-form">
                <div class="form-group full-width">
                    <label for="org-name">Название организации</label>
                    <input type="text" id="org-name" name="org_name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="full-name">ФИО</label>
                        <input type="text" id="full-name" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="contact-person">Контактное лицо</label>
                        <input type="text" id="contact-person" name="contact_person" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Телефон</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="inn">ИНН</label>
                        <input type="text" id="inn" name="inn" required>
                    </div>
                    <div class="form-group">
                        <label for="region">Регион</label>
                        <input type="text" id="region" name="region" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="industry">Отрасль</label>
                        <select id="industry" name="industry" required>
                            <option value="">Выберите отрасль</option>
                            <option value="розничная торговля">Розничная торговля</option>
                            <option value="строительство">Строительство</option>
                            <option value="услуги">Услуги</option>
                            <option value="производство">Производство</option>
                            <option value="ресторанный бизнес">Ресторанный бизнес</option>
                            <option value="финансы">Финансы</option>
                            <option value="промышленность">Промышленность</option>
                            <option value="сервис">Сервис</option>
                            <option value="маркетинг">Маркетинг</option>
                            <option value="логистика">Логистика</option>
                            <option value="энергия">Энергия</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="budget-segment">Бюджетный сегмент</label>
                        <select id="budget-segment" name="budget_segment" required>
                            <option value="">Выберите сегмент</option>
                            <option value="low">Низкий</option>
                            <option value="medium">Средний</option>
                            <option value="high">Высокий</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label for="username">Логин</label>
                    <input type="text" id="username" name="login" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Пароль</label>
                        <input type="password" id="password" name="password" required>
                        <div class="password-strength">
                            <div class="password-strength-bar"></div>
                        </div>
                        <div class="password-hint">Минимум 6 символов</div>
                    </div>
                    <div class="form-group">
                        <label for="confirm-password">Подтвердите пароль</label>
                        <input type="password" id="confirm-password" name="confirm_password" required>
                    </div>
                </div>
                
                <button type="submit" class="form-submit">Зарегистрироваться</button>
            </form>
            <div class="form-footer">
                <p>Уже есть аккаунт? <a href="#" id="switch-to-login">Войти</a></p>
            </div>
        </div>
    </div>
    
    <script>
        // Theme Toggle
        const toggleButton = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const body = document.body;
        
        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
            themeIcon.textContent = '☀️';
        }
        
        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
                themeIcon.textContent = '☀️';
            } else {
                localStorage.setItem('theme', 'light');
                themeIcon.textContent = '🌙';
            }
        });
        
        // Star Animation
        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 150;
        
        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }
        
        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }
        
        initStars();
        drawStars();
        
        window.addEventListener('resize', initStars);
        
        // Modal Handling
        const loginBtn = document.getElementById('login-btn');
        const registerBtn = document.getElementById('register-btn');
        const loginModal = document.getElementById('login-modal');
        const registerModal = document.getElementById('register-modal');
        const closeButtons = document.querySelectorAll('.close-modal');
        const switchToRegister = document.getElementById('switch-to-register');
        const switchToLogin = document.getElementById('switch-to-login');
        
        // Обработчики для кнопок входа и регистрации
        loginBtn.addEventListener('click', () => {
            loginModal.style.display = 'flex';
        });
        
        registerBtn.addEventListener('click', () => {
            registerModal.style.display = 'flex';
        });
        
        // Обработчики для закрытия модальных окон
        closeButtons.forEach(button => {
            button.addEventListener('click', () => {
                loginModal.style.display = 'none';
                registerModal.style.display = 'none';
            });
        });
        
        // Переключение между формами
        switchToRegister.addEventListener('click', (e) => {
            e.preventDefault();
            loginModal.style.display = 'none';
            registerModal.style.display = 'flex';
        });
        
        switchToLogin.addEventListener('click', (e) => {
            e.preventDefault();
            registerModal.style.display = 'none';
            loginModal.style.display = 'flex';
        });
        
        // Закрытие модальных окон при клике вне их
        window.addEventListener('click', (e) => {
            if (e.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (e.target === registerModal) {
                registerModal.style.display = 'none';
            }
        });
        
        // Индикатор сложности пароля
        const passwordInput = document.getElementById('password');
        const passwordStrength = document.querySelector('.password-strength');
        const passwordStrengthBar = document.querySelector('.password-strength-bar');
        const passwordHint = document.querySelector('.password-hint');
        
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            let hint = '';
            
            if (password.length >= 6) strength += 1;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 1;
            if (password.match(/\d/)) strength += 1;
            if (password.match(/[^a-zA-Z\d]/)) strength += 1;
            
            // Обновляем индикатор
            passwordStrength.className = 'password-strength';
            if (password.length > 0) {
                if (strength <= 1) {
                    passwordStrength.classList.add('password-weak');
                    hint = 'Слабый пароль';
                } else if (strength <= 2) {
                    passwordStrength.classList.add('password-medium');
                    hint = 'Средний пароль';
                } else {
                    passwordStrength.classList.add('password-strong');
                    hint = 'Сильный пароль';
                }
                passwordHint.textContent = hint;
            } else {
                passwordHint.textContent = 'Минимум 6 символов';
            }
        });
        
        // Проверка совпадения паролей в реальном времени
        const confirmPasswordInput = document.getElementById('confirm-password');
        
        confirmPasswordInput.addEventListener('input', function() {
            const password = passwordInput.value;
            const confirmPassword = this.value;
            
            if (confirmPassword && password !== confirmPassword) {
                this.style.borderColor = '#e74c3c';
            } else {
                this.style.borderColor = '';
            }
        });
        
        // Обработчик формы входа
        document.getElementById('login-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const submitBtn = this.querySelector('.form-submit');
            const originalText = submitBtn.textContent;
            
            // Показываем индикатор загрузки
            submitBtn.textContent = 'Вход...';
            submitBtn.disabled = true;
            
            // Здесь должна быть логика отправки данных на сервер
            setTimeout(() => {
                alert('Вход выполнен! (Это демо-версия)');
                loginModal.style.display = 'none';
                this.reset();
                
                // Восстанавливаем кнопку
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 1000);
        });
        
        // Обработчик формы регистрации
        document.getElementById('register-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            
            if (password !== confirmPassword) {
                alert('Пароли не совпадают!');
                return;
            }
            
            if (password.length < 6) {
                alert('Пароль должен содержать минимум 6 символов!');
                return;
            }
            
            const submitBtn = this.querySelector('.form-submit');
            const originalText = submitBtn.textContent;
            
            // Показываем индикатор загрузки
            submitBtn.textContent = 'Регистрация...';
            submitBtn.disabled = true;
            
            // Здесь должна быть логика отправки данных на сервер
            setTimeout(() => {
                alert('Регистрация завершена! Данные будут добавлены в базу. (Это демо-версия)');
                registerModal.style.display = 'none';
                this.reset();
                
                // Восстанавливаем кнопку
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 1000);
        });
        
        // Smooth scrolling for navigation links
        document.querySelectorAll('nav a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId.startsWith('#')) {
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>
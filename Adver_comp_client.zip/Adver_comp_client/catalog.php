<?php
include 'csrf.php';
include 'db.php';

// Проверяем авторизацию
if (!isset($_SESSION['client_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Получаем категорию из параметра
$category = $_GET['category'] ?? 'digital';

// Обработка добавления в заказ
if ($_POST['action'] ?? '' === 'add_to_order') {
    $product_name = $_POST['product_name'];
    $quantity = intval($_POST['quantity']);
    $unit_cost = floatval($_POST['unit_cost']);
    $total_cost = $unit_cost * $quantity;
    $client_id = $_SESSION['client_id'];
    
    // Создаем кампанию если ее нет
    $campaign_name = "Заказ: " . $product_name;
    $stmt = $conn->prepare("INSERT INTO campaigns (client_id, name, status) VALUES (?, ?, 'planned')");
    $stmt->bind_param("is", $client_id, $campaign_name);
    $stmt->execute();
    $campaign_id = $stmt->insert_id;
    
    // Добавляем заказ
    $stmt = $conn->prepare("INSERT INTO orders (campaign_id, product_name, quantity, unit_cost, total_cost, status) VALUES (?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("isidd", $campaign_id, $product_name, $quantity, $unit_cost, $total_cost);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Товар успешно добавлен в заказ!";
    } else {
        $_SESSION['error_message'] = "Ошибка при добавлении товара в заказ.";
    }
    
    header("Location: catalog.php?category=" . $category);
    exit;
}

// Получаем категорию из параметра
$category = $_GET['category'] ?? 'digital';

// Определяем товары по категориям
$products = [];
$category_icons = [
    'digital' => '📱',
    'design' => '🎨', 
    'analytics' => '📊',
    'internet' => '🌐',
    'outdoor' => '🏢',
    'special' => '🎯'
];

// Цифровой маркетинг
if ($category == 'digital') {
    $category_name = "Цифровой маркетинг";
    $category_description = "Современные решения для продвижения в интернете";
    $products = [
        ['name' => 'Баннер 3x2 м', 'unit' => 'шт', 'cost' => 1500.00, 'popular' => true],
        ['name' => 'Баннер 5x3 м', 'unit' => 'шт', 'cost' => 2500.00, 'popular' => true],
        ['name' => 'Баннер уличный', 'unit' => 'шт', 'cost' => 1800.00],
        ['name' => 'Всплывающее окно (pop-up)', 'unit' => 'кампания', 'cost' => 5000.00],
        ['name' => 'Контекстная реклама Яндекс', 'unit' => 'месяц', 'cost' => 15000.00, 'popular' => true],
        ['name' => 'Контекстная реклама Google', 'unit' => 'месяц', 'cost' => 12000.00],
        ['name' => 'SEO-продвижение сайта', 'unit' => 'месяц', 'cost' => 20000.00, 'popular' => true],
        ['name' => 'Таргетированная реклама ВК', 'unit' => 'кампания', 'cost' => 8000.00],
        ['name' => 'Таргетированная реклама Instagram', 'unit' => 'кампания', 'cost' => 10000.00],
    ];
}
// Креативный дизайн
elseif ($category == 'design') {
    $category_name = "Креативный дизайн";
    $category_description = "Уникальный визуальный контент для вашего бренда";
    $products = [
        ['name' => 'Листовка A5', 'unit' => 'шт', 'cost' => 5.00, 'popular' => true],
        ['name' => 'Листовка цветная', 'unit' => 'шт', 'cost' => 7.00],
        ['name' => 'Футболка с логотипом', 'unit' => 'шт', 'cost' => 300.00, 'popular' => true],
        ['name' => 'Футболка промо', 'unit' => 'шт', 'cost' => 350.00],
        ['name' => 'Футболка зимняя', 'unit' => 'шт', 'cost' => 400.00],
        ['name' => 'Брошюра A4', 'unit' => 'шт', 'cost' => 10.00],
        ['name' => 'Брошюра каталог', 'unit' => 'шт', 'cost' => 15.00, 'popular' => true],
        ['name' => 'Наклейка 10x10 см', 'unit' => 'шт', 'cost' => 2.00],
        ['name' => 'Наклейка большая', 'unit' => 'шт', 'cost' => 5.00],
        ['name' => 'Вывеска 1x1 м', 'unit' => 'шт', 'cost' => 2000.00],
        ['name' => 'Вывеска световая', 'unit' => 'шт', 'cost' => 3000.00, 'popular' => true],
        ['name' => 'Вывеска рекламная', 'unit' => 'шт', 'cost' => 2200.00],
    ];
}
// Аналитика и отчетность
elseif ($category == 'analytics') {
    $category_name = "Аналитика и отчетность";
    $category_description = "Глубокий анализ и детальная отчетность для вашего бизнеса";
    $products = [
        ['name' => 'Базовый отчет по эффективности', 'unit' => 'отчет', 'cost' => 5000.00],
        ['name' => 'Расширенная аналитика кампании', 'unit' => 'анализ', 'cost' => 15000.00, 'popular' => true],
        ['name' => 'Мониторинг упоминаний бренда', 'unit' => 'месяц', 'cost' => 8000.00],
        ['name' => 'Анализ конкурентов', 'unit' => 'отчет', 'cost' => 12000.00, 'popular' => true],
        ['name' => 'SEO-аудит сайта', 'unit' => 'аудит', 'cost' => 20000.00],
        ['name' => 'Настройка Google Analytics', 'unit' => 'проект', 'cost' => 7000.00],
        ['name' => 'Еженедельные отчеты', 'unit' => 'месяц', 'cost' => 15000.00],
        ['name' => 'Анализ целевой аудитории', 'unit' => 'исследование', 'cost' => 18000.00],
    ];
}
// Интернет-реклама
elseif ($category == 'internet') {
    $category_name = "Интернет-реклама";
    $category_description = "Комплексные решения для продвижения в digital-пространстве";
    $products = [
        ['name' => 'Медийная реклама на сайтах', 'unit' => 'кампания', 'cost' => 25000.00, 'popular' => true],
        ['name' => 'Видеореклама YouTube', 'unit' => 'кампания', 'cost' => 30000.00],
        ['name' => 'Email-рассылка', 'unit' => 'рассылка', 'cost' => 8000.00],
        ['name' => 'SMM-продвижение', 'unit' => 'месяц', 'cost' => 20000.00, 'popular' => true],
        ['name' => 'Продвижение в Telegram', 'unit' => 'кампания', 'cost' => 12000.00],
        ['name' => 'Реклама в мобильных приложениях', 'unit' => 'кампания', 'cost' => 18000.00],
        ['name' => 'Нативная реклама', 'unit' => 'публикация', 'cost' => 15000.00],
    ];
}
// Наружная реклама
elseif ($category == 'outdoor') {
    $category_name = "Наружная реклама";
    $category_description = "Эффективные решения для привлечения внимания на улицах города";
    $products = [
        ['name' => 'Билборд 3x6 м', 'unit' => 'месяц', 'cost' => 30000.00, 'popular' => true],
        ['name' => 'Ситилайт', 'unit' => 'месяц', 'cost' => 25000.00],
        ['name' => 'Штендер', 'unit' => 'шт', 'cost' => 5000.00],
        ['name' => 'Брендирование транспорта', 'unit' => 'единица', 'cost' => 15000.00, 'popular' => true],
        ['name' => 'Оформление витрин', 'unit' => 'точка', 'cost' => 20000.00],
        ['name' => 'Реклама в лифтах', 'unit' => 'месяц', 'cost' => 8000.00],
        ['name' => 'Реклама в ТЦ', 'unit' => 'месяц', 'cost' => 35000.00],
    ];
}
// Спецпроекты
elseif ($category == 'special') {
    $category_name = "Спецпроекты";
    $category_description = "Уникальные и комплексные решения для вашего бренда";
    $products = [
        ['name' => 'Промо-акция (1 день)', 'unit' => 'акция', 'cost' => 50000.00],
        ['name' => 'Корпоративное мероприятие', 'unit' => 'мероприятие', 'cost' => 100000.00, 'popular' => true],
        ['name' => 'Product placement', 'unit' => 'проект', 'cost' => 150000.00],
        ['name' => 'Спонсорство события', 'unit' => 'событие', 'cost' => 80000.00],
        ['name' => 'Комплексная рекламная кампания', 'unit' => 'кампания', 'cost' => 200000.00, 'popular' => true],
        ['name' => 'Бренд-активация', 'unit' => 'активация', 'cost' => 120000.00],
    ];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог - <?php echo $category_name; ?> | PeelyPulse</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
    <style>
        /* Все стили из dashboard.php */
        :root {
            --primary-light: #8e44ad;
            --secondary-light: #9b59b6;
            --primary-dark: #2c3e50;
            --secondary-dark: #34495e;
            --text-light: #333;
            --text-dark: #ecf0f1;
            --card-light: rgba(255, 255, 255, 0.9);
            --card-dark: rgba(44, 62, 80, 0.8);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-light), var(--secondary-light));
            color: var(--text-light);
            transition: all 0.5s ease;
            min-height: 100vh;
        }
        
        body.dark-theme {
            background: linear-gradient(135deg, var(--primary-dark), var(--secondary-dark));
            color: var(--text-dark);
        }
        
        .stars-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header стили из dashboard.php */
        header {
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            min-height: 60px;
        }

         .quantity-selector {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 15px 0;
            justify-content: center;
        }
        
        .quantity-btn {
            width: 35px;
            height: 35px;
            border: none;
            background: var(--primary-light);
            color: white;
            border-radius: 50%;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .quantity-btn:hover {
            background: var(--secondary-light);
            transform: scale(1.1);
        }
        
        .quantity-input {
            width: 60px;
            text-align: center;
            padding: 8px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
        }
        
        body.dark-theme .quantity-input {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.3);
            color: var(--text-dark);
        }
        
        .product-total {
            text-align: center;
            margin: 10px 0;
            font-size: 18px;
            font-weight: 600;
            color: var(--primary-light);
        }
        
        body.dark-theme .product-total {
            color: #f1c40f;
        }
        
        /* Стили для уведомлений */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin: 20px 0;
            font-weight: 500;
            text-align: center;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        body.dark-theme .alert-success {
            background: rgba(40, 167, 69, 0.2);
            color: #75b798;
            border-color: rgba(40, 167, 69, 0.3);
        }
        
        body.dark-theme .alert-error {
            background: rgba(220, 53, 69, 0.2);
            color: #e6a2a9;
            border-color: rgba(220, 53, 69, 0.3);
        }
        
        .logo {
            font-size: 30px;
            font-weight: 700;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
            height: 100%;
        }
        
        .logo span {
            color: #f1c40f;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            gap: 20px;
            align-items: center;
            height: 100%;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 10px 18px;
            border-radius: 20px;
            transition: all 0.3s ease;
            font-size: 15px;
            display: flex;
            align-items: center;
            height: 100%;
        }
        
        nav a:hover, nav a.active {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .auth-buttons {
            display: flex;
            gap: 15px;
            align-items: center;
            height: 100%;
        }

        .about-link {
            min-width: 90px;
            text-align: center;
            justify-content: center;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
            height: 100%;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 18px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            min-width: 120px;
            height: 100%;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .user-info:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-1px);
        }

        .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: linear-gradient(135deg, #f1c40f, #f39c12);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 12px rgba(241, 196, 15, 0.3);
            flex-shrink: 0;
        }

        .btn-logout {
            background: transparent;
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
            padding: 10px 20px;
            border-radius: 20px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            font-size: 14px;
            min-width: 80px;
            text-align: center;
            white-space: nowrap;
        }

        .btn-logout:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .theme-toggle-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            white-space: nowrap;
            height: 100%;
        }

        .theme-toggle-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        /* Стили для каталога */
        .catalog-container {
            padding: 40px 0;
        }

        .catalog-header {
            text-align: center;
            margin-bottom: 50px;
            color: white;
        }

        .catalog-header h1 {
            font-size: 48px;
            margin-bottom: 15px;
            color: white;
        }

        .catalog-header p {
            font-size: 20px;
            max-width: 600px;
            margin: 0 auto;
            color: rgba(255, 255, 255, 0.9);
        }

        .category-nav {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 50px;
        }

        .category-btn {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.2);
            padding: 12px 25px;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .category-btn:hover, .category-btn.active {
            background: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.4);
            transform: translateY(-2px);
        }

        .category-btn.active {
            background: rgba(255, 255, 255, 0.3);
            border-color: #f1c40f;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
            margin-bottom: 50px;
        }

        .product-card {
            background: var(--card-light);
            border-radius: 20px;
            padding: 30px;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            position: relative;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        body.dark-theme .product-card {
            background: var(--card-dark);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }

        .popular-badge {
            position: absolute;
            top: -10px;
            right: 20px;
            background: linear-gradient(135deg, #f1c40f, #f39c12);
            color: #333;
            padding: 5px 15px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(241, 196, 15, 0.3);
        }

        .product-name {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary-light);
            line-height: 1.3;
        }

        body.dark-theme .product-name {
            color: #f1c40f;
        }

        .product-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding: 15px 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        body.dark-theme .product-details {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .product-unit {
            color: #666;
            font-size: 16px;
            font-weight: 500;
        }

        body.dark-theme .product-unit {
            color: #bbb;
        }

        .product-cost {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary-light);
        }

        body.dark-theme .product-cost {
            color: #f1c40f;
        }

        .order-btn {
            width: 100%;
            padding: 15px;
            background: var(--primary-light);
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            margin-top: auto;
        }

        .order-btn:hover {
            background: var(--secondary-light);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 12px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            margin-top: 20px;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .category-icon {
            font-size: 24px;
        }

        /* Адаптивность */
        @media (max-width: 768px) {
            .products-grid {
                grid-template-columns: 1fr;
            }
            
            .catalog-header h1 {
                font-size: 36px;
            }
            
            .category-nav {
                gap: 10px;
            }
            
            .category-btn {
                padding: 10px 15px;
                font-size: 14px;
            }
            
            .product-card {
                padding: 20px;
            }
        }

        @media (max-width: 480px) {
            .header-content {
                flex-direction: column;
                gap: 20px;
            }
            
            nav ul {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .catalog-header h1 {
                font-size: 30px;
            }
            
            .catalog-header p {
                font-size: 16px;
            }
            
            .user-menu {
                flex-direction: row;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">Peely<span>Pulse</span></div>
                <nav>
                    <ul>
                        <li><a href="dashboard.php">Главная</a></li>
                        <li><a href="dashboard.php#features">Ассортимент</a></li>
                        <li><a href="dashboard.php#benefits">Преимущества</a></li>
                        <li><a href="dashboard.php#testimonials">Отзывы</a></li>
                        <li><a href="dashboard.php#about" class="about-link">О нас</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <div class="user-menu">
                        <a href="profile.php" class="user-info">
                            <div class="user-avatar">
                                <?php 
                                $login = $_SESSION['client_login'];
                                echo strtoupper(mb_substr($login, 0, 1)); 
                                ?>
                            </div>
                            <span><?php echo htmlspecialchars($login); ?></span>
                        </a>
                        <a href="logout.php" class="btn-logout">Выйти</a>
                    </div>
                    <button class="theme-toggle-btn" id="theme-toggle">
                        <span id="theme-icon">🌙</span> Тема
                    </button>
                </div>
            </div>
        </div>
    </header>

    <div class="container catalog-container">
        <div class="catalog-header">
            <h1><?php echo $category_icons[$category] . ' ' . $category_name; ?></h1>
            <p><?php echo $category_description; ?></p>
        </div>

        <div class="category-nav">
            <a href="catalog.php?category=digital" class="category-btn <?php echo $category == 'digital' ? 'active' : ''; ?>">
                <span class="category-icon">📱</span> Цифровой маркетинг
            </a>
            <a href="catalog.php?category=design" class="category-btn <?php echo $category == 'design' ? 'active' : ''; ?>">
                <span class="category-icon">🎨</span> Креативный дизайн
            </a>
            <a href="catalog.php?category=analytics" class="category-btn <?php echo $category == 'analytics' ? 'active' : ''; ?>">
                <span class="category-icon">📊</span> Аналитика
            </a>
            <a href="catalog.php?category=internet" class="category-btn <?php echo $category == 'internet' ? 'active' : ''; ?>">
                <span class="category-icon">🌐</span> Интернет-реклама
            </a>
            <a href="catalog.php?category=outdoor" class="category-btn <?php echo $category == 'outdoor' ? 'active' : ''; ?>">
                <span class="category-icon">🏢</span> Наружная реклама
            </a>
            <a href="catalog.php?category=special" class="category-btn <?php echo $category == 'special' ? 'active' : ''; ?>">
                <span class="category-icon">🎯</span> Спецпроекты
            </a>
        </div>

        <div class="products-grid">
            <?php foreach ($products as $product): ?>
            <div class="product-card">
                <?php if (isset($product['popular']) && $product['popular']): ?>
                <div class="popular-badge">Популярное</div>
                <?php endif; ?>
                
                <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                
                <div class="product-details">
                    <span class="product-unit"><?php echo htmlspecialchars($product['unit']); ?></span>
                    <span class="product-cost"><?php echo number_format($product['cost'], 0, '.', ' '); ?> руб.</span>
                </div>
                
                <button class="order-btn" data-product="<?php echo htmlspecialchars($product['name']); ?>" data-cost="<?php echo $product['cost']; ?>">
                    Добавить в заказ
                </button>
            </div>
            <?php endforeach; ?>
        </div>

        <div style="text-align: center;">
            <a href="dashboard.php#features" class="back-btn">← Вернуться к услугам</a>
        </div>
    </div>

    <script>
        // Star Animation (как в dashboard.php)
        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 150;
        
        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }
        
        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }
        
        initStars();
        drawStars();
        
        window.addEventListener('resize', initStars);
        
        // Theme Toggle
        const toggleButton = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const body = document.body;
        
        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
            themeIcon.textContent = '☀️';
        }
        
        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
                themeIcon.textContent = '☀️';
            } else {
                localStorage.setItem('theme', 'light');
                themeIcon.textContent = '🌙';
            }
        });

        // Обработчик для кнопок заказа
        document.querySelectorAll('.order-btn').forEach(button => {
            button.addEventListener('click', function() {
                const productName = this.getAttribute('data-product');
                const productCost = this.getAttribute('data-cost');
                
                // Временное решение - можно интегрировать с системой заказов
                const originalText = this.textContent;
                this.textContent = 'Добавлено ✓';
                this.style.background = '#27ae60';
                this.disabled = true;
                
                setTimeout(() => {
                    this.textContent = originalText;
                    this.style.background = '';
                    this.disabled = false;
                }, 2000);
                
                // Показываем уведомление
                alert(`Товар "${productName}" добавлен в заказ!\nСтоимость: ${parseFloat(productCost).toLocaleString('ru-RU')} руб.`);
            });
        });

        // Плавная прокрутка для навигации
        document.querySelectorAll('nav a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId.startsWith('#')) {
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                } else if (targetId.includes('dashboard.php')) {
                    window.location.href = targetId;
                }
            });
        });
    </script>
</body>
</html>
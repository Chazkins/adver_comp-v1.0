<?php
// register_handler.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'db.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Проверка CSRF-токена
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            $response['message'] = 'Ошибка безопасности. Пожалуйста, обновите страницу.';
            echo json_encode($response);
            exit;
        }

        // Получаем данные из формы
        $org_name = trim($_POST['org_name']);
        $full_name = trim($_POST['full_name']);
        $contact_person = trim($_POST['contact_person']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $inn = trim($_POST['inn']);
        $industry = trim($_POST['industry']);
        $budget_segment = trim($_POST['budget_segment']);
        $region = trim($_POST['region']);
        $login = trim($_POST['login']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        // Валидация данных
        if (empty($org_name) || empty($full_name) || empty($email) || empty($phone) || 
            empty($inn) || empty($industry) || empty($budget_segment) || empty($region) || 
            empty($login) || empty($password)) {
            $response['message'] = 'Все обязательные поля должны быть заполнены.';
            echo json_encode($response);
            exit;
        }

        if ($password !== $confirm_password) {
            $response['message'] = 'Пароли не совпадают.';
            echo json_encode($response);
            exit;
        }

        if (strlen($password) < 6) {
            $response['message'] = 'Пароль должен содержать минимум 6 символов.';
            echo json_encode($response);
            exit;
        }

        // Проверяем, существует ли пользователь с таким логином или email
        $check_stmt = $conn->prepare("SELECT client_id FROM clients WHERE login = ? OR email = ?");
        $check_stmt->bind_param("ss", $login, $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $response['message'] = 'Пользователь с таким логином или email уже существует.';
            echo json_encode($response);
            exit;
        }

        // Хэшируем пароль
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Вставляем данные в таблицу clients
        $insert_client = $conn->prepare("
            INSERT INTO clients (org_name, full_name, contact_person, email, phone, inn, industry, budget_segment, region, login, password_hash) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $insert_client->bind_param(
            "sssssssssss", 
            $org_name, $full_name, $contact_person, $email, $phone, 
            $inn, $industry, $budget_segment, $region, $login, $password_hash
        );

        if ($insert_client->execute()) {
            $client_id = $conn->insert_id;
            
            // Создаем запись в таблице registration
            $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
            $insert_registration = $conn->prepare("
                INSERT INTO registration (client_id, status, expires_at) 
                VALUES (?, 'pending', ?)
            ");
            $insert_registration->bind_param("is", $client_id, $expires_at);
            
            if ($insert_registration->execute()) {
                $response['success'] = true;
                $response['message'] = 'Регистрация успешно завершена! Ваши данные будут проверены администратором.';
                
                // Логируем успешную регистрацию
                error_log("Новый клиент зарегистрирован: $login (ID: $client_id)");
            } else {
                $response['message'] = 'Ошибка при создании записи регистрации: ' . $conn->error;
            }
        } else {
            $response['message'] = 'Ошибка при регистрации: ' . $conn->error;
        }

    } catch (Exception $e) {
        $response['message'] = 'Ошибка при обработке запроса: ' . $e->getMessage();
        error_log("Registration error: " . $e->getMessage());
    }
} else {
    $response['message'] = 'Неверный метод запроса.';
}

echo json_encode($response);
?>
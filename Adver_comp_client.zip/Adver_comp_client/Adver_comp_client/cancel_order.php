<?php
session_start();
include 'db.php';
include 'csrf.php';

// Проверяем авторизацию
if (!isset($_SESSION['client_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Проверяем CSRF токен
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error_message'] = "Ошибка безопасности";
    header('Location: profile.php');
    exit;
}

if ($_POST['order_id'] ?? '') {
    $order_id = intval($_POST['order_id']);
    $client_id = $_SESSION['client_id'];
    
    // Обновляем статус заказа
    $stmt = $conn->prepare("UPDATE client_orders SET status = 'canceled' WHERE order_id = ? AND client_id = ?");
    $stmt->bind_param("ii", $order_id, $client_id);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Заказ успешно отменен";
    } else {
        $_SESSION['error_message'] = "Ошибка при отмене заказа";
    }
    
    $stmt->close();
}

header('Location: profile.php');
exit;
?>
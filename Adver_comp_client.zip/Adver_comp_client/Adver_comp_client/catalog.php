<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'csrf.php';
include 'db.php';

// Проверяем авторизацию
if (!isset($_SESSION['client_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Получаем категорию из параметра
$category = $_GET['category'] ?? 'digital';

// Обработка добавления в заказ
if ($_POST['action'] ?? '' === 'add_to_order') {
    $product_name = $_POST['product_name'];
    $quantity = intval($_POST['quantity']);
    $unit_cost = floatval($_POST['unit_cost']);
    $client_id = $_SESSION['client_id'];
    $total_cost = $unit_cost * $quantity;
    
    try {
        // Добавляем заказ в таблицу client_orders
        $insert_sql = "INSERT INTO client_orders (client_id, product_name, quantity, unit_cost, total_cost, status) VALUES (?, ?, ?, ?, ?, 'pending')";
        $insert_stmt = $conn->prepare($insert_sql);
        
        if (!$insert_stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $insert_stmt->bind_param("isidd", $client_id, $product_name, $quantity, $unit_cost, $total_cost);
        
        if (!$insert_stmt->execute()) {
            throw new Exception("Insert failed: " . $insert_stmt->error);
        }
        
        $insert_stmt->close();
        $_SESSION['success_message'] = "Товар '{$product_name}' успешно добавлен в заказ!";
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Ошибка при добавлении в заказ: " . $e->getMessage();
        error_log("Order error: " . $e->getMessage());
    }
    
    header("Location: catalog.php?category=" . $category);
    exit;
}

// Определяем товары по категориям
$products = [];
$category_icons = [
    'digital' => '📱',
    'design' => '🎨', 
    'analytics' => '📊',
    'internet' => '🌐',
    'outdoor' => '🏢',
    'special' => '🎯'
];

// Цифровой маркетинг
if ($category == 'digital') {
    $category_name = "Цифровой маркетинг";
    $category_description = "Современные решения для продвижения в интернете";
    $products = [
        ['name' => 'Баннер 3x2 м', 'unit' => 'шт', 'cost' => 1500.00, 'popular' => true],
        ['name' => 'Баннер 5x3 м', 'unit' => 'шт', 'cost' => 2500.00, 'popular' => true],
        ['name' => 'Баннер уличный', 'unit' => 'шт', 'cost' => 1800.00],
        ['name' => 'Всплывающее окно (pop-up)', 'unit' => 'кампания', 'cost' => 5000.00],
        ['name' => 'Контекстная реклама Яндекс', 'unit' => 'месяц', 'cost' => 15000.00, 'popular' => true],
        ['name' => 'Контекстная реклама Google', 'unit' => 'месяц', 'cost' => 12000.00],
        ['name' => 'SEO-продвижение сайта', 'unit' => 'месяц', 'cost' => 20000.00, 'popular' => true],
        ['name' => 'Таргетированная реклама ВК', 'unit' => 'кампания', 'cost' => 8000.00],
        ['name' => 'Таргетированная реклама Instagram', 'unit' => 'кампания', 'cost' => 10000.00],
    ];
}
// Креативный дизайн
elseif ($category == 'design') {
    $category_name = "Креативный дизайн";
    $category_description = "Уникальный визуальный контент для вашего бренда";
    $products = [
        ['name' => 'Листовка A5', 'unit' => 'шт', 'cost' => 5.00, 'popular' => true],
        ['name' => 'Листовка цветная', 'unit' => 'шт', 'cost' => 7.00],
        ['name' => 'Футболка с логотипом', 'unit' => 'шт', 'cost' => 300.00, 'popular' => true],
        ['name' => 'Футболка промо', 'unit' => 'шт', 'cost' => 350.00],
        ['name' => 'Футболка зимняя', 'unit' => 'шт', 'cost' => 400.00],
        ['name' => 'Брошюра A4', 'unit' => 'шт', 'cost' => 10.00],
        ['name' => 'Брошюра каталог', 'unit' => 'шт', 'cost' => 15.00, 'popular' => true],
        ['name' => 'Наклейка 10x10 см', 'unit' => 'шт', 'cost' => 2.00],
        ['name' => 'Наклейка большая', 'unit' => 'шт', 'cost' => 5.00],
        ['name' => 'Вывеска 1x1 м', 'unit' => 'шт', 'cost' => 2000.00],
        ['name' => 'Вывеска световая', 'unit' => 'шт', 'cost' => 3000.00, 'popular' => true],
        ['name' => 'Вывеска рекламная', 'unit' => 'шт', 'cost' => 2200.00],
    ];
}
// Аналитика и отчетность
elseif ($category == 'analytics') {
    $category_name = "Аналитика и отчетность";
    $category_description = "Глубокий анализ и детальная отчетность для вашего бизнеса";
    $products = [
        ['name' => 'Базовый отчет по эффективности', 'unit' => 'отчет', 'cost' => 5000.00],
        ['name' => 'Расширенная аналитика кампании', 'unit' => 'анализ', 'cost' => 15000.00, 'popular' => true],
        ['name' => 'Мониторинг упоминаний бренда', 'unit' => 'месяц', 'cost' => 8000.00],
        ['name' => 'Анализ конкурентов', 'unit' => 'отчет', 'cost' => 12000.00, 'popular' => true],
        ['name' => 'SEO-аудит сайта', 'unit' => 'аудит', 'cost' => 20000.00],
        ['name' => 'Настройка Google Analytics', 'unit' => 'проект', 'cost' => 7000.00],
        ['name' => 'Еженедельные отчеты', 'unit' => 'месяц', 'cost' => 15000.00],
        ['name' => 'Анализ целевой аудитории', 'unit' => 'исследование', 'cost' => 18000.00],
    ];
}
// Интернет-реклама
elseif ($category == 'internet') {
    $category_name = "Интернет-реклама";
    $category_description = "Комплексные решения для продвижения в digital-пространстве";
    $products = [
        ['name' => 'Медийная реклама на сайтах', 'unit' => 'кампания', 'cost' => 25000.00, 'popular' => true],
        ['name' => 'Видеореклама YouTube', 'unit' => 'кампания', 'cost' => 30000.00],
        ['name' => 'Email-рассылка', 'unit' => 'рассылка', 'cost' => 8000.00],
        ['name' => 'SMM-продвижение', 'unit' => 'месяц', 'cost' => 20000.00, 'popular' => true],
        ['name' => 'Продвижение в Telegram', 'unit' => 'кампания', 'cost' => 12000.00],
        ['name' => 'Реклама в мобильных приложениях', 'unit' => 'кампания', 'cost' => 18000.00],
        ['name' => 'Нативная реклама', 'unit' => 'публикация', 'cost' => 15000.00],
    ];
}
// Наружная реклама
elseif ($category == 'outdoor') {
    $category_name = "Наружная реклама";
    $category_description = "Эффективные решения для привлечения внимания на улицах города";
    $products = [
        ['name' => 'Билборд 3x6 м', 'unit' => 'месяц', 'cost' => 30000.00, 'popular' => true],
        ['name' => 'Ситилайт', 'unit' => 'месяц', 'cost' => 25000.00],
        ['name' => 'Штендер', 'unit' => 'шт', 'cost' => 5000.00],
        ['name' => 'Брендирование транспорта', 'unit' => 'единица', 'cost' => 15000.00, 'popular' => true],
        ['name' => 'Оформление витрин', 'unit' => 'точка', 'cost' => 20000.00],
        ['name' => 'Реклама в лифтах', 'unit' => 'месяц', 'cost' => 8000.00],
        ['name' => 'Реклама в ТЦ', 'unit' => 'месяц', 'cost' => 35000.00],
    ];
}
// Спецпроекты
elseif ($category == 'special') {
    $category_name = "Спецпроекты";
    $category_description = "Уникальные и комплексные решения для вашего бренда";
    $products = [
        ['name' => 'Промо-акция (1 день)', 'unit' => 'акция', 'cost' => 50000.00],
        ['name' => 'Корпоративное мероприятие', 'unit' => 'мероприятие', 'cost' => 100000.00, 'popular' => true],
        ['name' => 'Product placement', 'unit' => 'проект', 'cost' => 150000.00],
        ['name' => 'Спонсорство события', 'unit' => 'событие', 'cost' => 80000.00],
        ['name' => 'Комплексная рекламная кампания', 'unit' => 'кампания', 'cost' => 200000.00, 'popular' => true],
        ['name' => 'Бренд-активация', 'unit' => 'активация', 'cost' => 120000.00],
    ];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог - <?php echo $category_name; ?> | PeelyPulse</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="css-styles/catalog.css">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">Peely<span>Pulse</span></div>
                <nav>
                    <ul>
                        <li><a href="dashboard.php">Главная</a></li>
                        <li><a href="dashboard.php#features">Ассортимент</a></li>
                        <li><a href="dashboard.php#benefits">Преимущества</a></li>
                        <li><a href="dashboard.php#testimonials">Отзывы</a></li>
                        <li><a href="dashboard.php#about" class="about-link">О нас</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <div class="user-menu">
                        <a href="profile.php" class="user-info">
                            <div class="user-avatar">
                                <?php 
                                $login = $_SESSION['client_login'];
                                echo strtoupper(mb_substr($login, 0, 1)); 
                                ?>
                            </div>
                            <span><?php echo htmlspecialchars($login); ?></span>
                        </a>
                        <a href="logout.php" class="btn-logout">Выйти</a>
                    </div>
                    <button class="theme-toggle-btn" id="theme-toggle">
                        <span id="theme-icon">🌙</span> Тема
                    </button>
                </div>
            </div>
        </div>
    </header>

    <div class="container catalog-container">
        <div class="catalog-header">
            <h1><?php echo $category_icons[$category] . ' ' . $category_name; ?></h1>
            <p><?php echo $category_description; ?></p>
        </div>

        <!-- Показываем уведомления -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="category-nav">
            <a href="catalog.php?category=digital" class="category-btn <?php echo $category == 'digital' ? 'active' : ''; ?>">
                <span class="category-icon">📱</span> Цифровой маркетинг
            </a>
            <a href="catalog.php?category=design" class="category-btn <?php echo $category == 'design' ? 'active' : ''; ?>">
                <span class="category-icon">🎨</span> Креативный дизайн
            </a>
            <a href="catalog.php?category=analytics" class="category-btn <?php echo $category == 'analytics' ? 'active' : ''; ?>">
                <span class="category-icon">📊</span> Аналитика
            </a>
            <a href="catalog.php?category=internet" class="category-btn <?php echo $category == 'internet' ? 'active' : ''; ?>">
                <span class="category-icon">🌐</span> Интернет-реклама
            </a>
            <a href="catalog.php?category=outdoor" class="category-btn <?php echo $category == 'outdoor' ? 'active' : ''; ?>">
                <span class="category-icon">🏢</span> Наружная реклама
            </a>
            <a href="catalog.php?category=special" class="category-btn <?php echo $category == 'special' ? 'active' : ''; ?>">
                <span class="category-icon">🎯</span> Спецпроекты
            </a>
        </div>

        <div class="products-grid">
            <?php foreach ($products as $product): ?>
            <div class="product-card">
                <?php if (isset($product['popular']) && $product['popular']): ?>
                <div class="popular-badge">Популярное</div>
                <?php endif; ?>
                
                <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                
                <div class="product-details">
                    <span class="product-unit"><?php echo htmlspecialchars($product['unit']); ?></span>
                    <span class="product-cost"><?php echo number_format($product['cost'], 0, '.', ' '); ?> руб.</span>
                </div>
                
                <!-- Счетчик количества -->
                <div class="quantity-selector">
                    <button class="quantity-btn minus" data-product="<?php echo htmlspecialchars($product['name']); ?>">-</button>
                    <input type="number" class="quantity-input" value="1" min="1" max="100" 
                           data-product="<?php echo htmlspecialchars($product['name']); ?>" 
                           data-base-cost="<?php echo $product['cost']; ?>">
                    <button class="quantity-btn plus" data-product="<?php echo htmlspecialchars($product['name']); ?>">+</button>
                </div>
                
                <div class="product-total">
                    Итого: <span class="total-cost" data-product="<?php echo htmlspecialchars($product['name']); ?>">
                        <?php echo number_format($product['cost'], 0, '.', ' '); ?>
                    </span> руб.
                </div>
                
                <form method="POST" class="order-form">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="hidden" name="action" value="add_to_order">
                    <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($product['name']); ?>">
                    <input type="hidden" name="unit_cost" value="<?php echo $product['cost']; ?>">
                    <input type="hidden" name="quantity" value="1" class="quantity-hidden" data-product="<?php echo htmlspecialchars($product['name']); ?>">
                    
                    <button type="submit" class="order-btn">
                        Добавить в заказ
                    </button>
                </form>
            </div>
            <?php endforeach; ?>
        </div>

        <div style="text-align: center;">
            <a href="dashboard.php#features" class="back-btn">← Вернуться к услугам</a>
        </div>
    </div>

    <script>
        // Theme Toggle
        const toggleButton = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const body = document.body;
        
        // Проверяем сохраненную тему
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            body.classList.add('dark-theme');
            themeIcon.textContent = '☀️';
        } else {
            body.classList.remove('dark-theme');
            themeIcon.textContent = '🌙';
        }
        
        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
                themeIcon.textContent = '☀️';
            } else {
                localStorage.setItem('theme', 'light');
                themeIcon.textContent = '🌙';
            }
            // Перерисовываем звезды при смене темы
            initStars();
        });
        
        // Star Animation
        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 150;
        
        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }
        
        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }
        
        initStars();
        drawStars();
        
        window.addEventListener('resize', initStars);

        // Функционал счетчика количества и динамической цены
        document.querySelectorAll('.quantity-btn').forEach(button => {
            button.addEventListener('click', function() {
                const productName = this.getAttribute('data-product');
                const input = document.querySelector(`.quantity-input[data-product="${productName}"]`);
                const baseCost = parseFloat(input.getAttribute('data-base-cost'));
                let quantity = parseInt(input.value);
                
                if (this.classList.contains('plus')) {
                    quantity++;
                } else if (this.classList.contains('minus') && quantity > 1) {
                    quantity--;
                }
                
                input.value = quantity;
                updateProductTotal(productName, baseCost, quantity);
            });
        });
        
        // Обновление при ручном вводе
        document.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('input', function() {
                const productName = this.getAttribute('data-product');
                const baseCost = parseFloat(this.getAttribute('data-base-cost'));
                let quantity = parseInt(this.value) || 1;
                
                if (quantity < 1) quantity = 1;
                if (quantity > 100) quantity = 100;
                
                this.value = quantity;
                updateProductTotal(productName, baseCost, quantity);
            });
        });
        
        function updateProductTotal(productName, baseCost, quantity) {
            const totalElement = document.querySelector(`.total-cost[data-product="${productName}"]`);
            const hiddenInput = document.querySelector(`.quantity-hidden[data-product="${productName}"]`);
            const totalCost = baseCost * quantity;
            
            totalElement.textContent = totalCost.toLocaleString('ru-RU');
            hiddenInput.value = quantity;
        }
        
        // Обработка отправки формы
        document.querySelectorAll('.order-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitBtn = this.querySelector('.order-btn');
                const originalText = submitBtn.textContent;
                
                // Показываем индикатор загрузки
                submitBtn.textContent = 'Добавляем...';
                submitBtn.disabled = true;
                
                // Форма отправится обычным способом
                setTimeout(() => {
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                }, 2000);
            });
        });

        // Плавная прокрутка для навигации
        document.querySelectorAll('nav a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId.startsWith('#')) {
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                } else if (targetId.includes('dashboard.php')) {
                    window.location.href = targetId;
                }
            });
        });
    </script>
</body>
</html>
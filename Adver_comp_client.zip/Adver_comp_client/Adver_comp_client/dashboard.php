<?php 
include 'csrf.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PeelyPulse - Рекламная компания</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
    <style>
        /* Все предыдущие стили остаются без изменений */
        :root {
            --primary-light: #8e44ad;
            --secondary-light: #9b59b6;
            --primary-dark: #2c3e50;
            --secondary-dark: #34495e;
            --text-light: #333;
            --text-dark: #ecf0f1;
            --card-light: rgba(255, 255, 255, 0.9);
            --card-dark: rgba(44, 62, 80, 0.8);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-light), var(--secondary-light));
            color: var(--text-light);
            transition: all 0.5s ease;
            min-height: 100vh;
        }
        
        body.dark-theme {
            background: linear-gradient(135deg, var(--primary-dark), var(--secondary-dark));
            color: var(--text-dark);
        }
        
        .stars-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
       /* Header & Navigation */
header {
    padding: 15px 0; /* Уменьшил отступы сверху и снизу */
    position: sticky;
    top: 0;
    z-index: 100;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}
        
       .header-content {
    display: flex;
    justify-content: space-between;
    align-items: center; /* Это выравнивает все элементы по центру по вертикали */
    min-height: 60px; /* Фиксированная минимальная высота */
}
        
     .logo {
    font-size: 30px;
    font-weight: 700;
    color: white;
    display: flex;
    align-items: center; /* Выравнивание по центру внутри логотипа */
    gap: 10px;
    height: 100%; /* Занимает всю высоту родителя */
}
        
        .logo span {
            color: #f1c40f;
        }
        
       nav ul {
    display: flex;
    list-style: none;
    gap: 20px;
    align-items: center; /* Выравнивание пунктов меню по центру */
    height: 100%; /* Занимает всю высоту родителя */
}

/* Стили для кнопок каталога */
.btn-catalog {
    display: inline-block;
    background: var(--primary-light);
    color: white;
    padding: 10px 20px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
    margin-top: 15px;
    border: none;
    cursor: pointer;
    font-size: 14px;
}

.btn-catalog:hover {
    background: var(--secondary-light);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

body.dark-theme .btn-catalog {
    background: #f1c40f;
    color: #333;
}

body.dark-theme .btn-catalog:hover {
    background: #f39c12;
}

/* Обновляем сетку features для 6 элементов */
.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 30px;
}

nav a {
    color: white;
    text-decoration: none;
    font-weight: 500;
    padding: 10px 18px;
    border-radius: 20px;
    transition: all 0.3s ease;
    font-size: 15px;
    display: flex;
    align-items: center; /* Выравнивание текста по центру */
    height: 100%; /* Занимает всю доступную высоту */
}
        
        nav a:hover, nav a.active {
            background: rgba(255, 255, 255, 0.2);
        }
        
     .auth-buttons {
    display: flex;
    gap: 15px;
    align-items: center; /* Выравнивание кнопок по центру */
    height: 100%; /* Занимает всю высоту родителя */
}

/* Стиль для кнопки "О нас" */
.about-link {
    min-width: 90px; /* Увеличиваем минимальную ширину */
    text-align: center;
    justify-content: center;
}
        
/* Для неавторизованных пользователей */
.btn {
    padding: 12px 24px;
    border-radius: 25px;
    border: none;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 15px;
    display: flex;
    align-items: center; /* Центрируем текст в кнопках */
    justify-content: center;
}

.btn-login {
    background: transparent;
    color: white;
    border: 2px solid white;
    min-width: 80px;
}

.btn-register {
    background: white;
    color: var(--primary-light);
    min-width: 120px;
}
        
        .btn-login:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        .btn-register:hover {
            background: rgba(255, 255, 255, 0.9);
            transform: translateY(-2px);
        }
        
        .theme-toggle-btn {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    border: none;
    padding: 10px 18px;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    white-space: nowrap;
    height: 100%;
}
        .theme-toggle-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

/* Убедитесь, что все внутренние элементы также выровнены по центру */
.user-menu {
    display: flex;
    align-items: center;
    gap: 15px;
    height: 100%;
}

/* Делаем всю область user-info кликабельной */
.user-info {
    display: flex;
    align-items: center;
    gap: 12px;
    color: white;
    font-weight: 500;
    background: rgba(255, 255, 255, 0.1);
    padding: 10px 18px;
    border-radius: 20px;
    backdrop-filter: blur(10px);
    min-width: 120px;
    height: 100%;
    text-decoration: none;
    transition: all 0.3s ease;
    cursor: pointer;
}

.user-info:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: translateY(-1px);
}

/* Убираем стандартные стили ссылки */
.user-info:visited, .user-info:active {
    color: white;
}

.user-avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: linear-gradient(135deg, #f1c40f, #f39c12);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #333;
    font-weight: bold;
    font-size: 16px;
    box-shadow: 0 4px 12px rgba(241, 196, 15, 0.3);
    flex-shrink: 0; /* Запрещаем сжатие аватара */
}


    .btn-profile {
    background: linear-gradient(135deg, #f1c40f, #f39c12);
    color: #333;
    padding: 12px 30px; /* Увеличили отступы для более растянутого вида */
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(241, 196, 15, 0.3);
    font-size: 15px;
    min-width: 140px; /* Минимальная ширина для кнопки */
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    white-space: nowrap; /* Запрещаем перенос текста */
}

.btn-profile:hover {
    background: linear-gradient(135deg, #f39c12, #e67e22);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(241, 196, 15, 0.4);
}

.btn-logout {
    background: transparent;
    color: white;
    border: 2px solid rgba(255, 255, 255, 0.3);
    padding: 10px 20px; /* Увеличили отступы */
    border-radius: 20px;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
    font-size: 14px;
    min-width: 80px; /* Минимальная ширина для кнопки */
    text-align: center;
    white-space: nowrap;
}

.btn-logout:hover {
    background: rgba(255, 255, 255, 0.1);
    border-color: rgba(255, 255, 255, 0.5);
}

.theme-toggle-btn {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    border: none;
    padding: 10px 18px; /* Увеличили отступы */
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px; /* Увеличили отступ между иконкой и текстом */
    font-size: 14px;
    white-space: nowrap;
}

.theme-toggle-btn:hover {
    background: rgba(255, 255, 255, 0.3);
}
        
        /* Hero Section */
        .hero {
            padding: 80px 0;
            text-align: center;
        }
        
        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
            color: white;
        }
        
        .hero p {
            font-size: 20px;
            max-width: 700px;
            margin: 0 auto 30px;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .btn-hero {
            background: #f1c40f;
            color: #333;
            padding: 12px 30px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 30px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-hero:hover {
            background: #f39c12;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        
        /* Features Section */
        .features {
            padding: 80px 0;
        }
        
        .section-title {
            text-align: center;
            font-size: 36px;
            margin-bottom: 50px;
            color: white;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .feature-card {
            background: var(--card-light);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        body.dark-theme .feature-card {
            background: var(--card-dark);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
        }
        
        .feature-icon {
            font-size: 40px;
            margin-bottom: 20px;
            color: var(--primary-light);
        }
        
        body.dark-theme .feature-icon {
            color: #f1c40f;
        }
        
        .feature-card h3 {
            font-size: 22px;
            margin-bottom: 15px;
        }
        
        /* Benefits Section */
        .benefits {
            padding: 80px 0;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .benefits-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: center;
        }
        
        .benefits-text h2 {
            font-size: 36px;
            margin-bottom: 20px;
            color: white;
        }
        
        .benefits-text p {
            margin-bottom: 20px;
            font-size: 18px;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .benefits-image {
            text-align: center;
        }
        
        .benefits-image img {
            max-width: 100%;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }
        
        /* Testimonials */
        .testimonials {
            padding: 80px 0;
        }
        
        .testimonials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .testimonial-card {
            background: var(--card-light);
            border-radius: 15px;
            padding: 30px;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        body.dark-theme .testimonial-card {
            background: var(--card-dark);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .testimonial-card:hover {
            transform: translateY(-5px);
        }
        
        .testimonial-text {
            font-style: italic;
            margin-bottom: 20px;
        }
        
        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .author-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--primary-light);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .author-info h4 {
            font-size: 18px;
        }
        
        .author-info p {
            font-size: 14px;
            opacity: 0.7;
        }
        
        /* CTA Section */
        .cta {
            padding: 80px 0;
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .cta h2 {
            font-size: 36px;
            margin-bottom: 20px;
            color: white;
        }
        
        .cta p {
            font-size: 20px;
            max-width: 700px;
            margin: 0 auto 30px;
            color: rgba(255, 255, 255, 0.9);
        }
        
        /* Footer */
        footer {
            padding: 50px 0 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }
        
        .footer-column h3 {
            font-size: 20px;
            margin-bottom: 20px;
            color: white;
        }
        
        .footer-column ul {
            list-style: none;
        }
        
        .footer-column ul li {
            margin-bottom: 10px;
        }
        
        .footer-column a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer-column a:hover {
            color: white;
        }
        
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: var(--card-light);
            border-radius: 15px;
            width: 90%;
            max-width: 450px;
            padding: 25px;
            position: relative;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
            max-height: 85vh;
            overflow-y: auto;
        }
        
        body.dark-theme .modal-content {
            background: var(--card-dark);
        }
        
        .compact-form {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .form-row {
            display: flex;
            gap: 12px;
        }
        
        .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        
        .form-group.full-width {
            flex: 0 0 100%;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            font-size: 13px;
            color: #666;
        }
        
        body.dark-theme .form-group label {
            color: #bbb;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        body.dark-theme .form-group input, body.dark-theme .form-group select {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
            color: var(--text-dark);
        }
        
        .form-group input:focus, .form-group select:focus {
            border-color: var(--primary-light);
            outline: none;
            box-shadow: 0 0 0 2px rgba(142, 68, 173, 0.2);
        }
        
        .form-submit {
            width: 100%;
            padding: 12px;
            background: var(--primary-light);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .form-submit:hover {
            background: var(--secondary-light);
            transform: translateY(-2px);
        }
        
        .form-footer {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        
        .form-footer a {
            color: var(--primary-light);
            text-decoration: none;
            font-weight: 500;
        }
        
        body.dark-theme .form-footer a {
            color: #f1c40f;
        }
        
        .modal h2 {
            margin-bottom: 20px;
            text-align: center;
            font-size: 22px;
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 20px;
            cursor: pointer;
            color: #777;
            background: none;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .close-modal:hover {
            background: rgba(0, 0, 0, 0.1);
        }
        
        body.dark-theme .close-modal {
            color: #bbb;
        }
        
        body.dark-theme .close-modal:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        /* Стили для индикатора сложности пароля */
        .password-strength {
            height: 4px;
            background: #eee;
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
            border-radius: 2px;
        }
        
        .password-weak .password-strength-bar {
            background: #e74c3c;
            width: 33%;
        }
        
        .password-medium .password-strength-bar {
            background: #f39c12;
            width: 66%;
        }
        
        .password-strong .password-strength-bar {
            background: #2ecc71;
            width: 100%;
        }
        
        .password-hint {
            font-size: 12px;
            color: #777;
            margin-top: 3px;
        }
        
        body.dark-theme .password-hint {
            color: #bbb;
        }
        
        /* Адаптивность для мобильных устройств */
        @media (max-width: 480px) {
            
            .form-row {
                flex-direction: column;
                gap: 12px;
            }
            
            .modal-content {
                padding: 20px;
                max-width: 95%;
            }
            
            .header-content {
                flex-direction: column;
                gap: 20px;
            }
            
            nav ul {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .hero h1 {
                font-size: 36px;
            }
            
            .hero p {
                font-size: 18px;
            }
            
            .benefits-content {
                grid-template-columns: 1fr;
            }
            
            .section-title {
                font-size: 30px;
            }

             .user-menu {
        flex-direction: column;
        gap: 8px;
    }
    
    .user-info {
        padding: 6px 12px;
        font-size: 14px;
    }
    
    .btn-profile, .btn-logout {
        padding: 8px 16px;
        font-size: 13px;
    }
}
    </style>
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <header>
    <div class="container">
        <div class="header-content">
            <div class="logo">Peely<span>Pulse</span></div>
            <nav>
    <ul>
        <li><a href="#">Главная</a></li>
        <li><a href="#features">Ассортимент</a></li>
        <li><a href="#benefits">Преимущества</a></li> <!-- Обновленная ссылка -->
        <li><a href="#testimonials">Отзывы</a></li>
        <li><a href="#about" class="about-link">О нас</a></li>
    </ul>
</nav>
            <div class="auth-buttons">
    <?php if (isset($_SESSION['client_id'])): ?>
        <!-- Показываем для авторизованного пользователя -->
        <div class="user-menu">
            <a href="profile.php" class="user-info">
                <div class="user-avatar">
                    <?php 
                    $login = $_SESSION['client_login'];
                    echo strtoupper(mb_substr($login, 0, 1)); 
                    ?>
                </div>
                <span><?php echo htmlspecialchars($login); ?></span>
            </a>
            <a href="logout.php" class="btn-logout">Выйти</a>
        </div>
    <?php else: ?>
        <!-- Показываем для неавторизованного пользователя -->
        <button class="btn btn-login" id="login-btn">Вход</button>
        <button class="btn btn-register" id="register-btn">Регистрация</button>
    <?php endif; ?>
    <button class="theme-toggle-btn" id="theme-toggle">
        <span id="theme-icon">🌙</span> Тема
    </button>
</div>
        </div>
    </div>
</header>
    
    <section class="hero">
        <div class="container">
            <h1>Инновационные решения для вашего бизнеса</h1>
            <p>PeelyPulse предлагает передовые рекламные технологии, которые помогут вашему бренду выделиться на рынке и привлечь целевую аудиторию.</p>
            <button class="btn-hero" id="learn-more-btn">Узнать больше</button>
        </div>
    </section>
    
    <!-- Добавьте этот код в dashboard.php после секции hero и перед секцией features -->

<!-- Модальное окно выбора агента -->
<div class="modal" id="agent-modal">
    <div class="modal-content agent-modal-content">
        <button class="close-modal">&times;</button>
        <h2>Выберите вашего консультанта</h2>
        <p class="modal-subtitle">Каждый агент специализируется на определенном направлении и поможет вам достичь лучших результатов</p>
        
        <div class="agents-grid" id="agents-container">
            <!-- Агенты будут загружены через JavaScript -->
        </div>
        
        <div class="selected-agent-info" id="selected-agent-info" style="display: none;">
            <div class="agent-details">
                <div class="agent-avatar-large">
                    <img id="selected-agent-img" src="" alt="Выбранный агент">
                </div>
                <div class="agent-text-info">
                    <h3 id="selected-agent-name"></h3>
                    <p id="selected-agent-specialty"></p>
                    <p id="selected-agent-description"></p>
                    <a href="#" class="btn-agent-action" id="agent-action-link">Перейти к услуге</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Стили для модального окна агентов */
.agent-modal-content {
    max-width: 900px;
    padding: 30px;
}

.modal-subtitle {
    text-align: center;
    margin-bottom: 30px;
    color: #666;
    font-size: 16px;
}

.agents-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.agent-card {
    background: var(--card-light);
    border-radius: 15px;
    padding: 20px;
    text-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
    border: 2px solid transparent;
    position: relative;
    overflow: hidden;
}

body.dark-theme .agent-card {
    background: var(--card-dark);
}

.agent-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    border-color: var(--primary-light);
}

.agent-card.selected {
    border-color: var(--primary-light);
    background: rgba(142, 68, 173, 0.1);
}

body.dark-theme .agent-card.selected {
    background: rgba(142, 68, 173, 0.2);
}

.agent-avatar {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    margin: 0 auto 15px;
    overflow: hidden;
    border: 3px solid var(--primary-light);
    transition: all 0.3s ease;
}

.agent-card.selected .agent-avatar {
    border-color: #f1c40f;
    transform: scale(1.05);
}

.agent-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.agent-name {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--primary-light);
}

body.dark-theme .agent-name {
    color: #f1c40f;
}

.agent-specialty {
    font-size: 14px;
    color: #666;
    margin-bottom: 10px;
}

body.dark-theme .agent-specialty {
    color: #bbb;
}

.agent-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: var(--primary-light);
    color: white;
    padding: 3px 8px;
    border-radius: 10px;
    font-size: 12px;
    font-weight: 500;
}

/* Стили для информации о выбранном агенте */
.selected-agent-info {
    background: rgba(142, 68, 173, 0.05);
    border-radius: 15px;
    padding: 25px;
    margin-top: 20px;
    border: 1px solid rgba(142, 68, 173, 0.2);
}

body.dark-theme .selected-agent-info {
    background: rgba(142, 68, 173, 0.1);
    border-color: rgba(142, 68, 173, 0.3);
}

.agent-details {
    display: flex;
    align-items: center;
    gap: 25px;
}

.agent-avatar-large {
    flex-shrink: 0;
    width: 150px;
    height: 150px;
    border-radius: 50%;
    overflow: hidden;
    border: 4px solid var(--primary-light);
}

.agent-avatar-large img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.agent-text-info {
    flex: 1;
}

.agent-text-info h3 {
    font-size: 24px;
    margin-bottom: 5px;
    color: var(--primary-light);
}

body.dark-theme .agent-text-info h3 {
    color: #f1c40f;
}

.agent-text-info p:first-of-type {
    font-weight: 500;
    margin-bottom: 10px;
    color: #666;
}

body.dark-theme .agent-text-info p:first-of-type {
    color: #bbb;
}

.agent-text-info p:last-of-type {
    margin-bottom: 20px;
    line-height: 1.5;
}

.btn-agent-action {
    display: inline-block;
    background: var(--primary-light);
    color: white;
    padding: 12px 25px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
    font-size: 16px;
}

.btn-agent-action:hover {
    background: var(--secondary-light);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

/* Анимация появления */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.selected-agent-info {
    animation: fadeIn 0.5s ease;
}

/* Адаптивность */
@media (max-width: 768px) {
    .agent-details {
        flex-direction: column;
        text-align: center;
    }
    
    .agents-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    }
}

@media (max-width: 480px) {
    .agent-modal-content {
        padding: 20px;
    }
    
    .agents-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
// Данные об агентах
const agentsData = [
    {
        id: 'cate',
        name: 'Кэти',
        image: 'images/cate.png',
        specialty: 'Специалист по цифровому маркетингу',
        description: 'Кэти поможет вам разработать эффективную стратегию цифрового маркетинга, включая SEO, контекстную рекламу и таргетирование в социальных сетях. Её подход основан на глубоком анализе данных и трендов.',
        category: 'digital',
        categoryName: 'Цифровой маркетинг',
        badge: '📱'
    },
    {
        id: 'kkv',
        name: 'Рейвен',
        image: 'images/kkv.png',
        specialty: 'Эксперт по креативному дизайну',
        description: 'Рейвен создаст уникальный визуальный контент для вашего бренда. От фирменного стиля до рекламных материалов - её работы всегда выделяются на фоне конкурентов.',
        category: 'design',
        categoryName: 'Креативный дизайн',
        badge: '🎨'
    },
    {
        id: 'spice',
        name: 'Тыковка',
        image: 'images/spice.png',
        specialty: 'Аналитик и стратег',
        description: 'Тыковка проведет глубокий анализ вашего бизнеса и конкурентов, предоставит детальные отчеты и рекомендации для повышения эффективности маркетинговых кампаний.',
        category: 'analytics',
        categoryName: 'Аналитика и отчетность',
        badge: '📊'
    },
    {
        id: 'phantom',
        name: 'Мяускул',
        image: 'images/phantom.png',
        specialty: 'Специалист по интернет-рекламе',
        description: 'Мяускул знает все о продвижении в digital-пространстве. Медийная реклама, видеомаркетинг, SMM - он найдет оптимальные каналы для вашего бренда.',
        category: 'internet',
        categoryName: 'Интернет-реклама',
        badge: '🌐'
    },
    {
        id: 'meowskulls',
        name: 'Бой-кот',
        image: 'images/meowskulls.png',
        specialty: 'Эксперт по наружной рекламе',
        description: 'Бой-кот разработает эффективные решения для привлечения внимания на улицах города. Билборды, ситилайты, брендирование транспорта - её козырь.',
        category: 'outdoor',
        categoryName: 'Наружная реклама',
        badge: '🏢'
    },
    {
        id: 'thunder',
        name: 'Гром',
        image: 'images/thunder.png',
        specialty: 'Менеджер спецпроектов',
        description: 'Гром организует масштабные промо-акции, ивенты и комплексные рекламные кампании. Его проекты всегда производят wow-эффект.',
        category: 'special',
        categoryName: 'Спецпроекты',
        badge: '🎯'
    }
];

// Функция для загрузки агентов в сетку
function loadAgents() {
    const agentsContainer = document.getElementById('agents-container');
    agentsContainer.innerHTML = '';
    
    agentsData.forEach(agent => {
        const agentCard = document.createElement('div');
        agentCard.className = 'agent-card';
        agentCard.setAttribute('data-agent-id', agent.id);
        
        agentCard.innerHTML = `
            <div class="agent-badge">${agent.badge}</div>
            <div class="agent-avatar">
                <img src="${agent.image}" alt="${agent.name}">
            </div>
            <h3 class="agent-name">${agent.name}</h3>
            <p class="agent-specialty">${agent.specialty}</p>
        `;
        
        agentCard.addEventListener('click', () => selectAgent(agent.id));
        agentsContainer.appendChild(agentCard);
    });
}

// Функция выбора агента
function selectAgent(agentId) {
    // Снимаем выделение со всех карточек
    document.querySelectorAll('.agent-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Выделяем выбранную карточку
    const selectedCard = document.querySelector(`[data-agent-id="${agentId}"]`);
    selectedCard.classList.add('selected');
    
    // Находим данные выбранного агента
    const agent = agentsData.find(a => a.id === agentId);
    
    // Заполняем информацию о выбранном агенте
    document.getElementById('selected-agent-img').src = agent.image;
    document.getElementById('selected-agent-img').alt = agent.name;
    document.getElementById('selected-agent-name').textContent = agent.name;
    document.getElementById('selected-agent-specialty').textContent = agent.specialty;
    document.getElementById('selected-agent-description').textContent = agent.description;
    
    // Настраиваем ссылку на категорию
    const actionLink = document.getElementById('agent-action-link');
    actionLink.href = `catalog.php?category=${agent.category}`;
    actionLink.textContent = `Перейти к ${agent.categoryName}`;
    
    // Показываем блок с информацией
    document.getElementById('selected-agent-info').style.display = 'block';
    
    // Прокручиваем к информации об агенте
    document.getElementById('selected-agent-info').scrollIntoView({ 
        behavior: 'smooth', 
        block: 'nearest' 
    });
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    loadAgents();
    
    // Обработчик для кнопки "Узнать больше"
    const learnMoreBtn = document.querySelector('.btn-hero');
    const agentModal = document.getElementById('agent-modal');
    const closeModalBtn = agentModal.querySelector('.close-modal');
    
    learnMoreBtn.addEventListener('click', function() {
        agentModal.style.display = 'flex';
        // Сбрасываем выбор агента при открытии
        document.querySelectorAll('.agent-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.getElementById('selected-agent-info').style.display = 'none';
    });
    
    closeModalBtn.addEventListener('click', function() {
        agentModal.style.display = 'none';
    });
    
    // Закрытие модального окна при клике вне его
    window.addEventListener('click', function(e) {
        if (e.target === agentModal) {
            agentModal.style.display = 'none';
        }
    });
});
</script>

    <section class="features" id="features">
    <div class="container">
        <h2 class="section-title">Наши услуги</h2>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">📱</div>
                <h3>Цифровой маркетинг</h3>
                <p>Баннеры, всплывающие окна, контекстная реклама, SEO-продвижение и таргетированная реклама в соцсетях.</p>
                <a href="catalog.php?category=digital" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎨</div>
                <h3>Креативный дизайн</h3>
                <p>Футболки, брошюры, листовки, наклейки, вывески и другие рекламные материалы с уникальным дизайном.</p>
                <a href="catalog.php?category=design" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <h3>Аналитика и отчетность</h3>
                <p>Отчеты по эффективности кампаний, аналитика конкурентов, мониторинг бренда и SEO-аналитика.</p>
                <a href="catalog.php?category=analytics" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🌐</div>
                <h3>Интернет-реклама</h3>
                <p>Медийная реклама, видеореклама, email-маркетинг, SMM и продвижение в мессенджерах.</p>
                <a href="catalog.php?category=internet" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🏢</div>
                <h3>Наружная реклама</h3>
                <p>Билборды, ситилайты, штендеры, брендирование транспорта и оформление точек продаж.</p>
                <a href="catalog.php?category=outdoor" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3>Спецпроекты</h3>
                <p>Промо-акции, ивенты, product placement, спонсорство и комплексные рекламные кампании.</p>
                <a href="catalog.php?category=special" class="btn-catalog">Смотреть каталог</a>
            </div>
        </div>
    </div>
</section>
    
    <section class="benefits" id="benefits">
    <div class="container">
        <h2 class="section-title">Почему выбирают PeelyPulse?</h2>
        <p class="section-subtitle">Уникальное сочетание экспертизы, технологий и индивидуального подхода</p>
        
        <div class="benefits-grid">
            <div class="benefit-card">
                <div class="benefit-icon">🚀</div>
                <h3>Инновационные решения</h3>
                <p>Мы используем передовые технологии и креативные подходы, чтобы ваш бренд выделялся на фоне конкурентов</p>
            </div>
            
            <div class="benefit-card">
                <div class="benefit-icon">🎯</div>
                <h3>Точечное таргетирование</h3>
                <p>Точное попадание в целевую аудиторию благодаря глубокой аналитике и современным инструментам</p>
            </div>
            
            <div class="benefit-card">
                <div class="benefit-icon">💎</div>
                <h3>Премиум качество</h3>
                <p>Все работы выполняются на высшем уровне с вниманием к каждой детали и требованием к совершенству</p>
            </div>
        </div>

        <div class="team-showcase">
            <h3 class="team-title">Наша команда экспертов</h3>
            <p class="team-subtitle">Профессионалы с узкой специализацией готовы решить ваши задачи</p>
            
            <div class="agents-showcase-grid">
                <div class="agent-showcase-card" data-agent="cate">
                    <div class="agent-showcase-avatar">
                        <img src="images/cate.png" alt="Кэти">
                        <div class="agent-badge digital">📱</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Кэти</h4>
                        <p>Цифровой маркетинг</p>
                        <span>SEO, контекстная реклама, таргетинг</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="kkv">
                    <div class="agent-showcase-avatar">
                        <img src="images/kkv.png" alt="Рейвен">
                        <div class="agent-badge design">🎨</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Рейвен</h4>
                        <p>Креативный дизайн</p>
                        <span>Брендинг, визуальный контент, айдентика</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="spice">
                    <div class="agent-showcase-avatar">
                        <img src="images/spice.png" alt="Тыковка">
                        <div class="agent-badge analytics">📊</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Тыковка</h4>
                        <p>Аналитика и отчетность</p>
                        <span>Анализ данных, KPI, оптимизация</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="phantom">
                    <div class="agent-showcase-avatar">
                        <img src="images/phantom.png" alt="Мяускул">
                        <div class="agent-badge internet">🌐</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Мяускул</h4>
                        <p>Интернет-реклама</p>
                        <span>SMM, медийная реклама, видео</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="meowskulls">
                    <div class="agent-showcase-avatar">
                        <img src="images/meowskulls.png" alt="Бой-кот">
                        <div class="agent-badge outdoor">🏢</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Бой-кот</h4>
                        <p>Наружная реклама</p>
                        <span>Билборды, брендирование, OOH</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="thunder">
                    <div class="agent-showcase-avatar">
                        <img src="images/thunder.png" alt="Гром">
                        <div class="agent-badge special">🎯</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Гром</h4>
                        <p>Спецпроекты</p>
                        <span>Ивенты, промо-акции, комплексные решения</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="benefits-stats">
            <div class="stat-item">
                <div class="stat-number">500+</div>
                <div class="stat-label">Успешных проектов</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">98%</div>
                <div class="stat-label">Довольных клиентов</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">3+</div>
                <div class="stat-label">Года на рынке</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">24/7</div>
                <div class="stat-label">Поддержка клиентов</div>
            </div>
        </div>
    </div>
</section>

<style>
/* Стили для обновленной секции benefits */
.benefits {
    padding: 80px 0;
    background: rgba(255, 255, 255, 0.1);
    position: relative;
    overflow: hidden;
}

.section-subtitle {
    text-align: center;
    font-size: 18px;
    color: rgba(255, 255, 255, 0.9);
    max-width: 600px;
    margin: 0 auto 50px;
    line-height: 1.6;
}

.benefits-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    margin-bottom: 60px;
}

.benefit-card {
    background: var(--card-light);
    border-radius: 20px;
    padding: 35px 30px;
    text-align: center;
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
}

body.dark-theme .benefit-card {
    background: var(--card-dark);
}

.benefit-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
    transition: left 0.6s ease;
}

.benefit-card:hover::before {
    left: 100%;
}

.benefit-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.benefit-icon {
    font-size: 50px;
    margin-bottom: 20px;
    display: block;
}

.benefit-card h3 {
    font-size: 22px;
    margin-bottom: 15px;
    color: var(--primary-light);
}

body.dark-theme .benefit-card h3 {
    color: #f1c40f;
}

.benefit-card p {
    line-height: 1.6;
    color: #666;
}

body.dark-theme .benefit-card p {
    color: #bbb;
}

/* Стили для показа команды */
.team-showcase {
    margin: 60px 0;
    text-align: center;
}

.team-title {
    font-size: 32px;
    margin-bottom: 15px;
    color: white;
}

.team-subtitle {
    font-size: 18px;
    color: rgba(255, 255, 255, 0.8);
    margin-bottom: 40px;
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
}

.agents-showcase-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 25px;
    margin-top: 40px;
}

.agent-showcase-card {
    background: var(--card-light);
    border-radius: 20px;
    padding: 25px;
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s ease;
    cursor: pointer;
    border: 2px solid transparent;
    position: relative;
    overflow: hidden;
}

body.dark-theme .agent-showcase-card {
    background: var(--card-dark);
}

.agent-showcase-card:hover {
    transform: translateY(-5px);
    border-color: var(--primary-light);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
}

.agent-showcase-avatar {
    position: relative;
    flex-shrink: 0;
}

.agent-showcase-avatar img {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid var(--primary-light);
    transition: all 0.3s ease;
}

.agent-showcase-card:hover .agent-showcase-avatar img {
    transform: scale(1.1);
    border-color: #f1c40f;
}

.agent-badge {
    position: absolute;
    bottom: -5px;
    right: -5px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    background: var(--primary-light);
    color: white;
    border: 2px solid var(--card-light);
}

body.dark-theme .agent-badge {
    border-color: var(--card-dark);
}

.agent-showcase-info {
    text-align: left;
    flex: 1;
}

.agent-showcase-info h4 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--primary-light);
}

body.dark-theme .agent-showcase-info h4 {
    color: #f1c40f;
}

.agent-showcase-info p {
    font-weight: 500;
    margin-bottom: 5px;
    color: #333;
}

body.dark-theme .agent-showcase-info p {
    color: #ddd;
}

.agent-showcase-info span {
    font-size: 12px;
    color: #666;
    display: block;
}

body.dark-theme .agent-showcase-info span {
    color: #999;
}

/* Стили для статистики */
.benefits-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 30px;
    margin-top: 50px;
    padding-top: 40px;
    border-top: 1px solid rgba(255, 255, 255, 0.2);
}

.stat-item {
    text-align: center;
    color: white;
}

.stat-number {
    font-size: 42px;
    font-weight: 700;
    margin-bottom: 10px;
    background: linear-gradient(135deg, #f1c40f, #f39c12);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-shadow: 0 4px 15px rgba(241, 196, 15, 0.3);
}

.stat-label {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.9);
    font-weight: 500;
}

/* Анимации */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.benefit-card, .agent-showcase-card, .stat-item {
    animation: fadeInUp 0.6s ease forwards;
}

.benefit-card:nth-child(1) { animation-delay: 0.1s; }
.benefit-card:nth-child(2) { animation-delay: 0.2s; }
.benefit-card:nth-child(3) { animation-delay: 0.3s; }

.agent-showcase-card:nth-child(1) { animation-delay: 0.1s; }
.agent-showcase-card:nth-child(2) { animation-delay: 0.2s; }
.agent-showcase-card:nth-child(3) { animation-delay: 0.3s; }
.agent-showcase-card:nth-child(4) { animation-delay: 0.4s; }
.agent-showcase-card:nth-child(5) { animation-delay: 0.5s; }
.agent-showcase-card:nth-child(6) { animation-delay: 0.6s; }

.stat-item:nth-child(1) { animation-delay: 0.1s; }
.stat-item:nth-child(2) { animation-delay: 0.2s; }
.stat-item:nth-child(3) { animation-delay: 0.3s; }
.stat-item:nth-child(4) { animation-delay: 0.4s; }

/* Адаптивность */
@media (max-width: 768px) {
    .benefits-grid {
        grid-template-columns: 1fr;
    }
    
    .agents-showcase-grid {
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    }
    
    .agent-showcase-card {
        flex-direction: column;
        text-align: center;
        padding: 20px;
    }
    
    .agent-showcase-info {
        text-align: center;
    }
    
    .benefits-stats {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .stat-number {
        font-size: 36px;
    }
}

@media (max-width: 480px) {
    .benefits {
        padding: 60px 0;
    }
    
    .team-title {
        font-size: 28px;
    }
    
    .agents-showcase-grid {
        grid-template-columns: 1fr;
    }
    
    .benefits-stats {
        grid-template-columns: 1fr;
        gap: 20px;
    }
}
</style>

<script>
// Добавьте этот скрипт для интерактивности с агентами
document.addEventListener('DOMContentLoaded', function() {
    // Обработчики для карточек агентов в секции benefits
    document.querySelectorAll('.agent-showcase-card').forEach(card => {
        card.addEventListener('click', function() {
            const agentId = this.getAttribute('data-agent');
            // Открываем модальное окно с агентами
            document.getElementById('agent-modal').style.display = 'flex';
            // Выбираем соответствующего агента
            selectAgent(agentId);
        });
    });
    
    // Анимация появления при скролле
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Наблюдаем за элементами для анимации
    document.querySelectorAll('.benefit-card, .agent-showcase-card, .stat-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});
</script>
    
    <section class="testimonials" id="testimonials">
        <div class="container">
            <h2 class="section-title">Что говорят наши клиенты</h2>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Благодаря PeelyPulse наш бренд стал узнаваемым в регионе. Результаты превзошли все ожидания!"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">ИП</div>
                        <div class="author-info">
                            <h4>Иван Петров</h4>
                            <p>Владелец бизнеса</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Профессиональный подход и креативные решения. Рекомендую PeelyPulse всем, кто хочет расти!"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">ОО</div>
                        <div class="author-info">
                            <h4>Ольга Орлова</h4>
                            <p>Маркетинг-директор</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Отличное соотношение цены и качества. Кампания окупилась уже в первый месяц после запуска."
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">АС</div>
                        <div class="author-info">
                            <h4>Алексей Смирнов</h4>
                            <p>Предприниматель</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="cta" id="about">
        <div class="container">
            <h2>Готовы начать работать с нами?</h2>
            <p>Свяжитесь с нами сегодня и получите бесплатную консультацию по вашей рекламной кампании.</p>
            <button class="btn-hero">Связаться с нами</button>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>PeelyPulse</h3>
                    <p>Инновационные рекламные решения для бизнеса любого масштаба.</p>
                </div>
                <div class="footer-column">
                    <h3>Услуги</h3>
                    <ul>
                        <li><a href="#">Цифровой маркетинг</a></li>
                        <li><a href="#">Брендинг</a></li>
                        <li><a href="#">Медийная реклама</a></li>
                        <li><a href="#">Аналитика</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Компания</h3>
                    <ul>
                        <li><a href="#">О нас</a></li>
                        <li><a href="#">Команда</a></li>
                        <li><a href="#">Карьера</a></li>
                        <li><a href="#">Контакты</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Контакты</h3>
                    <ul>
                        <li>г. Белово, ул. Ильича, 32А</li>
                        <li>+7 (3842) 123-456</li>
                        <li>info@peelypulse.ru</li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 PeelyPulse. Все права защищены.</p>
            </div>
        </div>
    </footer>
    
    <?php if (!isset($_SESSION['client_id'])): ?>
    <!-- Login Modal -->
    <div class="modal" id="login-modal">
        <div class="modal-content">
            <button class="close-modal">&times;</button>
            <h2>Вход в систему</h2>
            <form id="login-form" class="compact-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group full-width">
                    <label for="login-username">Логин</label>
                    <input type="text" id="login-username" name="login" required>
                </div>
                <div class="form-group full-width">
                    <label for="login-password">Пароль</label>
                    <input type="password" id="login-password" name="password" required>
                </div>
                <button type="submit" class="form-submit">Войти</button>
            </form>
            <div class="form-footer">
                <p>Нет аккаунта? <a href="#" id="switch-to-register">Зарегистрироваться</a></p>
            </div>
        </div>
    </div>
    
    <!-- Register Modal -->
    <div class="modal" id="register-modal">
        <div class="modal-content">
            <button class="close-modal">&times;</button>
            <h2>Регистрация</h2>
            <form id="register-form" class="compact-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group full-width">
                    <label for="org-name">Название организации</label>
                    <input type="text" id="org-name" name="org_name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="full-name">ФИО</label>
                        <input type="text" id="full-name" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="contact-person">Контактное лицо</label>
                        <input type="text" id="contact-person" name="contact_person" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Телефон</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="inn">ИНН</label>
                        <input type="text" id="inn" name="inn" required>
                    </div>
                    <div class="form-group">
                        <label for="region">Регион</label>
                        <input type="text" id="region" name="region" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="industry">Отрасль</label>
                        <select id="industry" name="industry" required>
                            <option value="">Выберите отрасль</option>
                            <option value="розничная торговля">Розничная торговля</option>
                            <option value="строительство">Строительство</option>
                            <option value="услуги">Услуги</option>
                            <option value="производство">Производство</option>
                            <option value="ресторанный бизнес">Ресторанный бизнес</option>
                            <option value="финансы">Финансы</option>
                            <option value="промышленность">Промышленность</option>
                            <option value="сервис">Сервис</option>
                            <option value="маркетинг">Маркетинг</option>
                            <option value="логистика">Логистика</option>
                            <option value="энергия">Энергия</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="budget-segment">Бюджетный сегмент</label>
                        <select id="budget-segment" name="budget_segment" required>
                            <option value="">Выберите сегмент</option>
                            <option value="low">Низкий</option>
                            <option value="medium">Средний</option>
                            <option value="high">Высокий</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label for="username">Логин</label>
                    <input type="text" id="username" name="login" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Пароль</label>
                        <input type="password" id="password" name="password" required>
                        <div class="password-strength">
                            <div class="password-strength-bar"></div>
                        </div>
                        <div class="password-hint">Минимум 6 символов</div>
                    </div>
                    <div class="form-group">
                        <label for="confirm-password">Подтвердите пароль</label>
                        <input type="password" id="confirm-password" name="confirm_password" required>
                    </div>
                </div>
                
                <button type="submit" class="form-submit">Зарегистрироваться</button>
            </form>
            <div class="form-footer">
                <p>Уже есть аккаунт? <a href="#" id="switch-to-login">Войти</a></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <script>
        // Theme Toggle
        const toggleButton = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const body = document.body;
        
        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
            themeIcon.textContent = '☀️';
        }
        
        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
                themeIcon.textContent = '☀️';
            } else {
                localStorage.setItem('theme', 'light');
                themeIcon.textContent = '🌙';
            }
        });
        
        // Star Animation
        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 150;
        
        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }
        
        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }
        
        initStars();
        drawStars();
        
        window.addEventListener('resize', initStars);
        
        <?php if (!isset($_SESSION['client_id'])): ?>
        // Modal Handling (только для неавторизованных пользователей)
        const loginBtn = document.getElementById('login-btn');
        const registerBtn = document.getElementById('register-btn');
        const loginModal = document.getElementById('login-modal');
        const registerModal = document.getElementById('register-modal');
        const closeButtons = document.querySelectorAll('.close-modal');
        const switchToRegister = document.getElementById('switch-to-register');
        const switchToLogin = document.getElementById('switch-to-login');
        
        // Обработчики для кнопок входа и регистрации
        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                loginModal.style.display = 'flex';
            });
        }
        
        if (registerBtn) {
            registerBtn.addEventListener('click', () => {
                registerModal.style.display = 'flex';
            });
        }
        
        // Обработчики для закрытия модальных окон
        closeButtons.forEach(button => {
            button.addEventListener('click', () => {
                if (loginModal) loginModal.style.display = 'none';
                if (registerModal) registerModal.style.display = 'none';
            });
        });
        
        // Переключение между формами
        if (switchToRegister) {
            switchToRegister.addEventListener('click', (e) => {
                e.preventDefault();
                loginModal.style.display = 'none';
                registerModal.style.display = 'flex';
            });
        }
        
        if (switchToLogin) {
            switchToLogin.addEventListener('click', (e) => {
                e.preventDefault();
                registerModal.style.display = 'none';
                loginModal.style.display = 'flex';
            });
        }
        
        // Закрытие модальных окон при клике вне их
        window.addEventListener('click', (e) => {
            if (loginModal && e.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (registerModal && e.target === registerModal) {
                registerModal.style.display = 'none';
            }
        });
        
        // Индикатор сложности пароля
        const passwordInput = document.getElementById('password');
        if (passwordInput) {
            const passwordStrength = document.querySelector('.password-strength');
            const passwordStrengthBar = document.querySelector('.password-strength-bar');
            const passwordHint = document.querySelector('.password-hint');
            
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                let strength = 0;
                let hint = '';
                
                if (password.length >= 6) strength += 1;
                if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 1;
                if (password.match(/\d/)) strength += 1;
                if (password.match(/[^a-zA-Z\d]/)) strength += 1;
                
                // Обновляем индикатор
                passwordStrength.className = 'password-strength';
                if (password.length > 0) {
                    if (strength <= 1) {
                        passwordStrength.classList.add('password-weak');
                        hint = 'Слабый пароль';
                    } else if (strength <= 2) {
                        passwordStrength.classList.add('password-medium');
                        hint = 'Средний пароль';
                    } else {
                        passwordStrength.classList.add('password-strong');
                        hint = 'Сильный пароль';
                    }
                    passwordHint.textContent = hint;
                } else {
                    passwordHint.textContent = 'Минимум 6 символов';
                }
            });
        }
        
        // Проверка совпадения паролей в реальном времени
        const confirmPasswordInput = document.getElementById('confirm-password');
        if (confirmPasswordInput && passwordInput) {
            confirmPasswordInput.addEventListener('input', function() {
                const password = passwordInput.value;
                const confirmPassword = this.value;
                
                if (confirmPassword && password !== confirmPassword) {
                    this.style.borderColor = '#e74c3c';
                } else {
                    this.style.borderColor = '';
                }
            });
        }
        
        // Обработчик формы входа (реальный)
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const submitBtn = this.querySelector('.form-submit');
                const originalText = submitBtn.textContent;
                
                // Показываем индикатор загрузки
                submitBtn.textContent = 'Вход...';
                submitBtn.disabled = true;
                
                // Собираем данные формы
                const formData = new FormData(this);
                
                // Отправляем запрос на сервер
                fetch('login_handler.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        loginModal.style.display = 'none';
                        this.reset();
                        // Перенаправляем пользователя или обновляем интерфейс
                        window.location.reload();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Произошла ошибка при входе.');
                })
                .finally(() => {
                    // Восстанавливаем кнопку
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                });
            });
        }
        
        // Обработчик формы регистрации (реальный)
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirm-password').value;
                
                if (password !== confirmPassword) {
                    alert('Пароли не совпадают!');
                    return;
                }
                
                if (password.length < 6) {
                    alert('Пароль должен содержать минимум 6 символов!');
                    return;
                }
                
                const submitBtn = this.querySelector('.form-submit');
                const originalText = submitBtn.textContent;
                
                // Показываем индикатор загрузки
                submitBtn.textContent = 'Регистрация...';
                submitBtn.disabled = true;
                
                // Собираем данные формы
                const formData = new FormData(this);
                
                // Отправляем запрос на сервер
                fetch('register_handler.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        registerModal.style.display = 'none';
                        this.reset();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Произошла ошибка при регистрации.');
                })
                .finally(() => {
                    // Восстанавливаем кнопку
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                });
            });
        }
        <?php endif; ?>
        
        // Smooth scrolling for navigation links
        document.querySelectorAll('nav a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId.startsWith('#')) {
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>
user-avatar
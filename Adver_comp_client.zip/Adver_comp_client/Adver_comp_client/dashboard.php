<?php 
include 'csrf.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PeelyPulse - Рекламная компания</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="css-styles/dashboard.css">
</head>
<body>
    <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <header>
    <div class="container">
        <div class="header-content">
            <div class="logo">Peely<span>Pulse</span></div>
            <nav>
    <ul>
        <li><a href="#">Главная</a></li>
        <li><a href="#features">Ассортимент</a></li>
        <li><a href="#benefits">Преимущества</a></li> <!-- Обновленная ссылка -->
        <li><a href="#testimonials">Отзывы</a></li>
        <li><a href="#about" class="about-link">О нас</a></li>
    </ul>
</nav>
            <div class="auth-buttons">
    <?php if (isset($_SESSION['client_id'])): ?>
        <!-- Показываем для авторизованного пользователя -->
        <div class="user-menu">
        <?php 
        $login = $_SESSION['client_login'];
        ?>
        <a href="profile.php" class="user-info">
            <div class="user-avatar">
                <img src="images/peely.png" alt="Аватар" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
            </div>
            <span><?php echo htmlspecialchars($login); ?></span>
        </a>
        <a href="logout.php" class="btn-logout">Выйти</a>
    </div>
    <?php else: ?>
        <!-- Показываем для неавторизованного пользователя -->
        <button class="btn btn-login" id="login-btn">Вход</button>
        <button class="btn btn-register" id="register-btn">Регистрация</button>
    <?php endif; ?>
    <button class="theme-toggle-btn" id="theme-toggle">
        <span id="theme-icon">🌙</span> Тема
    </button>
</div>
        </div>
    </div>
</header>
    
    <section class="hero">
        <div class="container">
            <h1>Инновационные решения для вашего бизнеса</h1>
            <p>PeelyPulse предлагает передовые рекламные технологии, которые помогут вашему бренду выделиться на рынке и привлечь целевую аудиторию.</p>
            <button class="btn-hero" id="learn-more-btn">Узнать больше</button>
        </div>
    </section>
    
    <!-- Добавьте этот код в dashboard.php после секции hero и перед секцией features -->

<!-- Модальное окно выбора агента -->
<div class="modal" id="agent-modal">
    <div class="modal-content agent-modal-content">
        <button class="close-modal">&times;</button>
        <h2>Выберите вашего консультанта</h2>
        <p class="modal-subtitle">Каждый агент специализируется на определенном направлении и поможет вам достичь лучших результатов</p>
        
        <div class="agents-grid" id="agents-container">
            <!-- Агенты будут загружены через JavaScript -->
        </div>
        
        <div class="selected-agent-info" id="selected-agent-info" style="display: none;">
            <div class="agent-details">
                <div class="agent-avatar-large">
                    <img id="selected-agent-img" src="" alt="Выбранный агент">
                </div>
                <div class="agent-text-info">
                    <h3 id="selected-agent-name"></h3>
                    <p id="selected-agent-specialty"></p>
                    <p id="selected-agent-description"></p>
                    <a href="#" class="btn-agent-action" id="agent-action-link">Перейти к услуге</a>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// Данные об агентах
const agentsData = [
    {
        id: 'cate',
        name: 'Кэти',
        image: 'images/cate.png',
        specialty: 'Специалист по цифровому маркетингу',
        description: 'Кэти поможет вам разработать эффективную стратегию цифрового маркетинга, включая SEO, контекстную рекламу и таргетирование в социальных сетях. Её подход основан на глубоком анализе данных и трендов.',
        category: 'digital',
        categoryName: 'Цифровой маркетинг',
        badge: '📱'
    },
    {
        id: 'kkv',
        name: 'Рейвен',
        image: 'images/kkv.png',
        specialty: 'Эксперт по креативному дизайну',
        description: 'Рейвен создаст уникальный визуальный контент для вашего бренда. От фирменного стиля до рекламных материалов - её работы всегда выделяются на фоне конкурентов.',
        category: 'design',
        categoryName: 'Креативный дизайн',
        badge: '🎨'
    },
    {
        id: 'spice',
        name: 'Тыковка',
        image: 'images/spice.png',
        specialty: 'Аналитик и стратег',
        description: 'Тыковка проведет глубокий анализ вашего бизнеса и конкурентов, предоставит детальные отчеты и рекомендации для повышения эффективности маркетинговых кампаний.',
        category: 'analytics',
        categoryName: 'Аналитика и отчетность',
        badge: '📊'
    },
    {
        id: 'phantom',
        name: 'Мяускул',
        image: 'images/phantom.png',
        specialty: 'Специалист по интернет-рекламе',
        description: 'Мяускул знает все о продвижении в digital-пространстве. Медийная реклама, видеомаркетинг, SMM - он найдет оптимальные каналы для вашего бренда.',
        category: 'internet',
        categoryName: 'Интернет-реклама',
        badge: '🌐'
    },
    {
        id: 'meowskulls',
        name: 'Бой-кот',
        image: 'images/meowskulls.png',
        specialty: 'Эксперт по наружной рекламе',
        description: 'Бой-кот разработает эффективные решения для привлечения внимания на улицах города. Билборды, ситилайты, брендирование транспорта - её козырь.',
        category: 'outdoor',
        categoryName: 'Наружная реклама',
        badge: '🏢'
    },
    {
        id: 'thunder',
        name: 'Гром',
        image: 'images/thunder.png',
        specialty: 'Менеджер спецпроектов',
        description: 'Гром организует масштабные промо-акции, ивенты и комплексные рекламные кампании. Его проекты всегда производят wow-эффект.',
        category: 'special',
        categoryName: 'Спецпроекты',
        badge: '🎯'
    }
];

// Функция для загрузки агентов в сетку
function loadAgents() {
    const agentsContainer = document.getElementById('agents-container');
    agentsContainer.innerHTML = '';
    
    agentsData.forEach(agent => {
        const agentCard = document.createElement('div');
        agentCard.className = 'agent-card';
        agentCard.setAttribute('data-agent-id', agent.id);
        
        agentCard.innerHTML = `
            <div class="agent-badge">${agent.badge}</div>
            <div class="agent-avatar">
                <img src="${agent.image}" alt="${agent.name}">
            </div>
            <h3 class="agent-name">${agent.name}</h3>
            <p class="agent-specialty">${agent.specialty}</p>
        `;
        
        agentCard.addEventListener('click', () => selectAgent(agent.id));
        agentsContainer.appendChild(agentCard);
    });
}

// Функция выбора агента
function selectAgent(agentId) {
    // Снимаем выделение со всех карточек
    document.querySelectorAll('.agent-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Выделяем выбранную карточку
    const selectedCard = document.querySelector(`[data-agent-id="${agentId}"]`);
    selectedCard.classList.add('selected');
    
    // Находим данные выбранного агента
    const agent = agentsData.find(a => a.id === agentId);
    
    // Заполняем информацию о выбранном агенте
    document.getElementById('selected-agent-img').src = agent.image;
    document.getElementById('selected-agent-img').alt = agent.name;
    document.getElementById('selected-agent-name').textContent = agent.name;
    document.getElementById('selected-agent-specialty').textContent = agent.specialty;
    document.getElementById('selected-agent-description').textContent = agent.description;
    
    // Настраиваем ссылку на категорию
    const actionLink = document.getElementById('agent-action-link');
    actionLink.href = `catalog.php?category=${agent.category}`;
    actionLink.textContent = `Перейти к ${agent.categoryName}`;
    
    // Показываем блок с информацией
    document.getElementById('selected-agent-info').style.display = 'block';
    
    // Прокручиваем к информации об агенте
    document.getElementById('selected-agent-info').scrollIntoView({ 
        behavior: 'smooth', 
        block: 'nearest' 
    });
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    loadAgents();
    
    // Обработчик для кнопки "Узнать больше"
    const learnMoreBtn = document.querySelector('.btn-hero');
    const agentModal = document.getElementById('agent-modal');
    const closeModalBtn = agentModal.querySelector('.close-modal');
    
    learnMoreBtn.addEventListener('click', function() {
        agentModal.style.display = 'flex';
        // Сбрасываем выбор агента при открытии
        document.querySelectorAll('.agent-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.getElementById('selected-agent-info').style.display = 'none';
    });
    
    closeModalBtn.addEventListener('click', function() {
        agentModal.style.display = 'none';
    });
    
    // Закрытие модального окна при клике вне его
    window.addEventListener('click', function(e) {
        if (e.target === agentModal) {
            agentModal.style.display = 'none';
        }
    });
});
</script>

    <section class="features" id="features">
    <div class="container">
        <h2 class="section-title">Наши услуги</h2>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">📱</div>
                <h3>Цифровой маркетинг</h3>
                <p>Баннеры, всплывающие окна, контекстная реклама, SEO-продвижение и таргетированная реклама в соцсетях.</p>
                <a href="catalog.php?category=digital" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎨</div>
                <h3>Креативный дизайн</h3>
                <p>Футболки, брошюры, листовки, наклейки, вывески и другие рекламные материалы с уникальным дизайном.</p>
                <a href="catalog.php?category=design" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <h3>Аналитика и отчетность</h3>
                <p>Отчеты по эффективности кампаний, аналитика конкурентов, мониторинг бренда и SEO-аналитика.</p>
                <a href="catalog.php?category=analytics" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🌐</div>
                <h3>Интернет-реклама</h3>
                <p>Медийная реклама, видеореклама, email-маркетинг, SMM и продвижение в мессенджерах.</p>
                <a href="catalog.php?category=internet" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🏢</div>
                <h3>Наружная реклама</h3>
                <p>Билборды, ситилайты, штендеры, брендирование транспорта и оформление точек продаж.</p>
                <a href="catalog.php?category=outdoor" class="btn-catalog">Смотреть каталог</a>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3>Спецпроекты</h3>
                <p>Промо-акции, ивенты, product placement, спонсорство и комплексные рекламные кампании.</p>
                <a href="catalog.php?category=special" class="btn-catalog">Смотреть каталог</a>
            </div>
        </div>
    </div>
</section>
    
    <section class="benefits" id="benefits">
    <div class="container">
        <h2 class="section-title">Почему выбирают PeelyPulse?</h2>
        <p class="section-subtitle">Уникальное сочетание экспертизы, технологий и индивидуального подхода</p>
        
        <div class="benefits-grid">
            <div class="benefit-card">
                <div class="benefit-icon">🚀</div>
                <h3>Инновационные решения</h3>
                <p>Мы используем передовые технологии и креативные подходы, чтобы ваш бренд выделялся на фоне конкурентов</p>
            </div>
            
            <div class="benefit-card">
                <div class="benefit-icon">🎯</div>
                <h3>Точечное таргетирование</h3>
                <p>Точное попадание в целевую аудиторию благодаря глубокой аналитике и современным инструментам</p>
            </div>
            
            <div class="benefit-card">
                <div class="benefit-icon">💎</div>
                <h3>Премиум качество</h3>
                <p>Все работы выполняются на высшем уровне с вниманием к каждой детали и требованием к совершенству</p>
            </div>
        </div>

        <div class="team-showcase">
            <h3 class="team-title">Наша команда экспертов</h3>
            <p class="team-subtitle">Профессионалы с узкой специализацией готовы решить ваши задачи</p>
            
            <div class="agents-showcase-grid">
                <div class="agent-showcase-card" data-agent="cate">
                    <div class="agent-showcase-avatar">
                        <img src="images/cate.png" alt="Кэти">
                        <div class="agent-badge digital">📱</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Кэти</h4>
                        <p>Цифровой маркетинг</p>
                        <span>SEO, контекстная реклама, таргетинг</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="kkv">
                    <div class="agent-showcase-avatar">
                        <img src="images/kkv.png" alt="Рейвен">
                        <div class="agent-badge design">🎨</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Рейвен</h4>
                        <p>Креативный дизайн</p>
                        <span>Брендинг, визуальный контент, айдентика</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="spice">
                    <div class="agent-showcase-avatar">
                        <img src="images/spice.png" alt="Тыковка">
                        <div class="agent-badge analytics">📊</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Тыковка</h4>
                        <p>Аналитика и отчетность</p>
                        <span>Анализ данных, KPI, оптимизация</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="phantom">
                    <div class="agent-showcase-avatar">
                        <img src="images/phantom.png" alt="Мяускул">
                        <div class="agent-badge internet">🌐</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Мяускул</h4>
                        <p>Интернет-реклама</p>
                        <span>SMM, медийная реклама, видео</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="meowskulls">
                    <div class="agent-showcase-avatar">
                        <img src="images/meowskulls.png" alt="Бой-кот">
                        <div class="agent-badge outdoor">🏢</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Бой-кот</h4>
                        <p>Наружная реклама</p>
                        <span>Билборды, брендирование, OOH</span>
                    </div>
                </div>
                
                <div class="agent-showcase-card" data-agent="thunder">
                    <div class="agent-showcase-avatar">
                        <img src="images/thunder.png" alt="Гром">
                        <div class="agent-badge special">🎯</div>
                    </div>
                    <div class="agent-showcase-info">
                        <h4>Гром</h4>
                        <p>Спецпроекты</p>
                        <span>Ивенты, промо-акции, комплексные решения</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="benefits-stats">
            <div class="stat-item">
                <div class="stat-number">500+</div>
                <div class="stat-label">Успешных проектов</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">98%</div>
                <div class="stat-label">Довольных клиентов</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">3+</div>
                <div class="stat-label">Года на рынке</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">24/7</div>
                <div class="stat-label">Поддержка клиентов</div>
            </div>
        </div>
    </div>
</section>

<script>
// Добавьте этот скрипт для интерактивности с агентами
document.addEventListener('DOMContentLoaded', function() {
    // Обработчики для карточек агентов в секции benefits
    document.querySelectorAll('.agent-showcase-card').forEach(card => {
        card.addEventListener('click', function() {
            const agentId = this.getAttribute('data-agent');
            // Открываем модальное окно с агентами
            document.getElementById('agent-modal').style.display = 'flex';
            // Выбираем соответствующего агента
            selectAgent(agentId);
        });
    });
    
    // Анимация появления при скролле
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Наблюдаем за элементами для анимации
    document.querySelectorAll('.benefit-card, .agent-showcase-card, .stat-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});
</script>
    
    <section class="testimonials" id="testimonials">
        <div class="container">
            <h2 class="section-title">Что говорят наши клиенты</h2>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Благодаря PeelyPulse наш бренд стал узнаваемым в регионе. Результаты превзошли все ожидания!"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">ИП</div>
                        <div class="author-info">
                            <h4>Иван Петров</h4>
                            <p>Владелец бизнеса</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Профессиональный подход и креативные решения. Рекомендую PeelyPulse всем, кто хочет расти!"
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">ОО</div>
                        <div class="author-info">
                            <h4>Ольга Орлова</h4>
                            <p>Маркетинг-директор</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Отличное соотношение цены и качества. Кампания окупилась уже в первый месяц после запуска."
                    </div>
                    <div class="testimonial-author">
                        <div class="author-avatar">АС</div>
                        <div class="author-info">
                            <h4>Алексей Смирнов</h4>
                            <p>Предприниматель</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="cta" id="about">
        <div class="container">
            <h2>Готовы начать работать с нами?</h2>
            <p>Свяжитесь с нами сегодня и получите бесплатную консультацию по вашей рекламной кампании.</p>
            <button class="btn-hero">Связаться с нами</button>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>PeelyPulse</h3>
                    <p>Инновационные рекламные решения для бизнеса любого масштаба.</p>
                </div>
                <div class="footer-column">
                    <h3>Услуги</h3>
                    <ul>
                        <li><a href="#">Цифровой маркетинг</a></li>
                        <li><a href="#">Брендинг</a></li>
                        <li><a href="#">Медийная реклама</a></li>
                        <li><a href="#">Аналитика</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Компания</h3>
                    <ul>
                        <li><a href="#">О нас</a></li>
                        <li><a href="#">Команда</a></li>
                        <li><a href="#">Карьера</a></li>
                        <li><a href="#">Контакты</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Контакты</h3>
                    <ul>
                        <li>г. Белово, ул. Ильича, 32А</li>
                        <li>+7 (3842) 123-456</li>
                        <li>info@peelypulse.ru</li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 PeelyPulse. Все права защищены.</p>
            </div>
        </div>
    </footer>
    
    <?php if (!isset($_SESSION['client_id'])): ?>
    <!-- Login Modal -->
    <div class="modal" id="login-modal">
        <div class="modal-content">
            <button class="close-modal">&times;</button>
            <h2>Вход в систему</h2>
            <form id="login-form" class="compact-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group full-width">
                    <label for="login-username">Логин</label>
                    <input type="text" id="login-username" name="login" required>
                </div>
                <div class="form-group full-width">
                    <label for="login-password">Пароль</label>
                    <input type="password" id="login-password" name="password" required>
                </div>
                <button type="submit" class="form-submit">Войти</button>
            </form>
            <div class="form-footer">
                <p>Нет аккаунта? <a href="#" id="switch-to-register">Зарегистрироваться</a></p>
            </div>
        </div>
    </div>
    
    <!-- Register Modal -->
    <div class="modal" id="register-modal">
        <div class="modal-content">
            <button class="close-modal">&times;</button>
            <h2>Регистрация</h2>
            <form id="register-form" class="compact-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group full-width">
                    <label for="org-name">Название организации</label>
                    <input type="text" id="org-name" name="org_name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="full-name">ФИО</label>
                        <input type="text" id="full-name" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="contact-person">Контактное лицо</label>
                        <input type="text" id="contact-person" name="contact_person" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Телефон</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="inn">ИНН</label>
                        <input type="text" id="inn" name="inn" required>
                    </div>
                    <div class="form-group">
                        <label for="region">Регион</label>
                        <input type="text" id="region" name="region" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="industry">Отрасль</label>
                        <select id="industry" name="industry" required>
                            <option value="">Выберите отрасль</option>
                            <option value="розничная торговля">Розничная торговля</option>
                            <option value="строительство">Строительство</option>
                            <option value="услуги">Услуги</option>
                            <option value="производство">Производство</option>
                            <option value="ресторанный бизнес">Ресторанный бизнес</option>
                            <option value="финансы">Финансы</option>
                            <option value="промышленность">Промышленность</option>
                            <option value="сервис">Сервис</option>
                            <option value="маркетинг">Маркетинг</option>
                            <option value="логистика">Логистика</option>
                            <option value="энергия">Энергия</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="budget-segment">Бюджетный сегмент</label>
                        <select id="budget-segment" name="budget_segment" required>
                            <option value="">Выберите сегмент</option>
                            <option value="low">Низкий</option>
                            <option value="medium">Средний</option>
                            <option value="high">Высокий</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label for="username">Логин</label>
                    <input type="text" id="username" name="login" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Пароль</label>
                        <input type="password" id="password" name="password" required>
                        <div class="password-strength">
                            <div class="password-strength-bar"></div>
                        </div>
                        <div class="password-hint">Минимум 6 символов</div>
                    </div>
                    <div class="form-group">
                        <label for="confirm-password">Подтвердите пароль</label>
                        <input type="password" id="confirm-password" name="confirm_password" required>
                    </div>
                </div>
                
                <button type="submit" class="form-submit">Зарегистрироваться</button>
            </form>
            <div class="form-footer">
                <p>Уже есть аккаунт? <a href="#" id="switch-to-login">Войти</a></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <script>
        // Theme Toggle
        const toggleButton = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const body = document.body;
        
        if (localStorage.getItem('theme') === 'dark') {
            body.classList.add('dark-theme');
            themeIcon.textContent = '☀️';
        }
        
        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
                themeIcon.textContent = '☀️';
            } else {
                localStorage.setItem('theme', 'light');
                themeIcon.textContent = '🌙';
            }
        });
        
        // Star Animation
        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 150;
        
        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }
        
        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }
        
        initStars();
        drawStars();
        
        window.addEventListener('resize', initStars);
        
        <?php if (!isset($_SESSION['client_id'])): ?>
        // Modal Handling (только для неавторизованных пользователей)
        const loginBtn = document.getElementById('login-btn');
        const registerBtn = document.getElementById('register-btn');
        const loginModal = document.getElementById('login-modal');
        const registerModal = document.getElementById('register-modal');
        const closeButtons = document.querySelectorAll('.close-modal');
        const switchToRegister = document.getElementById('switch-to-register');
        const switchToLogin = document.getElementById('switch-to-login');
        
        // Обработчики для кнопок входа и регистрации
        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                loginModal.style.display = 'flex';
            });
        }
        
        if (registerBtn) {
            registerBtn.addEventListener('click', () => {
                registerModal.style.display = 'flex';
            });
        }
        
        // Обработчики для закрытия модальных окон
        closeButtons.forEach(button => {
            button.addEventListener('click', () => {
                if (loginModal) loginModal.style.display = 'none';
                if (registerModal) registerModal.style.display = 'none';
            });
        });
        
        // Переключение между формами
        if (switchToRegister) {
            switchToRegister.addEventListener('click', (e) => {
                e.preventDefault();
                loginModal.style.display = 'none';
                registerModal.style.display = 'flex';
            });
        }
        
        if (switchToLogin) {
            switchToLogin.addEventListener('click', (e) => {
                e.preventDefault();
                registerModal.style.display = 'none';
                loginModal.style.display = 'flex';
            });
        }
        
        // Закрытие модальных окон при клике вне их
        window.addEventListener('click', (e) => {
            if (loginModal && e.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (registerModal && e.target === registerModal) {
                registerModal.style.display = 'none';
            }
        });
        
        // Индикатор сложности пароля
        const passwordInput = document.getElementById('password');
        if (passwordInput) {
            const passwordStrength = document.querySelector('.password-strength');
            const passwordStrengthBar = document.querySelector('.password-strength-bar');
            const passwordHint = document.querySelector('.password-hint');
            
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                let strength = 0;
                let hint = '';
                
                if (password.length >= 6) strength += 1;
                if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 1;
                if (password.match(/\d/)) strength += 1;
                if (password.match(/[^a-zA-Z\d]/)) strength += 1;
                
                // Обновляем индикатор
                passwordStrength.className = 'password-strength';
                if (password.length > 0) {
                    if (strength <= 1) {
                        passwordStrength.classList.add('password-weak');
                        hint = 'Слабый пароль';
                    } else if (strength <= 2) {
                        passwordStrength.classList.add('password-medium');
                        hint = 'Средний пароль';
                    } else {
                        passwordStrength.classList.add('password-strong');
                        hint = 'Сильный пароль';
                    }
                    passwordHint.textContent = hint;
                } else {
                    passwordHint.textContent = 'Минимум 6 символов';
                }
            });
        }
        
        // Проверка совпадения паролей в реальном времени
        const confirmPasswordInput = document.getElementById('confirm-password');
        if (confirmPasswordInput && passwordInput) {
            confirmPasswordInput.addEventListener('input', function() {
                const password = passwordInput.value;
                const confirmPassword = this.value;
                
                if (confirmPassword && password !== confirmPassword) {
                    this.style.borderColor = '#e74c3c';
                } else {
                    this.style.borderColor = '';
                }
            });
        }
        
        // Обработчик формы входа (реальный)
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const submitBtn = this.querySelector('.form-submit');
                const originalText = submitBtn.textContent;
                
                // Показываем индикатор загрузки
                submitBtn.textContent = 'Вход...';
                submitBtn.disabled = true;
                
                // Собираем данные формы
                const formData = new FormData(this);
                
                // Отправляем запрос на сервер
                fetch('login_handler.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        loginModal.style.display = 'none';
                        this.reset();
                        // Перенаправляем пользователя или обновляем интерфейс
                        window.location.reload();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Произошла ошибка при входе.');
                })
                .finally(() => {
                    // Восстанавливаем кнопку
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                });
            });
        }
        
        // Обработчик формы регистрации (реальный)
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirm-password').value;
                
                if (password !== confirmPassword) {
                    alert('Пароли не совпадают!');
                    return;
                }
                
                if (password.length < 6) {
                    alert('Пароль должен содержать минимум 6 символов!');
                    return;
                }
                
                const submitBtn = this.querySelector('.form-submit');
                const originalText = submitBtn.textContent;
                
                // Показываем индикатор загрузки
                submitBtn.textContent = 'Регистрация...';
                submitBtn.disabled = true;
                
                // Собираем данные формы
                const formData = new FormData(this);
                
                // Отправляем запрос на сервер
                fetch('register_handler.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        registerModal.style.display = 'none';
                        this.reset();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Произошла ошибка при регистрации.');
                })
                .finally(() => {
                    // Восстанавливаем кнопку
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                });
            });
        }
        <?php endif; ?>
        
        // Smooth scrolling for navigation links
        document.querySelectorAll('nav a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId.startsWith('#')) {
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>
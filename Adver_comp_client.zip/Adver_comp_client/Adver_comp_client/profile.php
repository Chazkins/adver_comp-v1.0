<?php
include 'csrf.php';
include 'db.php';

// Проверяем авторизацию
if (!isset($_SESSION['client_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Получаем данные пользователя
$client_id = $_SESSION['client_id'];
$stmt = $conn->prepare("SELECT * FROM clients WHERE client_id = ?");
$stmt->bind_param("i", $client_id);
$stmt->execute();
$result = $stmt->get_result();
$client = $result->fetch_assoc();

// Получаем заказы пользователя из таблицы client_orders
$orders_stmt = $conn->prepare("
    SELECT * FROM client_orders 
    WHERE client_id = ? 
    ORDER BY order_date DESC
");
$orders_stmt->bind_param("i", $client_id);
$orders_stmt->execute();
$orders = $orders_stmt->get_result();

// Получаем статус регистрации
$registration_stmt = $conn->prepare("SELECT status FROM registration WHERE client_id = ?");
$registration_stmt->bind_param("i", $client_id);
$registration_stmt->execute();
$registration_result = $registration_stmt->get_result();
$registration = $registration_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет - PeelyPulse</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
    <style>
        :root {
            --primary-light: #8e44ad;
            --secondary-light: #9b59b6;
            --primary-dark: #2c3e50;
            --secondary-dark: #34495e;
            --text-light: #333;
            --text-dark: #ecf0f1;
            --card-light: rgba(255, 255, 255, 0.9);
            --card-dark: rgba(44, 62, 80, 0.8);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-light), var(--secondary-light));
            color: var(--text-light);
            transition: all 0.5s ease;
            min-height: 100vh;
        }
        
        body.dark-theme {
            background: linear-gradient(135deg, var(--primary-dark), var(--secondary-dark));
            color: var(--text-dark);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .stars-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }
        
        /* Обновляем стили для лучшего отображения */
        .profile-container {
            padding: 40px 0;
            position: relative;
            z-index: 1;
        }
        
       /* Header & Navigation */
        header {
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            min-height: 60px;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
            height: 100%;
        }
        
        .logo span {
            color: #f1c40f;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            gap: 20px;
            align-items: center;
            height: 100%;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 10px 18px;
            border-radius: 20px;
            transition: all 0.3s ease;
            font-size: 15px;
            display: flex;
            align-items: center;
            height: 100%;
        }
        
        nav a:hover, nav a.active {
            background: rgba(255, 255, 255, 0.2);
        }

        .auth-buttons {
            display: flex;
            gap: 15px;
            align-items: center;
            height: 100%;
        }

        .about-link {
            min-width: 90px;
            text-align: center;
            justify-content: center;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
            height: 100%;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 18px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            min-width: 120px;
            height: 100%;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .user-info:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-1px);
        }

        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            flex-shrink: 0;
        }

        .btn-logout {
            background: transparent;
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
            padding: 8px 16px;
            border-radius: 20px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-logout:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .theme-toggle-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }

        .theme-toggle-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        /* Стили для личного кабинета */
        .profile-header {
            text-align: center;
            margin-bottom: 40px;
            color: white;
        }

        .profile-header h1 {
            font-size: 36px;
            margin-bottom: 10px;
        }

        .profile-grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }

        .profile-card, .orders-card {
            background: var(--card-light);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        body.dark-theme .profile-card,
        body.dark-theme .orders-card {
            background: var(--card-dark);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .profile-card h2, .orders-card h2 {
            margin-bottom: 20px;
            color: var(--primary-light);
            border-bottom: 2px solid var(--primary-light);
            padding-bottom: 10px;
        }

        body.dark-theme .profile-card h2,
        body.dark-theme .orders-card h2 {
            color: #f1c40f;
            border-bottom-color: #f1c40f;
        }

        .info-group {
            margin-bottom: 15px;
        }

        .info-label {
            font-weight: 600;
            color: #666;
            margin-bottom: 5px;
        }

        body.dark-theme .info-label {
            color: #bbb;
        }

        .info-value {
            font-size: 16px;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-pending {
            background: #f39c12;
            color: white;
        }

        .status-confirmed {
            background: #2ecc71;
            color: white;
        }

        .status-expired {
            background: #e74c3c;
            color: white;
        }

        .status-completed {
            background: #27ae60;
            color: white;
        }

        .status-canceled {
            background: #95a5a6;
            color: white;
        }

        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }

        .orders-table th,
        .orders-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        body.dark-theme .orders-table th,
        body.dark-theme .orders-table td {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .orders-table th {
            background: rgba(0, 0, 0, 0.05);
            font-weight: 600;
        }

        body.dark-theme .orders-table th {
            background: rgba(255, 255, 255, 0.05);
        }

        .no-orders {
            text-align: center;
            padding: 40px;
            color: #666;
        }

        body.dark-theme .no-orders {
            color: #bbb;
        }

        .btn-back {
            display: inline-block;
            background: var(--primary-light);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            margin-top: 20px;
        }

        .btn-back:hover {
            background: var(--secondary-light);
            transform: translateY(-2px);
        }

        .btn-cancel {
            background: #e74c3c;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s ease;
        }

        .btn-cancel:hover {
            background: #c0392b;
            transform: translateY(-1px);
        }

        /* Адаптивность для мобильных устройств */
        @media (max-width: 480px) {
            .about-link {
                min-width: 70px;
                font-size: 14px;
                padding: 8px 12px;
            }
            
            .user-info {
                padding: 8px 14px;
                min-width: 100px;
            }
            
            .user-info span {
                font-size: 14px;
            }
            
            .user-menu {
                flex-direction: row;
                gap: 8px;
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .btn-logout {
                padding: 6px 12px;
                font-size: 13px;
                white-space: nowrap;
            }
            
            .theme-toggle-btn {
                padding: 6px 10px;
                font-size: 12px;
                white-space: nowrap;
            }
            
            @media (max-width: 360px) {
                .user-menu {
                    gap: 5px;
                }
                
                .user-info {
                    min-width: 80px;
                    padding: 6px 10px;
                }
                
                .user-info span {
                    font-size: 12px;
                }
            }
        }

        @media (max-width: 768px) {
            .profile-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }
    </style>
</head>
<body>
     <canvas id="stars-canvas" class="stars-canvas"></canvas>
    
    <!-- Полная шапка как в dashboard.php -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">Peely<span>Pulse</span></div>
                <nav>
                    <ul>
                        <li><a href="dashboard.php">Главная</a></li>
                        <li><a href="dashboard.php#features">Ассортимент</a></li>
                        <li><a href="dashboard.php#benefits">Преимущества</a></li>
                        <li><a href="dashboard.php#testimonials">Отзывы</a></li>
                        <li><a href="dashboard.php#about" class="about-link">О нас</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <div class="user-menu">
    <a href="dashboard.php" class="user-info">
        <div class="user-avatar">
            <img src="images/peely.png" alt="Аватар" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
        </div>
        <span><?php echo htmlspecialchars($client['login']); ?></span>
    </a>
    <a href="logout.php" class="btn-logout">Выйти</a>
</div>
                    <button class="theme-toggle-btn" id="theme-toggle">
                        <span id="theme-icon">🌙</span> Тема
                    </button>
                </div>
            </div>
        </div>
    </header>

    <div class="container profile-container">
        <div class="profile-header">
            <h1>Личный кабинет</h1>
            <p>Управление вашими данными и заказами</p>
        </div>

        <div class="profile-grid">
            <div class="profile-card">
                <h2>Информация о профиле</h2>
                <div class="profile-avatar" style="text-align: center; margin-bottom: 20px;">
                    <img src="images/peely.png" alt="Аватар" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 4px solid var(--primary-light);">
                </div>
                <div class="info-group">
                    <div class="info-label">Логин</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['login']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Организация</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['org_name']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">ФИО</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['full_name']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Контактное лицо</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['contact_person']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Email</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['email']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Телефон</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['phone']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">ИНН</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['inn']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Отрасль</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['industry']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Бюджетный сегмент</div>
                    <div class="info-value">
                        <?php 
                        $budget_segment = $client['budget_segment'];
                        $segment_names = [
                            'low' => 'Низкий',
                            'medium' => 'Средний',
                            'high' => 'Высокий'
                        ];
                        echo $segment_names[$budget_segment] ?? $budget_segment;
                        ?>
                    </div>
                </div>
                <div class="info-group">
                    <div class="info-label">Регион</div>
                    <div class="info-value"><?php echo htmlspecialchars($client['region']); ?></div>
                </div>
                <div class="info-group">
                    <div class="info-label">Статус регистрации</div>
                    <div class="info-value">
                        <?php if ($registration): ?>
                            <span class="status-badge status-<?php echo $registration['status']; ?>">
                                <?php 
                                $status_names = [
                                    'pending' => 'На рассмотрении',
                                    'confirmed' => 'Подтвержден',
                                    'expired' => 'Истек'
                                ];
                                echo $status_names[$registration['status']] ?? $registration['status'];
                                ?>
                            </span>
                        <?php else: ?>
                            <span class="status-badge status-pending">Неизвестно</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="orders-card">
                <h2>Мои заказы</h2>
                <?php if ($orders->num_rows > 0): ?>
                    <table class="orders-table">
                        <thead>
                            <tr>
                                <th>Товар</th>
                                <th>Кол-во</th>
                                <th>Цена за ед.</th>
                                <th>Общая стоимость</th>
                                <th>Дата заказа</th>
                                <th>Статус</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($order = $orders->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                                <td><?php echo $order['quantity']; ?> шт.</td>
                                <td><?php echo number_format($order['unit_cost'], 0, '.', ' '); ?> руб.</td>
                                <td><?php echo number_format($order['total_cost'], 0, '.', ' '); ?> руб.</td>
                                <td><?php echo date('d.m.Y H:i', strtotime($order['order_date'])); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                        <?php 
                                        $order_status_names = [
                                            'pending' => 'В обработке',
                                            'completed' => 'Выполнен',
                                            'canceled' => 'Отменен'
                                        ];
                                        echo $order_status_names[$order['status']] ?? $order['status'];
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($order['status'] == 'pending'): ?>
                                    <form method="POST" action="cancel_order.php" style="display: inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                        <button type="submit" class="btn-cancel" onclick="return confirm('Вы уверены, что хотите отменить заказ?')">Отменить</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-orders">
                        <p>У вас пока нет заказов</p>
                        <a href="catalog.php?category=digital" class="btn-back">Перейти к каталогу</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Theme Toggle - исправленная версия
        const toggleButton = document.getElementById('theme-toggle');
        const themeIcon = document.getElementById('theme-icon');
        const body = document.body;
        
        // Проверяем сохраненную тему
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            body.classList.add('dark-theme');
            themeIcon.textContent = '☀️';
        } else {
            body.classList.remove('dark-theme');
            themeIcon.textContent = '🌙';
        }
        
        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-theme');
            if (body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
                themeIcon.textContent = '☀️';
            } else {
                localStorage.setItem('theme', 'light');
                themeIcon.textContent = '🌙';
            }
            // Перерисовываем звезды при смене темы
            initStars();
        });
        
        // Star Animation (как в dashboard.php)
        const canvas = document.getElementById('stars-canvas');
        const ctx = canvas.getContext('2d');
        let stars = [];
        let numStars = 150;
        
        function initStars() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            stars = [];
            for (let i = 0; i < numStars; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.5 + 0.5,
                    speed: Math.random() * 0.5 + 0.2,
                    opacity: Math.random() * 0.5 + 0.5
                });
            }
        }
        
        function drawStars() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = body.classList.contains('dark-theme') ? 'rgba(255, 255, 255, 0.8)' : 'rgba(255, 255, 255, 0.6)';
            for (let star of stars) {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = -star.radius;
                    star.x = Math.random() * canvas.width;
                }
            }
            ctx.globalAlpha = 1;
            requestAnimationFrame(drawStars);
        }
        
        initStars();
        drawStars();
        
        window.addEventListener('resize', initStars);
    </script>
</body>
</html>